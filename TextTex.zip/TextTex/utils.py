import os
import array
import platform
import math
import bpy
import gpu
import blf
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from gpu.types import GPUOffScreen


# ----------------------------
# Fonts
# ----------------------------

def get_custom_font_dirs():
    """Get custom font directories from addon preferences."""
    custom_dirs = []
    try:
        # Need to get the addon package name
        package_name = __package__ if __package__ else "TextTex"
        if package_name in bpy.context.preferences.addons:
            prefs = bpy.context.preferences.addons[package_name].preferences
            if hasattr(prefs, 'custom_font_paths'):
                for item in prefs.custom_font_paths:
                    if item.path and os.path.exists(bpy.path.abspath(item.path)):
                        custom_dirs.append(bpy.path.abspath(item.path))
    except Exception:
        pass
    return custom_dirs

def load_custom_fonts_to_blender():
    """Scan custom directories and load fonts into bpy.data.fonts so they appear in the UI."""
    stats = {"loaded": 0, "existing": 0, "failed": 0}
    font_dirs = get_custom_font_dirs()
    
    existing_paths = {f.filepath for f in bpy.data.fonts}
    
    for font_dir in font_dirs:
        if os.path.exists(font_dir):
            for root, _, files in os.walk(font_dir):
                for f in files:
                    if f.lower().endswith((".ttf", ".otf")):
                        full_path = os.path.join(root, f)
                        if full_path in existing_paths:
                            stats["existing"] += 1
                            continue
                            
                        try:
                            bpy.data.fonts.load(full_path, check_existing=True)
                            stats["loaded"] += 1
                        except Exception as e:
                            print(f"Failed to load font {full_path}: {e}")
                            stats["failed"] += 1
    
    print(f"[TextTool] Custom fonts: {stats['loaded']} loaded, {stats['existing']} skipped, {stats['failed']} failed.")
    return stats


# ----------------------------
# Loaded Font Cache (blf font IDs)
# ----------------------------
_blf_font_cache = {}  # font_path -> font_id

def _get_blf_font_id(font_path):
    """Get or load a font using blf, returns font_id."""
    global _blf_font_cache
    
    if font_path in _blf_font_cache:
        return _blf_font_cache[font_path]
    
    font_id = 0  # Default font
    if font_path and os.path.exists(font_path):
        try:
            font_id = blf.load(font_path)
            if font_id == -1:
                font_id = 0
        except Exception as e:
            print(f"[TextTool] Failed to load font {font_path}: {e}")
            font_id = 0
    
    _blf_font_cache[font_path] = font_id
    return font_id


# ----------------------------
# Gradient Node Storage
# ----------------------------
def get_gradient_node():
    """Get or create a hidden node tree with a Color Ramp node."""
    tree_name = ".TextTool_Gradient_Storage"
    if tree_name not in bpy.data.node_groups:
        # Create new node group (shader type)
        tree = bpy.data.node_groups.new(tree_name, 'ShaderNodeTree')
        tree.use_fake_user = True  # Ensure it persists
    else:
        tree = bpy.data.node_groups[tree_name]
        
    # Ensure the color ramp node exists
    node_name = "Gradient_Ramp"
    if node_name not in tree.nodes:
        node = tree.nodes.new('ShaderNodeValToRGB')
        node.name = node_name
        node.label = "Gradient"
    else:
        node = tree.nodes[node_name]
        
    return node


def get_gradient_lut(node, samples=256):
    """Evaluate a Color Ramp node into a LUT of RGBA tuples."""
    if not node or not hasattr(node, "color_ramp"):
        return []
    
    ramp = node.color_ramp
    lut = []
    # Optimization: If ramp has only 1 element, just return that.
    # But usually it has 2.
    
    # Evaluate at regular intervals
    step = 1.0 / (samples - 1)
    for i in range(samples):
        # clamp position 0-1
        pos = min(1.0, i * step)
        # evaluate returns a Color object (r,g,b,a)
        # We need tuple
        c = ramp.evaluate(pos)
        lut.append((c[0], c[1], c[2], c[3]))
        
    return lut


# ----------------------------
# Native Blender Font Manager
# ----------------------------
class FontManager:
    @staticmethod
    def create_text_image(text, font_path, font_size, color, width=None, height=None, rotation_degrees=0.0, gradient_lut=None, outline_info=None):
        """Render text to pixel buffer using Blender's native blf and GPUOffScreen.
        
        Args:
            text: Text string to render
            font_path: Path to the font file
            font_size: Font size in pixels
            color: Base RGBA color tuple (used when gradient_lut is None)
            width: Optional canvas width
            height: Optional canvas height
            rotation_degrees: Rotation angle in degrees
            gradient_lut: Optional list of RGBA tuples (Look-Up Table) for gradient.
            outline_info: Optional dict with outline settings.
        
        Returns: (pixels_list, (width, height)) or (None, None) on failure
        """
        if not text:
            return None, None
        
        try:
            font_id = _get_blf_font_id(font_path)
            
            # Set font size
            blf.size(font_id, font_size)
            
            # Get text bounding box dimensions
            text_width, text_height = blf.dimensions(font_id, text)
            
            # Add padding - extra for outline if enabled
            outline_size = 0
            if outline_info and outline_info.get('enabled'):
                outline_size = outline_info.get('size', 2)
            
            padding = 10 + outline_size
            base_width = int(text_width + padding * 2)
            base_height = int(text_height + padding * 2)
            
            # For rotation, we need a larger canvas to fit rotated text
            if rotation_degrees != 0.0:
                angle_rad = math.radians(abs(rotation_degrees))
                # Calculate bounding box of rotated rectangle
                cos_a = abs(math.cos(angle_rad))
                sin_a = abs(math.sin(angle_rad))
                rotated_width = int(base_width * cos_a + base_height * sin_a) + padding * 2
                rotated_height = int(base_width * sin_a + base_height * cos_a) + padding * 2
                canvas_width = max(rotated_width, base_width)
                canvas_height = max(rotated_height, base_height)
            else:
                canvas_width = base_width
                canvas_height = base_height
            
            # Ensure minimum size
            canvas_width = max(2, canvas_width)
            canvas_height = max(2, canvas_height)
            
            # Create offscreen buffer
            offscreen = GPUOffScreen(canvas_width, canvas_height)
            
            text_pixels = []
            outline_pixels = []
            has_outline = outline_info and outline_info.get('enabled')
            
            with offscreen.bind():
                # Get framebuffer
                fb = gpu.state.active_framebuffer_get()
                
                # Setup 2D orthographic projection
                from mathutils import Matrix
                sx = 2.0 / canvas_width
                sy = 2.0 / canvas_height
                proj = Matrix((
                    (sx, 0, 0, -1),
                    (0, sy, 0, -1),
                    (0, 0, 1, 0),
                    (0, 0, 0, 1)
                ))
                
                gpu.matrix.push()
                gpu.matrix.push_projection()
                gpu.matrix.load_identity()
                gpu.matrix.load_projection_matrix(proj)
                gpu.state.blend_set('ALPHA')
                
                # Calculate geometry
                cx, cy = canvas_width / 2, canvas_height / 2
                if rotation_degrees != 0.0:
                    angle_rad = math.radians(rotation_degrees)
                    blf.enable(font_id, blf.ROTATION)
                    blf.rotation(font_id, angle_rad)
                    
                    cos_r = math.cos(angle_rad)
                    sin_r = math.sin(angle_rad)
                    offset_x = text_width / 2
                    offset_y = text_height / 2
                    rotated_offset_x = offset_x * cos_r - offset_y * sin_r
                    rotated_offset_y = offset_x * sin_r + offset_y * cos_r
                    base_x = cx - rotated_offset_x
                    base_y = cy - rotated_offset_y
                else:
                    base_x = (canvas_width - text_width) / 2
                    base_y = (canvas_height - text_height) / 2
                
                # --- PASS 1: Outline (if enabled) ---
                # We render to a separate buffer first? Or simpler: 
                # If we want gradient on text but NOT outline, we must process text separately.
                # So let's render text first to get the main shape for gradient.
                # Then render outline to get outline pixels.
                # Then composite.
                
                # --- PASS 1: Text Body ---
                fb.clear(color=(0.0, 0.0, 0.0, 0.0))
                
                # Set text color
                if gradient_lut:
                    blf.color(font_id, 1.0, 1.0, 1.0, 1.0)
                else:
                    r, g, b = color[0], color[1], color[2]
                    a = color[3] if len(color) > 3 else 1.0
                    blf.color(font_id, r, g, b, a)
                
                blf.position(font_id, base_x, base_y, 0)
                blf.draw(font_id, text)
                
                buffer_text = fb.read_color(0, 0, canvas_width, canvas_height, 4, 0, 'FLOAT')
                # Convert to flat list
                for row in buffer_text:
                    for pixel in row:
                        text_pixels.extend(pixel)
                
                # --- PASS 2: Outline (only if enabled) ---
                if has_outline:
                    fb.clear(color=(0.0, 0.0, 0.0, 0.0))
                    
                    outline_color = outline_info.get('color', (0, 0, 0, 1))
                    outline_sz = outline_info.get('size', 2)
                    
                    or_, og, ob = outline_color[0], outline_color[1], outline_color[2]
                    oa = outline_color[3] if len(outline_color) > 3 else 1.0
                    blf.color(font_id, or_, og, ob, oa)
                    
                    # Draw outline circular pattern
                    for angle in range(0, 360, 30):
                        rad = math.radians(angle)
                        ox = math.cos(rad) * outline_sz
                        oy = math.sin(rad) * outline_sz
                        blf.position(font_id, base_x + ox, base_y + oy, 0)
                        blf.draw(font_id, text)
                    
                    # Cardinal directions
                    for ox, oy in [(outline_sz, 0), (-outline_sz, 0), (0, outline_sz), (0, -outline_sz)]:
                        blf.position(font_id, base_x + ox, base_y + oy, 0)
                        blf.draw(font_id, text)
                        
                    buffer_outline = fb.read_color(0, 0, canvas_width, canvas_height, 4, 0, 'FLOAT')
                    for row in buffer_outline:
                        for pixel in row:
                            outline_pixels.extend(pixel)

                # Cleanup
                if rotation_degrees != 0.0:
                    blf.disable(font_id, blf.ROTATION)
                
                gpu.state.blend_set('NONE')
                gpu.matrix.pop_projection()
                gpu.matrix.pop()
            
            offscreen.free()
            
            # --- Post-Processing ---
            
            # 1. Apply Gradient to Text Body
            if gradient_lut:
                text_pixels = FontManager._apply_gradient(
                    text_pixels, canvas_width, canvas_height, gradient_lut
                )
            
            # 2. Composite (Text over Outline)
            if has_outline and outline_pixels:
                final_pixels = FontManager._composite_layers(text_pixels, outline_pixels)
            else:
                final_pixels = text_pixels
            
            return final_pixels, (canvas_width, canvas_height)
            
        except Exception as e:
            print(f"[TextTool] Render error: {e}")
            import traceback
            traceback.print_exc()
            return None, None
            
    @staticmethod
    def _composite_layers(fg_pixels, bg_pixels):
        """Composite foreground (text) over background (outline)."""
        # Both are flat lists of RGBA floats
        count = len(fg_pixels)
        if len(bg_pixels) != count:
            return fg_pixels 
            
        result = [0.0] * count
        
        # Simple Over operator:
        # out = fg + bg * (1 - fg.a)
        # Note: Interpreting pixels as straight alpha (Blender default)
        
        for i in range(0, count, 4):
            fr, fg, fb, fa = fg_pixels[i], fg_pixels[i+1], fg_pixels[i+2], fg_pixels[i+3]
            br, bg, bb, ba = bg_pixels[i], bg_pixels[i+1], bg_pixels[i+2], bg_pixels[i+3]
            
            inv_fa = 1.0 - fa
            
            result[i]   = fr * fa + br * inv_fa   # Using premul logic or straight?
            # Actually fb.read_color returns straight alpha usually unless we clear with 0.
            # But standard composition equation: 
            #   out_a = src_a + dst_a * (1 - src_a)
            #   out_rgb = (src_rgb * src_a + dst_rgb * dst_a * (1 - src_a)) / out_a
            # Simpler approximation for now (standard mix):
            
            result[i]   = fr * fa + br * ba * inv_fa # Premultiplied output attempt?
            # Let's stick to standard straight alpha mix:
            # Output should ideally be straight RGB and A.
            
            # Standard "Over":
            # out_a = fa + ba * (1 - fa)
            out_a = fa + ba * inv_fa
            
            # Avoid divide by zero
            if out_a > 0:
                # out_rgb = (fr * fa + br * ba * inv_fa) / out_a
                # Wait, if we assume straight inputs:
                # contributions:
                # fg contributes (fr, fg, fb) * fa
                # bg contributes (br, bg, bb) * ba * (1 - fa)
                
                result[i]   = (fr * fa + br * ba * inv_fa) / out_a
                result[i+1] = (fg * fa + bg * ba * inv_fa) / out_a
                result[i+2] = (fb * fa + bb * ba * inv_fa) / out_a
                result[i+3] = out_a
            else:
                result[i] = 0.0
                result[i+1] = 0.0
                result[i+2] = 0.0
                result[i+3] = 0.0
                
        return result
    
    @staticmethod
    def _apply_gradient(pixels, width, height, gradient_lut, gradient_type='LINEAR'):
        """Apply gradient colors to rendered text pixels using a LUT.
        
        Args:
            pixels: Flat list of RGBA pixel values
            width: Image width
            height: Image height
            gradient_lut: List of RGBA tuples sampled from the color ramp.
            gradient_type: 'LINEAR' or 'RADIAL' (passed via global prop usually, but we can assume LINEAR for now or add arg)
                           Actually, we should pass the type here too or handle it outside.
                           Let's fix the signature to include type if needed, but for now we'll assume linear/radial logic is here.
                           Wait, the gradient type is separate from the LUT.
                           We need to know the type. Let's make the LUT passed in contain the type or pass type separately.
                           The calling code (operators) has access to props.gradient_type.
                           Let's update the signature to accept gradient_type in the gradient_lut tuple or separate arg.
                           Since I can't easily change the helper arg structure without changing call sites too much, 
                           I'll assume gradient_lut is a tuple: (type, lut_list).
                           
                           Actually, let's keep it simple: the operator passes (lut, type).
                           But here I see I defined `gradient_lut` as just the list in the implementation plan.
                           Let's make `gradient_lut` be a dict or tuple containing both.
                           
                           Revised Plan for this function:
                           gradient_lut param will be expected to be: {'type': 'LINEAR', 'lut': [...colors...]}
        """
        if not highlight_content: 
             pass # Placeholder to match indentation level of original file if needed, but here replacing wholesale.

        # Simplify: The argument passed is `gradient_lut`. Let's treat it as a dictionary 
        # carrying the LUT and the type, or just split it.
        # In the plan I said "utils.FontManager.create_text_image: Update signature to accept gradient_lut... instead of gradient_info".
        # Let's use `gradient_opts` = {'type': '...', 'lut': [...]}
        pass
    
    @staticmethod
    def _apply_gradient(pixels, width, height, gradient_data):
        """Apply gradient colors to rendered text pixels.
        
        Args:
            pixels: Flat list of RGBA pixel values
            width: Image width
            height: Image height
            gradient_data: Dict with {'type': str, 'lut': list of RGBA, 'angle': float, 'font_rotation': float}
        """
        gradient_type = gradient_data.get('type', 'LINEAR')
        lut = gradient_data.get('lut', [])
        gradient_angle = gradient_data.get('angle', 0.0)
        font_rotation = gradient_data.get('font_rotation', 0.0)
        lut_len = len(lut)
        
        if lut_len < 2:
            return pixels 
        
        # --- Step 1: Find actual text bounding box (non-transparent pixels) ---
        min_x, max_x = width, 0
        min_y, max_y = height, 0
        
        for y in range(height):
            for x in range(width):
                idx = (y * width + x) * 4
                if pixels[idx + 3] > 0:  # Has alpha
                    if x < min_x: min_x = x
                    if x > max_x: max_x = x
                    if y < min_y: min_y = y
                    if y > max_y: max_y = y
        
        # If no text pixels found, return unchanged
        if max_x < min_x or max_y < min_y:
            return pixels
            
        # Text bounding box center (in canvas coordinates)
        cx = (min_x + max_x) / 2
        cy = (min_y + max_y) / 2
        
        # --- Step 2: Precompute rotation constants ---
        # To transform canvas coordinates back to "unrotated text" coordinates,
        # we rotate by the NEGATIVE of font_rotation
        font_rad = math.radians(-font_rotation)
        font_cos = math.cos(font_rad)
        font_sin = math.sin(font_rad)
        
        # Now we need to find the text bounds in the UNROTATED space
        # by transforming all text pixel positions
        local_min_x, local_max_x = float('inf'), float('-inf')
        local_min_y, local_max_y = float('inf'), float('-inf')
        
        for y in range(min_y, max_y + 1):
            for x in range(min_x, max_x + 1):
                idx = (y * width + x) * 4
                if pixels[idx + 3] > 0:
                    # Transform to local (unrotated) coordinates
                    dx = x - cx
                    dy = y - cy
                    local_x = dx * font_cos - dy * font_sin
                    local_y = dx * font_sin + dy * font_cos
                    
                    if local_x < local_min_x: local_min_x = local_x
                    if local_x > local_max_x: local_max_x = local_x
                    if local_y < local_min_y: local_min_y = local_y
                    if local_y > local_max_y: local_max_y = local_y
        
        # Local text dimensions
        local_width = local_max_x - local_min_x if local_max_x > local_min_x else 1.0
        local_height = local_max_y - local_min_y if local_max_y > local_min_y else 1.0
        local_cx = (local_min_x + local_max_x) / 2
        local_cy = (local_min_y + local_max_y) / 2
        
        # --- Step 3: Calculate gradient parameters in LOCAL space ---
        # Gradient angle is relative to the text's local coordinate system
        grad_rad = math.radians(gradient_angle)
        grad_cos = math.cos(grad_rad)
        grad_sin = math.sin(grad_rad)
        
        # For linear gradient, project local corners onto the gradient axis
        hw = local_width / 2
        hh = local_height / 2
        corners = [
            (-hw * grad_cos - -hh * grad_sin),
            ( hw * grad_cos - -hh * grad_sin),
            ( hw * grad_cos -  hh * grad_sin),
            (-hw * grad_cos -  hh * grad_sin),
        ]
        min_p = min(corners)
        max_p = max(corners)
        span = max_p - min_p if (max_p - min_p) > 0.001 else 1.0

        # Radial max dist
        max_dist = math.sqrt(hw * hw + hh * hh) if (hw > 0 and hh > 0) else 1.0

        # --- Step 4: Apply gradient ---
        result = list(pixels)
        
        for y in range(height):
            for x in range(width):
                idx = (y * width + x) * 4
                
                alpha = result[idx + 3]
                if alpha <= 0:
                    continue
                
                # Transform pixel to LOCAL coordinates (undo font rotation)
                dx = x - cx
                dy = y - cy
                local_x = dx * font_cos - dy * font_sin
                local_y = dx * font_sin + dy * font_cos
                
                # Offset from local center
                lx = local_x - local_cx
                ly = local_y - local_cy
                
                # Calculate gradient factor
                if gradient_type == 'LINEAR':
                    rot_x = lx * grad_cos + ly * grad_sin
                    t = (rot_x - min_p) / span
                else:  # RADIAL
                    dist = math.sqrt(lx * lx + ly * ly)
                    t = dist / max_dist
                
                # Clamp t
                t = max(0.0, min(1.0, t))
                
                # Sample LUT
                lut_index = int(t * (lut_len - 1))
                color = lut[lut_index]
                
                # Apply gradient color while preserving luminance and alpha from original
                orig_lum = result[idx]  # Original was rendered white
                
                result[idx] = color[0] * orig_lum
                result[idx + 1] = color[1] * orig_lum
                result[idx + 2] = color[2] * orig_lum
                # Alpha stays the same
        
        return result



def blend_pixel(pixels, idx, tr, tg, tb, ta, mode):
    """
    Blend source pixel (tr, tg, tb, ta) onto destination pixels[idx] using 'mode'.
    Modes correspond to Blender Brush Blend modes.
    """
    # Destination pixel
    dr = pixels[idx]
    dg = pixels[idx + 1]
    db = pixels[idx + 2]
    da = pixels[idx + 3]

    # Pre-calculations
    # For standard alpha blending ('MIX'), we typically use:
    # out = src * src_a + dst * (1 - src_a)
    # But here 'tr, tg, tb' are straight color, 'ta' is alpha. 
    # 'pixels' is presumably premultiplied or straight? 
    # Blender Internal Images are generally Straight Alpha (unassociated).
    # So we do mixing in straight space usually.
    
    out_r, out_g, out_b, out_a = dr, dg, db, da

    if mode == 'MIX':
        # Standard Alpha Blending (Source Over)
        # out = col * alpha + dst * (1 - alpha)
        # alpha = src_a + dst_a * (1 - src_a)
        inv_ta = 1.0 - ta
        out_r = tr * ta + dr * inv_ta
        out_g = tg * ta + dg * inv_ta
        out_b = tb * ta + db * inv_ta
        out_a = ta + da * inv_ta

    elif mode == 'ADD':
        # Additive blending
        # out = dst + src * alpha
        out_r = min(1.0, dr + tr * ta)
        out_g = min(1.0, dg + tg * ta)
        out_b = min(1.0, db + tb * ta)
        out_a = min(1.0, da + ta) # ? Actually usually alpha just accumulates or stays max.

    elif mode == 'SUBTRACT':
        # Subtractive
        out_r = max(0.0, dr - tr * ta)
        out_g = max(0.0, dg - tg * ta)
        out_b = max(0.0, db - tb * ta)
        out_a = da # Alpha generally unaffected or mixed? Let's keep destination alpha.

    elif mode == 'MULTIPLY':
        # Multiply
        # out = dst * (1 - alpha) + (dst * src) * alpha
        # = dst * (1 - alpha + src * alpha)
        # Standard multiply blend in composition:
        inv_ta = 1.0 - ta
        out_r = dr * (inv_ta + tr * ta)
        out_g = dg * (inv_ta + tg * ta)
        out_b = db * (inv_ta + tb * ta)
        out_a = da # Usually alpha shouldn't reduce? 'Mix' logic for alpha: out_a = ta + da*(1-ta)
        out_a = ta + da * inv_ta

    elif mode == 'LIGHTEN':
        # Lighten: max(dst, src)
        # Mixed with alpha
        target_r = max(dr, tr)
        target_g = max(dg, tg)
        target_b = max(db, tb)
        inv_ta = 1.0 - ta
        out_r = target_r * ta + dr * inv_ta
        out_g = target_g * ta + dg * inv_ta
        out_b = target_b * ta + db * inv_ta
        out_a = ta + da * inv_ta

    elif mode == 'DARKEN':
        # Darken: min(dst, src)
        target_r = min(dr, tr)
        target_g = min(dg, tg)
        target_b = min(db, tb)
        inv_ta = 1.0 - ta
        out_r = target_r * ta + dr * inv_ta
        out_g = target_g * ta + dg * inv_ta
        out_b = target_b * ta + db * inv_ta
        out_a = ta + da * inv_ta
        
    elif mode == 'ERASE_ALPHA':
        # Erase Alpha: Reduce dst alpha by src alpha
        out_a = max(0.0, da - ta)
        # Color remains destination color (but will be invisible if alpha 0)
    
    elif mode == 'ADD_ALPHA':
        # Add Alpha
        out_a = min(1.0, da + ta)
    
    else:
        # Fallback to MIX
        inv_ta = 1.0 - ta
        out_r = tr * ta + dr * inv_ta
        out_g = tg * ta + dg * inv_ta
        out_b = tb * ta + db * inv_ta
        out_a = ta + da * inv_ta

    pixels[idx] = out_r
    pixels[idx + 1] = out_g
    pixels[idx + 2] = out_b
    pixels[idx + 3] = out_a

# ----------------------------
# Texture Refresh Helper
# ----------------------------
def force_texture_refresh(context, image):
    """Force the 3D viewport to refresh the texture after modification."""
    if not image:
        return

    image.update()
    
    # Toggle image node property to force material update
    # This acts as a 'touch' to tell the dependency graph something changed on the node
    # which usually triggers a GPU texture reload for the viewport.
    
    # Strategy: Find materials using this image and toggle interpolation
    # We scan all materials in data to cover all objects.
    # Note: Scanning all materials might be slow in huge scenes.
    # Optimization: Scan only materials on visible objects or just the active object if possible.
    # But for Image Editor tool, we don't know which object uses it.
    # Let's try to find usage in current context if possible, or scan common usage.
    
    # A safer/faster approach for specific context:
    # If in 3D Viewport, we know the active object.
    # If in Image Editor, we assume user wants to see it on objects in the scene.
    
    # Let's iterate over visible objects in the current view layer.
    if context.view_layer:
        for obj in context.view_layer.objects.values():
            if obj.type == 'MESH' and obj.visible_get():
                if obj.active_material and obj.active_material.use_nodes:
                    mat = obj.active_material
                    for node in mat.node_tree.nodes:
                        if node.type == 'TEX_IMAGE' and node.image == image:
                            current = node.interpolation
                            # Toggle
                            node.interpolation = 'Closest' if current != 'Closest' else 'Linear'
                            node.interpolation = current
                            break  # Found the node, move to next object
    
    # Tag all 3D viewports for redraw
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

# ----------------------------
# Shared State
# ----------------------------
cursor_pos = None
show_cursor = False
cursor_pixel_scale = 1.0

# Gradient Tool preview state
gradient_preview_start = None  # (x, y) screen coordinates
gradient_preview_end = None    # (x, y) screen coordinates

# Crop Tool preview state
crop_preview_start = None  # (x, y) screen coordinates
crop_preview_end = None    # (x, y) screen coordinates

# Clone Tool state
clone_source_pos = None    # (x, y) screen coordinates - source point
clone_cursor_pos = None    # (x, y) screen coordinates - current brush position
clone_source_set = False   # Whether source has been set

# Path Tool state
path_points = []           # List of (x, y) control points in screen coordinates
path_cursor_pos = None     # Current cursor position

# ----------------------------
# Image Undo/Redo Stack
# ----------------------------
class ImageUndoStack:
    """Manages undo/redo history for image pixel modifications.
    
    Blender's built-in undo system does NOT track direct pixel modifications,
    so we need a custom undo stack for text paint operations.
    """
    
    _instance = None
    
    def __init__(self, max_undo_steps=20):
        # Dictionary: image_name -> {"undo": [...], "redo": [...]}
        self._stacks = {}
        self.max_undo_steps = max_undo_steps
    
    @classmethod
    def get(cls):
        if cls._instance is None:
            cls._instance = ImageUndoStack()
        return cls._instance
    
    def _get_stack(self, image_name):
        """Get or create the undo/redo stack for an image."""
        if image_name not in self._stacks:
            self._stacks[image_name] = {"undo": [], "redo": []}
        return self._stacks[image_name]
    
    def push_state(self, image):
        """Save current image state before modification."""
        if image is None:
            return
        
        stack = self._get_stack(image.name)
        
        # Save current pixels as an array (much faster than list)
        width, height = image.size
        num_pixels = width * height * 4
        
        # Create float array
        pixels = array.array('f', [0.0] * num_pixels)
        image.pixels.foreach_get(pixels)
        
        stack["undo"].append({
            "pixels": pixels,
            "size": (width, height)
        })
        
        # Clear redo stack when new action is performed
        stack["redo"].clear()
        
        # Limit undo history size
        while len(stack["undo"]) > self.max_undo_steps:
            stack["undo"].pop(0)
    
    def push_state_from_array(self, image, pixels_array):
        """Save pre-cached pixel array as undo state (for realtime preview)."""
        if image is None or pixels_array is None:
            return
        
        stack = self._get_stack(image.name)
        width, height = image.size
        
        # Make a copy of the array
        pixels_copy = array.array('f', pixels_array)
        
        stack["undo"].append({
            "pixels": pixels_copy,
            "size": (width, height)
        })
        
        stack["redo"].clear()
        
        while len(stack["undo"]) > self.max_undo_steps:
            stack["undo"].pop(0)
    
    def undo(self, image):
        """Restore previous image state (including size changes from crop)."""
        if image is None:
            return False
        
        stack = self._get_stack(image.name)
        
        if not stack["undo"]:
            return False
        
        # Save current state to redo stack
        width, height = image.size
        num_pixels = width * height * 4
        current_pixels = array.array('f', [0.0] * num_pixels)
        image.pixels.foreach_get(current_pixels)
        
        stack["redo"].append({
            "pixels": current_pixels,
            "size": (width, height)
        })
        
        # Restore previous state
        state = stack["undo"].pop()
        old_width, old_height = state["size"]
        
        # Handle size change (from crop operations)
        if (old_width, old_height) != (width, height):
            image.scale(old_width, old_height)
        
        # Fast restore
        image.pixels.foreach_set(state["pixels"])
        image.update()
        return True
    
    def redo(self, image):
        """Restore next image state (including size changes from crop)."""
        if image is None:
            return False
        
        stack = self._get_stack(image.name)
        
        if not stack["redo"]:
            return False
        
        # Save current state to undo stack
        width, height = image.size
        num_pixels = width * height * 4
        current_pixels = array.array('f', [0.0] * num_pixels)
        image.pixels.foreach_get(current_pixels)
        
        stack["undo"].append({
            "pixels": current_pixels,
            "size": (width, height)
        })
        
        # Restore next state
        state = stack["redo"].pop()
        new_width, new_height = state["size"]
        
        # Handle size change (from crop operations)
        if (new_width, new_height) != (width, height):
            image.scale(new_width, new_height)
        
        image.pixels.foreach_set(state["pixels"])
        image.update()
        return True
    
    def can_undo(self, image):
        if image is None:
            return False
        return len(self._get_stack(image.name)["undo"]) > 0
    
    def can_redo(self, image):
        if image is None:
            return False
        return len(self._get_stack(image.name)["redo"]) > 0
    
    def clear(self, image=None):
        if image is None:
            self._stacks.clear()
        elif image.name in self._stacks:
            del self._stacks[image.name]


# ----------------------------
# Text Preview Cache
# ----------------------------
class TextPreviewCache:
    """Cache for text preview to avoid re-rendering on every frame."""
    
    _instance = None
    PREVIEW_IMAGE_NAME = "_TextTool_Preview_"
    
    def __init__(self):
        self.blender_image = None
        self.gpu_texture = None
        self.preview_width = 0
        self.preview_height = 0
        # Cache key to detect when settings change
        self.cache_key = None
    
    @classmethod
    def get(cls):
        if cls._instance is None:
            cls._instance = TextPreviewCache()
        return cls._instance
    
    def _make_cache_key(self, text, font_path, font_size, color, rotation, gradient_data):
        """Create a hashable key from current settings."""
        # Color is a tuple/list, convert to tuple for hashing
        color_key = tuple(round(c, 3) for c in color)
        
        # Hash gradient data
        grad_key = None
        if gradient_data:
            grad_key = (
                gradient_data.get('type', 'LINEAR'),
                tuple(tuple(round(c, 3) for c in col) for col in gradient_data.get('lut', [])),
                gradient_data.get('angle', 0.0)
            )
        
        return (text, font_path, font_size, color_key, round(rotation, 2), grad_key)
    
    def update_preview(self, text, font_path, font_size, color, rotation, gradient_data=None):
        """Update the preview texture if settings have changed."""
        if not text:
            return False
        
        new_key = self._make_cache_key(text, font_path, font_size, color, rotation, gradient_data)
        
        # Check if we need to regenerate
        if new_key == self.cache_key and self.gpu_texture is not None:
            return True  # Already up to date
        
        # Generate new preview image using native rendering
        rotation_degrees = math.degrees(rotation) if isinstance(rotation, float) else rotation
        
        pixels, size = FontManager.create_text_image(
            text, font_path, font_size, color, 
            rotation_degrees=rotation_degrees,
            gradient_lut=gradient_data
        )
        
        if pixels is None or size is None:
            self.invalidate()
            return False
        
        self.preview_width, self.preview_height = size
        
        # Create or update Blender image
        try:
            # Remove old preview image if exists with different size
            if self.PREVIEW_IMAGE_NAME in bpy.data.images:
                old_img = bpy.data.images[self.PREVIEW_IMAGE_NAME]
                if old_img.size[0] != self.preview_width or old_img.size[1] != self.preview_height:
                    bpy.data.images.remove(old_img)
                    self.blender_image = None
                    self.gpu_texture = None
            
            # Create new image if needed
            if self.PREVIEW_IMAGE_NAME not in bpy.data.images:
                self.blender_image = bpy.data.images.new(
                    self.PREVIEW_IMAGE_NAME,
                    width=self.preview_width,
                    height=self.preview_height,
                    alpha=True
                )
                self.blender_image.colorspace_settings.name = 'sRGB'
            else:
                self.blender_image = bpy.data.images[self.PREVIEW_IMAGE_NAME]
            
            # Set pixels directly (already in correct format from GPUOffScreen)
            # GPUOffScreen reads bottom-up which matches Blender's image format
            self.blender_image.pixels.foreach_set(pixels)
            self.blender_image.update()
            
            # Force recreate GPU texture after every pixel update
            # The texture must be recreated to reflect updated pixel data
            self.gpu_texture = gpu.texture.from_image(self.blender_image)
            
            self.cache_key = new_key
            return True
            
        except Exception as e:
            print(f"[TextTool] Failed to create preview texture: {e}")
            import traceback
            traceback.print_exc()
            self.invalidate()
            return False
    
    def invalidate(self):
        """Clear the cache."""
        self.gpu_texture = None
        self.preview_width = 0
        self.preview_height = 0
        self.cache_key = None
        # Don't remove the Blender image here to avoid issues during drawing
    
    def get_texture_and_size(self):
        """Return the GPU texture and its size."""
        return self.gpu_texture, self.preview_width, self.preview_height
    
    def cleanup(self):
        """Remove the preview image from Blender. Call on addon unregister."""
        if self.PREVIEW_IMAGE_NAME in bpy.data.images:
            bpy.data.images.remove(bpy.data.images[self.PREVIEW_IMAGE_NAME])
        self.blender_image = None
        self.gpu_texture = None
