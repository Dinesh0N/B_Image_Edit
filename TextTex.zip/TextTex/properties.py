import bpy
from bpy.types import PropertyGroup
from bpy.props import StringProperty, IntProperty, EnumProperty, BoolProperty, FloatVectorProperty, FloatProperty, PointerProperty
from . import utils

def update_gradient_init(self, context):
    """Ensure gradient node tree exists when gradient is enabled."""
    if self.use_gradient:
        # This creates the node tree if missing, which is safe in an operator/update loop
        # but not in a draw loop. By doing it here, we ensure ui.py finds it ready.
        try:
            utils.get_gradient_node()
        except Exception as e:
            print(f"Error initializing gradient node: {e}")

class TextTexProperties(PropertyGroup):
    text: StringProperty(
        name="Text",
        description="Text to paint",
        default="Text"
    )
    font_file: PointerProperty(
        name="Font",
        description="Font to use",
        type=bpy.types.VectorFont
    )
    font_size: IntProperty(
        name="Font Size",
        description="TTF/OTF font size (pixels)",
        default=64,
        min=8,
        max=512
    )
    color: FloatVectorProperty(
        name="Color",
        description="Text color",
        default=(1.0, 1.0, 1.0, 1.0),
        min=0.0,
        max=1.0,
        size=4,
        subtype='COLOR'
    )

    center_text: BoolProperty(
        name="Center Text",
        description="Center text at click position",
        default=True
    )
    rotation: FloatProperty(
        name="Rotation",
        description="Text rotation in degrees (counter-clockwise)",
        default=0.0,
        min=0.0,
        max=360.0,
        subtype='ANGLE'
    )
    align_to_view: BoolProperty(
        name="Align to View",
        description="Align text rotation to viewport camera (uncheck for UV/3D alignment)",
        default=True
    )
    projection_mode: EnumProperty(
        name="Projection",
        description="How text is projected onto the surface",
        items=[
            ('UV', "UV-Based", "Place text at UV coordinates (fast)"),
            ('VIEW', "3D Projected", "Project text from view like brush strokes (accurate)"),
        ],
        default='VIEW'
    )
    
    # Gradient properties
    use_gradient: BoolProperty(
        name="Use Gradient",
        description="Use gradient instead of solid color",
        default=False,
        update=update_gradient_init
    )
    gradient_type: EnumProperty(
        name="Gradient Type",
        description="Type of gradient to apply",
        items=[
            ('LINEAR', "Linear", "Linear gradient from left to right"),
            ('RADIAL', "Radial", "Radial gradient from center outward"),
        ],
        default='LINEAR'
    )
    gradient_rotation: FloatProperty(
        name="Gradient Rotation",
        description="Rotation of the gradient in degrees",
        default=0.0,
        min=0.0,
        max=360.0
    )
    
    # Outline properties
    use_outline: BoolProperty(
        name="Use Outline",
        description="Add outline/stroke around text",
        default=False
    )
    outline_color: FloatVectorProperty(
        name="Outline Color",
        description="Color of the text outline",
        default=(0.0, 0.0, 0.0, 1.0),
        min=0.0,
        max=1.0,
        size=4,
        subtype='COLOR'
    )
    outline_size: IntProperty(
        name="Outline Size",
        description="Thickness of the text outline in pixels",
        default=2,
        min=1,
        max=20
    )
    
    # Crop Tool properties
    crop_show_thirds: BoolProperty(
        name="Show Rule of Thirds",
        description="Display rule of thirds grid overlay on crop selection",
        default=True
    )
    crop_lock_aspect: BoolProperty(
        name="Lock Aspect Ratio",
        description="Constrain crop selection to specified aspect ratio",
        default=False
    )
    crop_aspect_width: FloatProperty(
        name="Width",
        description="Aspect ratio width component",
        default=16.0,
        min=0.1,
        max=100.0
    )
    crop_aspect_height: FloatProperty(
        name="Height",
        description="Aspect ratio height component",
        default=9.0,
        min=0.1,
        max=100.0
    )
    
    # Clone Tool properties
    clone_brush_size: IntProperty(
        name="Brush Size",
        description="Clone brush radius in pixels",
        default=50,
        min=1,
        max=500
    )
    clone_brush_hardness: FloatProperty(
        name="Hardness",
        description="Edge falloff (1.0 = hard edge, 0.0 = soft edge)",
        default=0.8,
        min=0.0,
        max=1.0
    )
    
    # Path Tool properties
    path_mode: EnumProperty(
        name="Mode",
        description="Path rendering mode",
        items=[
            ('PAINT', "Paint", "Stamp pattern at intervals along curve"),
            ('RIBBON', "Ribbon", "Continuous deformed strip along curve"),
        ],
        default='RIBBON'
    )
    path_width: IntProperty(
        name="Width",
        description="Width of the path/ribbon in pixels",
        default=50,
        min=5,
        max=500
    )
    path_spacing: FloatProperty(
        name="Spacing",
        description="Spacing between stamps in Paint mode (as multiplier of width)",
        default=1.0,
        min=0.1,
        max=5.0
    )
    path_pattern: PointerProperty(
        name="Pattern",
        description="Pattern image to use along the path",
        type=bpy.types.Image
    )
