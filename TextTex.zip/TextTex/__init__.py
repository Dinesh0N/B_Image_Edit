bl_info = {
    "name": "Text Tool",
    "author": "Dinesh007",
    "version": (1, 0, 0),
    "blender": (5, 0, 0),
    "location": "Texture Paint Mode > Toolbar & Image Editor Paint Mode",
    "description": "Paints text to images using TTF/OTF fonts with Blender's native blf rendering.",
    "category": "Paint",
}

import bpy
from . import properties
from . import preferences
from . import ui
from . import operators
from . import sync

classes = (
    properties.TextTexProperties,
    *preferences.preference_classes,
    operators.TEXTURE_PAINT_OT_input_text,
    operators.TEXTURE_PAINT_OT_refresh_fonts,
    operators.TEXTURE_PAINT_OT_text_tool,
    operators.IMAGE_PAINT_OT_text_tool,
    operators.TEXTURE_PAINT_OT_gradient_tool,
    operators.IMAGE_PAINT_OT_gradient_tool,
    operators.IMAGE_PAINT_OT_crop_tool,
    operators.IMAGE_PAINT_OT_clone_tool,
    operators.IMAGE_PAINT_OT_path_tool,
    operators.TEXTTOOL_OT_undo,
    operators.TEXTTOOL_OT_redo,
    operators.TEXTTOOL_OT_adjust_font_size,
    operators.TEXTTOOL_OT_adjust_rotation,
)

_addon_keymaps = []

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.text_tool_properties = bpy.props.PointerProperty(type=properties.TextTexProperties)
    bpy.utils.register_tool(ui.TextTool, separator=True, group=False)
    bpy.utils.register_tool(ui.GradientTool, separator=False, group=False)
    bpy.utils.register_tool(ui.ImageTextTool, separator=True, group=False)
    bpy.utils.register_tool(ui.ImageGradientTool, separator=False, group=False)
    bpy.utils.register_tool(ui.ImageCropTool, separator=False, group=False)
    bpy.utils.register_tool(ui.ImageCloneTool, separator=False, group=False)
    bpy.utils.register_tool(ui.ImagePathTool, separator=False, group=False)
    
    if not bpy.app.timers.is_registered(sync.sync_tool_timer):
        bpy.app.timers.register(sync.sync_tool_timer)
    
    # Register keymaps for undo/redo
    wm = bpy.context.window_manager
    if wm.keyconfigs.addon:
        # Texture Paint mode keymap
        km = wm.keyconfigs.addon.keymaps.new(name='Texture Paint', space_type='EMPTY')
        kmi = km.keymap_items.new('texttool.undo', 'Z', 'PRESS', ctrl=True)
        _addon_keymaps.append((km, kmi))
        kmi = km.keymap_items.new('texttool.redo', 'Z', 'PRESS', ctrl=True, shift=True)
        _addon_keymaps.append((km, kmi))
        # Font Size: F key
        kmi = km.keymap_items.new('texttool.adjust_font_size', 'F', 'PRESS')
        _addon_keymaps.append((km, kmi))
        # Rotation: Ctrl+F key
        kmi = km.keymap_items.new('texttool.adjust_rotation', 'F', 'PRESS', ctrl=True)
        _addon_keymaps.append((km, kmi))
        
        # Image Paint mode keymap
        km = wm.keyconfigs.addon.keymaps.new(name='Image Paint', space_type='EMPTY')
        kmi = km.keymap_items.new('texttool.undo', 'Z', 'PRESS', ctrl=True)
        _addon_keymaps.append((km, kmi))
        kmi = km.keymap_items.new('texttool.redo', 'Z', 'PRESS', ctrl=True, shift=True)
        _addon_keymaps.append((km, kmi))
        # Font Size: F key
        kmi = km.keymap_items.new('texttool.adjust_font_size', 'F', 'PRESS')
        _addon_keymaps.append((km, kmi))
        # Rotation: Ctrl+F key
        kmi = km.keymap_items.new('texttool.adjust_rotation', 'F', 'PRESS', ctrl=True)
        _addon_keymaps.append((km, kmi))
        # Clone Tool: Ctrl+LMB (sets source and starts cloning)
        kmi = km.keymap_items.new('image_paint.clone_tool', 'LEFTMOUSE', 'PRESS', ctrl=True)
        _addon_keymaps.append((km, kmi))

def unregister():
    # Unregister keymaps
    for km, kmi in _addon_keymaps:
        km.keymap_items.remove(kmi)
    _addon_keymaps.clear()
    
    if bpy.app.timers.is_registered(sync.sync_tool_timer):
        try:
            bpy.app.timers.unregister(sync.sync_tool_timer)
        except ValueError:
            pass

    bpy.utils.unregister_tool(ui.ImagePathTool)
    bpy.utils.unregister_tool(ui.ImageCloneTool)
    bpy.utils.unregister_tool(ui.ImageCropTool)
    bpy.utils.unregister_tool(ui.ImageGradientTool)
    bpy.utils.unregister_tool(ui.ImageTextTool)
    bpy.utils.unregister_tool(ui.GradientTool)
    bpy.utils.unregister_tool(ui.TextTool)
    del bpy.types.Scene.text_tool_properties
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
        
    from . import utils
    utils.TextPreviewCache.get().cleanup()
    utils.ImageUndoStack.get().clear()
