import bpy
import os
import gpu
import blf
import math
from gpu_extras.batch import batch_for_shader
from bpy.types import Panel, WorkSpaceTool
from . import utils

# ----------------------------
# Text Preview Drawing
# ----------------------------

# Shader for drawing textured quads with alpha
_preview_shader = None

def _get_preview_shader():
    """Get or create the shader for drawing text preview with alpha."""
    global _preview_shader
    if _preview_shader is None:
        # Try available shaders in order of preference
        shader_names = ['IMAGE', '2D_IMAGE', 'IMAGE_SCENE_LINEAR_TO_REC709_SRGB']
        for shader_name in shader_names:
            try:
                _preview_shader = gpu.shader.from_builtin(shader_name)
                break
            except:
                continue
    return _preview_shader


def _draw_text_preview_direct(x, y, for_image_editor=False):
    """Draw the text preview at cursor position using direct blf rendering."""
    context = bpy.context
    if not hasattr(context.scene, "text_tool_properties"):
        return False
    
    props = context.scene.text_tool_properties
    
    if not props.text:
        return False
    
    # Get font ID
    font_path = props.font_file.filepath if props.font_file else None
    font_id = utils._get_blf_font_id(font_path)
    
    # Set font size - for image editor, scale by zoom level
    font_size = props.font_size
    if for_image_editor:
        try:
            sima = context.space_data
            if sima.type == 'IMAGE_EDITOR' and sima.image:
                i_width, i_height = sima.image.size
                if i_width > 0:
                    region = context.region
                    cx = region.width / 2
                    cy = region.height / 2
                    v0 = region.view2d.region_to_view(cx, cy)
                    v1 = region.view2d.region_to_view(cx + 100, cy)
                    
                    dist_view_x = v1[0] - v0[0]
                    if abs(dist_view_x) > 0.000001:
                        img_subset_pixels = dist_view_x * i_width
                        scale = 100.0 / img_subset_pixels
                        font_size = int(props.font_size * scale)
        except Exception:
            pass
    
    # Clamp font size to reasonable bounds
    font_size = max(8, min(font_size, 500))
    
    blf.size(font_id, font_size)
    
    # Get text dimensions
    text_width, text_height = blf.dimensions(font_id, props.text)
    
    # Calculate position (centered if center_text is enabled)
    if props.center_text:
        draw_x = x - text_width / 2
        draw_y = y - text_height / 2
    else:
        draw_x = x
        draw_y = y
    
    # Set text color
    if props.use_gradient:
        # If gradient is enabled, just show white in preview for now
        # (It would be expensive to sample gradient for every pixel in blf)
        r, g, b, a = 1.0, 1.0, 1.0, 1.0
    else:
        r, g, b = props.color[0], props.color[1], props.color[2]
        a = props.color[3] if len(props.color) > 3 else 1.0
    blf.color(font_id, r, g, b, a)
    
    # Apply rotation if needed
    # props.rotation is in radians
    if props.rotation != 0.0:
        blf.enable(font_id, blf.ROTATION)
        blf.rotation(font_id, props.rotation)
        
        # For rotated text centered on cursor:
        # blf rotates around the position point, so we need to calculate
        # where to put the origin so the text center ends up at (x, y)
        if props.center_text:
            # Calculate the offset from center to origin in rotated space
            # Origin is at bottom-left of text. Center offset is (-w/2, -h/2)
            # We need to rotate this offset and add to cursor position
            cos_r = math.cos(props.rotation)
            sin_r = math.sin(props.rotation)
            offset_x = -text_width / 2
            offset_y = -text_height / 2
            # Rotate the offset
            rotated_offset_x = offset_x * cos_r - offset_y * sin_r
            rotated_offset_y = offset_x * sin_r + offset_y * cos_r
            blf.position(font_id, x + rotated_offset_x, y + rotated_offset_y, 0)
        else:
            blf.position(font_id, draw_x, draw_y, 0)
    else:
        blf.position(font_id, draw_x, draw_y, 0)
    
    # Draw the text
    blf.draw(font_id, props.text)
    
    # Disable rotation after drawing
    if props.rotation != 0.0:
        blf.disable(font_id, blf.ROTATION)
    
    return True


def _draw_text_preview(x, y, for_image_editor=False):
    """Draw the text preview at cursor position."""
    # Use direct blf rendering for preview (more reliable than texture-based)
    return _draw_text_preview_direct(x, y, for_image_editor)


def _draw_crosshair(x, y, color, size=15):
    """Draw a simple crosshair at the given position."""
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    
    coords = [(x - size, y), (x + size, y)]
    batch = batch_for_shader(shader, 'LINES', {"pos": coords})
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)

    coords = [(x, y - size), (x, y + size)]
    batch = batch_for_shader(shader, 'LINES', {"pos": coords})
    batch.draw(shader)


def draw_cursor_callback_3d():
    """Draw text preview for 3D Viewport texture paint mode."""
    if not utils.show_cursor or not utils.cursor_pos:
        return
    
    x, y = utils.cursor_pos
    
    # Draw crosshair first (behind the preview)
    _draw_crosshair(x, y, (1.0, 1.0, 1.0, 0.5), size=20)
    
    # Draw text preview
    preview_drawn = _draw_text_preview(x, y, for_image_editor=False)
    
    # If preview failed, show text label as fallback
    if not preview_drawn:
        context = bpy.context
        if hasattr(context.scene, "text_tool_properties"):
            props = context.scene.text_tool_properties
            if props.text:
                font_id = 0
                blf.position(font_id, x + 25, y + 10, 0)
                blf.size(font_id, 14)
                blf.color(font_id, 1.0, 1.0, 0.0, 0.8)
                blf.draw(font_id, f"'{props.text}'")


def draw_cursor_callback_image():
    """Draw text preview for Image Editor paint mode."""
    if not utils.show_cursor or not utils.cursor_pos:
        return
    
    x, y = utils.cursor_pos
    
    # Draw crosshair first (behind the preview)
    _draw_crosshair(x, y, (1.0, 0.2, 0.2, 0.7), size=15)
    
    # Draw text preview
    preview_drawn = _draw_text_preview(x, y, for_image_editor=True)
    
    # If preview failed, show text label as fallback
    if not preview_drawn:
        context = bpy.context
        if hasattr(context.scene, "text_tool_properties"):
            props = context.scene.text_tool_properties
            if props.text:
                font_id = 0
                blf.position(font_id, x + 20, y + 8, 0)
                blf.size(font_id, 12)
                blf.color(font_id, 1.0, 0.5, 0.0, 0.9)
                blf.draw(font_id, f"'{props.text}'")


# ----------------------------
# Gradient Preview Drawing
# ----------------------------
def draw_gradient_preview_3d():
    """Draw gradient line preview for 3D Viewport."""
    if utils.gradient_preview_start is None or utils.gradient_preview_end is None:
        return
    
    x1, y1 = utils.gradient_preview_start
    x2, y2 = utils.gradient_preview_end
    
    # Draw line
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    coords = [(x1, y1), (x2, y2)]
    batch = batch_for_shader(shader, 'LINES', {"pos": coords})
    
    gpu.state.blend_set('ALPHA')
    gpu.state.line_width_set(2.0)
    shader.bind()
    shader.uniform_float("color", (1.0, 1.0, 0.0, 0.8))
    batch.draw(shader)
    
    # Draw start circle
    _draw_circle(x1, y1, 8, (0.0, 1.0, 0.0, 0.8))
    # Draw end circle
    _draw_circle(x2, y2, 8, (1.0, 0.0, 0.0, 0.8))
    
    gpu.state.line_width_set(1.0)
    gpu.state.blend_set('NONE')


def draw_gradient_preview_image():
    """Draw gradient line preview for Image Editor."""
    if utils.gradient_preview_start is None or utils.gradient_preview_end is None:
        return
    
    x1, y1 = utils.gradient_preview_start
    x2, y2 = utils.gradient_preview_end
    
    # Draw line
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    coords = [(x1, y1), (x2, y2)]
    batch = batch_for_shader(shader, 'LINES', {"pos": coords})
    
    gpu.state.blend_set('ALPHA')
    gpu.state.line_width_set(2.0)
    shader.bind()
    shader.uniform_float("color", (1.0, 0.5, 0.0, 0.9))
    batch.draw(shader)
    
    # Draw start/end circles
    _draw_circle(x1, y1, 6, (0.0, 1.0, 0.0, 0.9))
    _draw_circle(x2, y2, 6, (1.0, 0.0, 0.0, 0.9))
    
    gpu.state.line_width_set(1.0)
    gpu.state.blend_set('NONE')


def _draw_circle(x, y, radius, color, segments=16):
    """Draw a circle at the given position."""
    import math
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    
    coords = []
    for i in range(segments):
        angle = 2.0 * math.pi * i / segments
        coords.append((x + radius * math.cos(angle), y + radius * math.sin(angle)))
    coords.append(coords[0])  # Close the circle
    
    batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": coords})
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)


# ----------------------------
# Crop Preview Drawing
# ----------------------------
def draw_crop_preview_image():
    """Draw crop selection rectangle for Image Editor with rule of thirds."""
    if utils.crop_preview_start is None or utils.crop_preview_end is None:
        return
    
    x1, y1 = utils.crop_preview_start
    x2, y2 = utils.crop_preview_end
    
    # Normalize coordinates
    min_x, max_x = min(x1, x2), max(x1, x2)
    min_y, max_y = min(y1, y2), max(y1, y2)
    
    # Draw rectangle outline
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    
    # Rectangle corners
    coords = [
        (min_x, min_y), (max_x, min_y),  # Bottom
        (max_x, min_y), (max_x, max_y),  # Right
        (max_x, max_y), (min_x, max_y),  # Top
        (min_x, max_y), (min_x, min_y),  # Left
    ]
    
    batch = batch_for_shader(shader, 'LINES', {"pos": coords})
    
    gpu.state.blend_set('ALPHA')
    gpu.state.line_width_set(2.0)
    shader.bind()
    shader.uniform_float("color", (1.0, 1.0, 1.0, 0.9))
    batch.draw(shader)
    
    # Draw rule of thirds grid if enabled
    context = bpy.context
    if hasattr(context.scene, "text_tool_properties"):
        props = context.scene.text_tool_properties
        if props.crop_show_thirds:
            width = max_x - min_x
            height = max_y - min_y
            
            if width > 10 and height > 10:
                thirds_coords = []
                # Vertical lines (1/3 and 2/3)
                thirds_coords.extend([(min_x + width / 3, min_y), (min_x + width / 3, max_y)])
                thirds_coords.extend([(min_x + 2 * width / 3, min_y), (min_x + 2 * width / 3, max_y)])
                # Horizontal lines (1/3 and 2/3)
                thirds_coords.extend([(min_x, min_y + height / 3), (max_x, min_y + height / 3)])
                thirds_coords.extend([(min_x, min_y + 2 * height / 3), (max_x, min_y + 2 * height / 3)])
                
                gpu.state.line_width_set(1.0)
                thirds_batch = batch_for_shader(shader, 'LINES', {"pos": thirds_coords})
                shader.uniform_float("color", (1.0, 1.0, 1.0, 0.4))
                thirds_batch.draw(shader)
    
    gpu.state.line_width_set(2.0)
    
    # Draw corner handles
    handle_size = 6
    for cx, cy in [(min_x, min_y), (max_x, min_y), (max_x, max_y), (min_x, max_y)]:
        handle_coords = [
            (cx - handle_size, cy - handle_size),
            (cx + handle_size, cy - handle_size),
            (cx + handle_size, cy + handle_size),
            (cx - handle_size, cy + handle_size),
        ]
        handle_batch = batch_for_shader(shader, 'TRI_FAN', {"pos": handle_coords})
        shader.uniform_float("color", (0.2, 0.6, 1.0, 0.9))
        handle_batch.draw(shader)
    
    # Draw edge handles (small rectangles at edge midpoints)
    edge_handle_size = 4
    edge_positions = [
        ((min_x + max_x) / 2, min_y),  # Bottom
        ((min_x + max_x) / 2, max_y),  # Top
        (min_x, (min_y + max_y) / 2),  # Left
        (max_x, (min_y + max_y) / 2),  # Right
    ]
    for ex, ey in edge_positions:
        edge_coords = [
            (ex - edge_handle_size, ey - edge_handle_size),
            (ex + edge_handle_size, ey - edge_handle_size),
            (ex + edge_handle_size, ey + edge_handle_size),
            (ex - edge_handle_size, ey + edge_handle_size),
        ]
        edge_batch = batch_for_shader(shader, 'TRI_FAN', {"pos": edge_coords})
        shader.uniform_float("color", (0.2, 0.8, 0.4, 0.9))
        edge_batch.draw(shader)
    
    gpu.state.line_width_set(1.0)
    gpu.state.blend_set('NONE')


# ----------------------------
# Clone Preview Drawing
# ----------------------------
def draw_clone_preview_image():
    """Draw clone tool brush cursor and source crosshair."""
    context = bpy.context
    if not hasattr(context.scene, "text_tool_properties"):
        return
    
    props = context.scene.text_tool_properties
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    
    gpu.state.blend_set('ALPHA')
    gpu.state.line_width_set(2.0)
    shader.bind()
    
    # Draw source crosshair if set
    if utils.clone_source_set and utils.clone_source_pos:
        sx, sy = utils.clone_source_pos
        size = 15
        
        # Crosshair lines
        cross_coords = [
            (sx - size, sy), (sx + size, sy),
            (sx, sy - size), (sx, sy + size),
        ]
        cross_batch = batch_for_shader(shader, 'LINES', {"pos": cross_coords})
        shader.uniform_float("color", (1.0, 0.3, 0.3, 0.9))
        cross_batch.draw(shader)
        
        # Small circle around crosshair
        _draw_circle(sx, sy, 8, (1.0, 0.3, 0.3, 0.7), segments=16)
    
    # Draw brush cursor at current position
    if utils.clone_cursor_pos:
        cx, cy = utils.clone_cursor_pos
        brush_size = props.clone_brush_size
        
        # Scale brush size based on image zoom
        try:
            sima = context.space_data
            if sima.type == 'IMAGE_EDITOR' and sima.image:
                i_width, i_height = sima.image.size
                if i_width > 0:
                    region = context.region
                    center_x = region.width / 2
                    v0 = region.view2d.region_to_view(center_x, 0)
                    v1 = region.view2d.region_to_view(center_x + 100, 0)
                    dist_view_x = v1[0] - v0[0]
                    if abs(dist_view_x) > 0.000001:
                        img_subset_pixels = dist_view_x * i_width
                        scale = 100.0 / img_subset_pixels
                        brush_size = int(props.clone_brush_size * scale)
        except:
            pass
        
        # Draw brush outline
        _draw_circle(cx, cy, brush_size, (0.2, 0.8, 1.0, 0.8), segments=32)
        
        # Draw inner circle for hardness indication
        inner_radius = brush_size * props.clone_brush_hardness
        if inner_radius > 2:
            _draw_circle(cx, cy, inner_radius, (0.2, 0.8, 1.0, 0.4), segments=32)
    
    gpu.state.line_width_set(1.0)
    gpu.state.blend_set('NONE')


# ----------------------------
# WorkSpace Tools
# ----------------------------
class ImageCloneTool(WorkSpaceTool):
    bl_space_type = 'IMAGE_EDITOR'
    bl_context_mode = 'PAINT'
    bl_idname = "image_paint.clone_tool"
    bl_label = "Clone Tool"
    bl_data_block = 'BRUSH'
    bl_description = "Clone pixels from one area to another (Ctrl+Click to set source)"
    bl_icon = "ops.gpencil.draw.eraser"
    bl_keymap = (
        ("image_paint.clone_tool", {"type": 'LEFTMOUSE', "value": 'PRESS'}, None),
    )

    def draw_settings(context, layout, tool):
        props = context.scene.text_tool_properties
        is_header = not layout.use_property_split
        
        if is_header:
            layout.prop(props, "clone_brush_size", text="Size")
            layout.prop(props, "clone_brush_hardness", text="Hard")
        else:
            layout.use_property_split = True
            layout.use_property_decorate = False
            col = layout.column()
            col.prop(props, "clone_brush_size")
            col.prop(props, "clone_brush_hardness")
            col.separator()
            if utils.clone_source_set:
                col.label(text="Source set - Click to paint", icon='CHECKMARK')
            else:
                col.label(text="Ctrl+Click to set source", icon='INFO')


# ----------------------------
# Path Preview Drawing
# ----------------------------
def draw_path_preview_image():
    """Draw path curve and control points."""
    if not utils.path_points and not utils.path_cursor_pos:
        return
    
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    gpu.state.blend_set('ALPHA')
    gpu.state.line_width_set(2.0)
    shader.bind()
    
    all_points = list(utils.path_points)
    if utils.path_cursor_pos and len(all_points) > 0:
        all_points.append(utils.path_cursor_pos)
    
    # Draw smooth curve if we have enough points
    if len(all_points) >= 2:
        # Generate interpolated curve points (Catmull-Rom style)
        curve_points = _interpolate_path(all_points, segments_per_span=10)
        
        if len(curve_points) >= 2:
            # Draw curve line
            line_coords = []
            for i in range(len(curve_points) - 1):
                line_coords.append(curve_points[i])
                line_coords.append(curve_points[i + 1])
            
            line_batch = batch_for_shader(shader, 'LINES', {"pos": line_coords})
            shader.uniform_float("color", (0.3, 0.7, 1.0, 0.9))
            line_batch.draw(shader)
    
    # Draw control points
    handle_size = 6
    for i, pt in enumerate(utils.path_points):
        px, py = pt
        # Draw filled circle
        _draw_circle(px, py, handle_size, (1.0, 1.0, 1.0, 0.9), segments=12, filled=True)
        # Draw outline
        _draw_circle(px, py, handle_size, (0.2, 0.5, 1.0, 1.0), segments=12)
    
    # Draw cursor preview point
    if utils.path_cursor_pos:
        cx, cy = utils.path_cursor_pos
        _draw_circle(cx, cy, 5, (1.0, 1.0, 0.5, 0.7), segments=12)
    
    gpu.state.line_width_set(1.0)
    gpu.state.blend_set('NONE')


def _interpolate_path(points, segments_per_span=10):
    """Interpolate path using Catmull-Rom spline for smooth curves."""
    if len(points) < 2:
        return points
    
    result = []
    
    for i in range(len(points) - 1):
        p0 = points[max(0, i - 1)]
        p1 = points[i]
        p2 = points[min(len(points) - 1, i + 1)]
        p3 = points[min(len(points) - 1, i + 2)]
        
        for t in range(segments_per_span):
            t_norm = t / segments_per_span
            
            # Catmull-Rom interpolation
            t2 = t_norm * t_norm
            t3 = t2 * t_norm
            
            x = 0.5 * ((2 * p1[0]) +
                       (-p0[0] + p2[0]) * t_norm +
                       (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 +
                       (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3)
            
            y = 0.5 * ((2 * p1[1]) +
                       (-p0[1] + p2[1]) * t_norm +
                       (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 +
                       (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)
            
            result.append((x, y))
    
    # Add final point
    result.append(points[-1])
    return result


class ImagePathTool(WorkSpaceTool):
    bl_space_type = 'IMAGE_EDITOR'
    bl_context_mode = 'PAINT'
    bl_idname = "image_paint.path_tool"
    bl_label = "Path Tool"
    bl_data_block = 'BRUSH'
    bl_description = "Draw patterns along a curve path"
    bl_icon = "ops.curve.draw"
    bl_keymap = (
        ("image_paint.path_tool", {"type": 'LEFTMOUSE', "value": 'PRESS'}, None),
    )

    def draw_settings(context, layout, tool):
        props = context.scene.text_tool_properties
        is_header = not layout.use_property_split
        
        if is_header:
            layout.prop(props, "path_mode", text="")
            layout.prop(props, "path_width", text="W")
        else:
            layout.use_property_split = True
            layout.use_property_decorate = False
            col = layout.column()
            col.prop(props, "path_mode")
            col.prop(props, "path_width")
            if props.path_mode == 'PAINT':
                col.prop(props, "path_spacing")
            col.separator()
            col.prop(props, "path_pattern")
            col.separator()
            col.label(text="Click to add points")
            col.label(text="Enter to apply, ESC to cancel")
            col.label(text="Backspace to remove last point")

class ImageCropTool(WorkSpaceTool):
    bl_space_type = 'IMAGE_EDITOR'
    bl_context_mode = 'PAINT'
    bl_idname = "image_paint.crop_tool"
    bl_label = "Crop Tool"
    bl_data_block = 'BRUSH'
    bl_description = "Crop the image by selecting a rectangular region"
    bl_icon = "ops.transform.resize"
    bl_keymap = (
        ("image_paint.crop_tool", {"type": 'LEFTMOUSE', "value": 'PRESS'}, None),
    )

    def draw_settings(context, layout, tool):
        props = context.scene.text_tool_properties
        is_header = not layout.use_property_split
        
        if is_header:
            layout.prop(props, "crop_show_thirds", text="", icon='MESH_GRID')
            layout.prop(props, "crop_lock_aspect", text="", icon='LOCKED' if props.crop_lock_aspect else 'UNLOCKED')
        else:
            layout.use_property_split = True
            layout.use_property_decorate = False
            col = layout.column()
            
            # Rule of thirds toggle
            col.prop(props, "crop_show_thirds")
            
            col.separator()
            
            # Aspect ratio section
            row = col.row(align=True)
            row.prop(props, "crop_lock_aspect", text="Lock Aspect Ratio")
            
            if props.crop_lock_aspect:
                box = col.box()
                row = box.row(align=True)
                row.prop(props, "crop_aspect_width", text="W")
                row.prop(props, "crop_aspect_height", text="H")
            
            col.separator()
            col.label(text="Drag handles to resize")
            col.label(text="Enter/Space to apply, ESC to cancel")

class GradientTool(WorkSpaceTool):
    bl_space_type = 'VIEW_3D'
    bl_context_mode = 'PAINT_TEXTURE'
    bl_idname = "texture_paint.gradient_tool"
    bl_label = "Gradient Tool"
    bl_data_block = 'BRUSH'
    bl_description = "Paint gradients on textures using click-drag"
    bl_icon = "ops.paint.weight_gradient"
    bl_keymap = (
        ("paint.gradient_tool", {"type": 'LEFTMOUSE', "value": 'PRESS'}, None),
    )

    def draw_settings(context, layout, tool):
        props = context.scene.text_tool_properties
        is_header = not layout.use_property_split
        
        if is_header:
            layout.prop(props, "gradient_type", text="")
        else:
            layout.use_property_split = True
            layout.use_property_decorate = False
            col = layout.column()
            col.prop(props, "gradient_type")
            
            # Color Ramp
            grad_node = utils.get_gradient_node()
            if grad_node:
                col.template_color_ramp(grad_node, "color_ramp", expand=True)
            
            # Blend Mode
            col.separator()
            if context.tool_settings.image_paint.brush:
                col.prop(context.tool_settings.image_paint.brush, "blend", text="Blend Mode")


class ImageGradientTool(WorkSpaceTool):
    bl_space_type = 'IMAGE_EDITOR'
    bl_context_mode = 'PAINT'
    bl_idname = "image_paint.gradient_tool"
    bl_label = "Gradient Tool"
    bl_data_block = 'BRUSH'
    bl_description = "Paint gradients on images using click-drag"
    bl_icon = "ops.paint.weight_gradient"
    bl_keymap = (
        ("image_paint.gradient_tool", {"type": 'LEFTMOUSE', "value": 'PRESS'}, None),
    )

    def draw_settings(context, layout, tool):
        props = context.scene.text_tool_properties
        is_header = not layout.use_property_split
        
        if is_header:
            layout.prop(props, "gradient_type", text="")
        else:
            layout.use_property_split = True
            layout.use_property_decorate = False
            col = layout.column()
            col.prop(props, "gradient_type")
            
            # Color Ramp
            grad_node = utils.get_gradient_node()
            if grad_node:
                col.template_color_ramp(grad_node, "color_ramp", expand=True)
            
            # Blend Mode
            col.separator()
            if context.tool_settings.image_paint.brush:
                col.prop(context.tool_settings.image_paint.brush, "blend", text="Blend Mode")


class TextTool(WorkSpaceTool):
    bl_space_type = 'VIEW_3D'
    bl_context_mode = 'PAINT_TEXTURE'
    bl_idname = "texture_paint.text_tool_ttf"
    bl_label = "Text Tool"
    bl_data_block = 'BRUSH'
    bl_description = "Paint text on textures with TTF/OTF font rendering"
    bl_icon = os.path.join(os.path.dirname(__file__), "icons", "ops.paint.text_tool")
    bl_keymap = (
        ("paint.text_tool_ttf", {"type": 'LEFTMOUSE', "value": 'PRESS'}, None),
    )

    def draw_settings(context, layout, tool):
        props = context.scene.text_tool_properties
        
        # Check if we're in header (compact) or side panel (full)
        is_header = not layout.use_property_split
        
        if is_header:
            # Header: compact horizontal layout
            # Header: compact horizontal layout
            layout.prop(props, "text", text="")
            layout.template_ID(props, "font_file", open="font.open")
            layout.separator()
            layout.prop(props, "color", text="")
            layout.separator()
            layout.prop(props, "font_size", text="Size")
            layout.separator()
            layout.prop(props, "rotation", text="Rotation")
        else:
            # Side panel: full vertical layout
            layout.use_property_split = True
            layout.use_property_decorate = False
            col = layout.column()
            col.prop(props, "text")
            row = col.row(align=True)
            row.template_ID(props, "font_file", open="font.open")
            row.operator("paint.refresh_fonts_ttf", text="", icon='FILE_REFRESH')
            col.prop(props, "font_size")
            
            # Color/Gradient tabs
            col.separator()
            row = col.row(align=True)
            row.prop(props, "use_gradient", text="Color", toggle=True, invert_checkbox=True)
            row.prop(props, "use_gradient", text="Gradient", toggle=True)
            
            if not props.use_gradient:
                # Solid color mode
                col.prop(props, "color")
            else:
                # Gradient mode
                box = col.box()
                box.prop(props, "gradient_type", text="Type")
                if props.gradient_type == 'LINEAR':
                    box.prop(props, "gradient_rotation", text="Rotation")
                
                # Native Color Ramp
                grad_node = utils.get_gradient_node()
                if grad_node:
                    box.template_color_ramp(grad_node, "color_ramp", expand=True)
                else:
                    box.label(text="Error loading gradient", icon="ERROR")
            
            col.separator()
            col.prop(props, "rotation")
            col.prop(props, "projection_mode")
            col.prop(props, "center_text")
            # Brush Blend Mode
            brush = context.tool_settings.image_paint.brush
            if brush:
                col.prop(brush, "blend", text="Blend Mode")
            
            # Outline section
            col.separator()
            col.prop(props, "use_outline")
            if props.use_outline:
                box = col.box()
                box.prop(props, "outline_color", text="Color")
                box.prop(props, "outline_size", text="Size")


class ImageTextTool(WorkSpaceTool):
    bl_space_type = 'IMAGE_EDITOR'
    bl_context_mode = 'PAINT'
    bl_idname = "image_paint.text_tool_ttf"
    bl_label = "Text Tool "
    bl_data_block = 'BRUSH'
    bl_description = "Paint text(TTF/OTF) directly on images"
    bl_icon = os.path.join(os.path.dirname(__file__), "icons", "ops.paint.text_tool")
    bl_keymap = (
        ("image_paint.text_tool_ttf", {"type": 'LEFTMOUSE', "value": 'PRESS'}, None),
    )

    def draw_settings(context, layout, tool):
        props = context.scene.text_tool_properties
        
        # Check if we're in header (compact) or side panel (full)
        is_header = not layout.use_property_split
        
        if is_header:
            # Header: compact horizontal layout
            # Header: compact horizontal layout
            layout.prop(props, "text", text="")
            layout.template_ID(props, "font_file", open="font.open")
            layout.separator()
            layout.prop(props, "color", text="")
            layout.separator()
            layout.prop(props, "font_size", text="Size")
            layout.separator()
            layout.prop(props, "rotation", text="Rotation")
        else:
            # Side panel: full vertical layout
            layout.use_property_split = True
            layout.use_property_decorate = False
            col = layout.column()
            col.prop(props, "text")
            row = col.row(align=True)
            row.template_ID(props, "font_file", open="font.open")
            row.operator("paint.refresh_fonts_ttf", text="", icon='FILE_REFRESH')
            col.prop(props, "font_size")
            
            # Color/Gradient tabs
            col.separator()
            row = col.row(align=True)
            row.prop(props, "use_gradient", text="Color", toggle=True, invert_checkbox=True)
            row.prop(props, "use_gradient", text="Gradient", toggle=True)
            
            if not props.use_gradient:
                # Solid color mode
                col.prop(props, "color")
            else:
                # Gradient mode
                box = col.box()
                box.prop(props, "gradient_type", text="Type")
                if props.gradient_type == 'LINEAR':
                    box.prop(props, "gradient_rotation", text="Rotation")
                
                # Native Color Ramp
                grad_node = utils.get_gradient_node()
                if grad_node:
                    box.template_color_ramp(grad_node, "color_ramp", expand=True)
                else:
                    box.label(text="Error loading gradient", icon="ERROR")
            
            col.separator()
            col.prop(props, "rotation")
            col.prop(props, "center_text")
            # Brush Blend Mode
            brush = context.tool_settings.image_paint.brush
            if brush:
                col.prop(brush, "blend", text="Blend Mode")
            
            # Outline section
            col.separator()
            col.prop(props, "use_outline")
            if props.use_outline:
                box = col.box()
                box.prop(props, "outline_color", text="Color")
                box.prop(props, "outline_size", text="Size")
