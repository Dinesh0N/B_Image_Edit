

bl_info = {
    "name": "Image Edit",
    "author": "akaneyu",
    "version": (1, 11, 0),
    "blender": (4, 2, 0),
    "location": "Image",
    "category": "Paint"}

if "bpy" in locals():
    import importlib
    importlib.reload(app)
    importlib.reload(api)
    importlib.reload(operators)
    importlib.reload(ui)
    importlib.reload(ui_renderer)
    importlib.reload(utils)

import bpy
from . import app
from . import api
from . import operators
from . import ui

classes = [
    app.IMAGE_EDITOR_PLUS_WindowPropertyGroup,
    app.IMAGE_EDITOR_PLUS_LayerPropertyGroup,
    app.IMAGE_EDITOR_PLUS_ImagePropertyGroup,
    operators.IMAGE_EDITOR_PLUS_OT_make_selection,
    operators.IMAGE_EDITOR_PLUS_OT_cancel_selection,
    operators.IMAGE_EDITOR_PLUS_OT_swap_colors,
    operators.IMAGE_EDITOR_PLUS_OT_fill_with_fg_color,
    operators.IMAGE_EDITOR_PLUS_OT_fill_with_bg_color,
    operators.IMAGE_EDITOR_PLUS_OT_clear,
    operators.IMAGE_EDITOR_PLUS_OT_cut,
    operators.IMAGE_EDITOR_PLUS_OT_copy,
    operators.IMAGE_EDITOR_PLUS_OT_paste,
    operators.IMAGE_EDITOR_PLUS_OT_cut_to_layer,
    operators.IMAGE_EDITOR_PLUS_OT_copy_to_layer,
    operators.IMAGE_EDITOR_PLUS_OT_add_image_layer,
    operators.IMAGE_EDITOR_PLUS_OT_new_image_layer,
    operators.IMAGE_EDITOR_PLUS_OT_crop,
    operators.IMAGE_EDITOR_PLUS_OT_deselect_layer,
    operators.IMAGE_EDITOR_PLUS_OT_move_layer,
    operators.IMAGE_EDITOR_PLUS_OT_delete_layer,
    operators.IMAGE_EDITOR_PLUS_OT_duplicate_layer,
    operators.IMAGE_EDITOR_PLUS_OT_lock_all_layers,
    operators.IMAGE_EDITOR_PLUS_OT_unlock_all_layers,
    operators.IMAGE_EDITOR_PLUS_OT_hide_all_layers,
    operators.IMAGE_EDITOR_PLUS_OT_show_all_layers,
    operators.IMAGE_EDITOR_PLUS_OT_delete_all_layers,
    operators.IMAGE_EDITOR_PLUS_OT_update_layer_previews,
    operators.IMAGE_EDITOR_PLUS_OT_select_all_layers,
    operators.IMAGE_EDITOR_PLUS_OT_deselect_all_layers,
    operators.IMAGE_EDITOR_PLUS_OT_invert_layer_selection,
    operators.IMAGE_EDITOR_PLUS_OT_delete_selected_layers,
    operators.IMAGE_EDITOR_PLUS_OT_merge_selected_layers,
    operators.IMAGE_EDITOR_PLUS_OT_change_image_layer_order,
    operators.IMAGE_EDITOR_PLUS_OT_merge_layers,
    operators.IMAGE_EDITOR_PLUS_OT_flip,
    operators.IMAGE_EDITOR_PLUS_OT_rotate,
    operators.IMAGE_EDITOR_PLUS_OT_scale,
    operators.IMAGE_EDITOR_PLUS_OT_change_canvas_size,
    operators.IMAGE_EDITOR_PLUS_OT_flip_layer,
    operators.IMAGE_EDITOR_PLUS_OT_rotate_layer,
    operators.IMAGE_EDITOR_PLUS_OT_rotate_layer_arbitrary,
    operators.IMAGE_EDITOR_PLUS_OT_scale_layer,
    operators.IMAGE_EDITOR_PLUS_OT_offset,
    ui.IMAGE_EDITOR_PLUS_OT_scale_dialog,
    ui.IMAGE_EDITOR_PLUS_OT_change_canvas_size_dialog,
    ui.IMAGE_EDITOR_PLUS_OffsetPropertyGroup,
    ui.IMAGE_EDITOR_PLUS_OT_offset_dialog,
    ui.IMAGE_EDITOR_PLUS_UL_layer_list,
    ui.IMAGE_EDITOR_PLUS_MT_edit_menu,
    ui.IMAGE_EDITOR_PLUS_MT_layers_menu,
    ui.IMAGE_EDITOR_PLUS_MT_layer_options_menu,
    ui.IMAGE_EDITOR_PLUS_MT_transform_menu,
    ui.IMAGE_EDITOR_PLUS_MT_transform_layer_menu,
    ui.IMAGE_EDITOR_PLUS_MT_offset_menu,
    ui.IMAGE_EDITOR_PLUS_PT_layers_panel,
    ui.IMAGE_EDITOR_PLUS_PT_transform_layer_panel,
    ui.IMAGE_EDITOR_PLUS_PT_offset_panel,
]

def register_keymaps():
    session = app.get_session()

    keymaps = session.keymaps

    wm = bpy.context.window_manager

    km = wm.keyconfigs.addon.keymaps.new(name='Image Generic', space_type='IMAGE_EDITOR')
    kmi = km.keymap_items.new(operators.IMAGE_EDITOR_PLUS_OT_make_selection.bl_idname,
            'B', 'PRESS')
    kmi = km.keymap_items.new(operators.IMAGE_EDITOR_PLUS_OT_cancel_selection.bl_idname,
            'D', 'PRESS', ctrl=True)
    kmi = km.keymap_items.new(operators.IMAGE_EDITOR_PLUS_OT_cut.bl_idname,
            'X', 'PRESS', ctrl=True)
    kmi = km.keymap_items.new(operators.IMAGE_EDITOR_PLUS_OT_copy.bl_idname,
            'C', 'PRESS', ctrl=True)
    kmi = km.keymap_items.new(operators.IMAGE_EDITOR_PLUS_OT_paste.bl_idname,
            'V', 'PRESS', ctrl=True)
    kmi = km.keymap_items.new(operators.IMAGE_EDITOR_PLUS_OT_fill_with_fg_color.bl_idname,
            'DEL', 'PRESS', ctrl=True)
    kmi = km.keymap_items.new(operators.IMAGE_EDITOR_PLUS_OT_clear.bl_idname,
            'DEL', 'PRESS')
    kmi = km.keymap_items.new(operators.IMAGE_EDITOR_PLUS_OT_move_layer.bl_idname,
            'G', 'PRESS')
    kmi = km.keymap_items.new(operators.IMAGE_EDITOR_PLUS_OT_rotate_layer_arbitrary.bl_idname,
            'R', 'PRESS')
    kmi = km.keymap_items.new(operators.IMAGE_EDITOR_PLUS_OT_scale_layer.bl_idname,
            'C', 'PRESS')

    keymaps.append(km)

def unregister_keymaps():
    session = app.get_session()

    wm = bpy.context.window_manager

    for km in session.keymaps:
        wm.keyconfigs.addon.keymaps.remove(km)

def register():
    global draw_handler


    api.API.VERSION = bl_info['version']

    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.IMAGE_MT_image.append(ui.menu_func)

    bpy.app.handlers.save_pre.append(app.save_pre_handler)

    draw_handler = bpy.types.SpaceImageEditor.draw_handler_add(
            app.draw_handler, (), 'WINDOW', 'POST_PIXEL')

    wm = bpy.types.WindowManager

    wm.imageeditorplus_api = api.API
    wm.imageeditorplus_properties = \
        bpy.props.PointerProperty(type=app.IMAGE_EDITOR_PLUS_WindowPropertyGroup)
    bpy.types.Image.imageeditorplus_properties = \
        bpy.props.PointerProperty(type=app.IMAGE_EDITOR_PLUS_ImagePropertyGroup)

    register_keymaps()
    
    # Register toolbar tool
    bpy.utils.register_tool(ui.IMAGE_EDITOR_PLUS_WT_box_select, after={"builtin.select_box"}, separator=True, group=False)

def unregister():
    global draw_handler

    app.cleanup_scene()

    for cls in classes:
        bpy.utils.unregister_class(cls)

    bpy.types.IMAGE_MT_image.remove(ui.menu_func)

    bpy.app.handlers.save_pre.remove(app.save_pre_handler)

    bpy.types.SpaceImageEditor.draw_handler_remove(draw_handler, 'WINDOW')

    wm = bpy.types.WindowManager

    del wm.imageeditorplus_properties
    del bpy.types.Image.imageeditorplus_properties

    unregister_keymaps()
    
    # Unregister toolbar tool
    bpy.utils.unregister_tool(ui.IMAGE_EDITOR_PLUS_WT_box_select)

if __name__ == "__main__":
    register()

    draw_handler = None
