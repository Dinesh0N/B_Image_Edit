
import sys
import math
import gpu
from gpu.shader import create_from_info
from gpu_extras.batch import batch_for_shader
from mathutils import Matrix, Vector
import numpy as np

default_vertex_shader = '''
void main()
{
    gl_Position = ModelViewProjectionMatrix * vec4(pos, 0, 1.0);
}
'''

default_fragment_shader = '''
void main()
{
    fragColor = color;
}
'''

dotted_line_vertex_shader = '''
void main()
{
    arcLengthInter = arcLength;

    gl_Position = ModelViewProjectionMatrix * vec4(pos, 0, 1.0);
}
'''

dotted_line_fragment_shader = '''
void main()
{
    if (step(sin((arcLengthInter + offset) * scale), 0.5) == 1) {
        fragColor = color1;
    } else {
        fragColor = color2;
    }
}
'''

image_vertex_shader = '''
void main()
{
    gl_Position = ModelViewProjectionMatrix * vec4(pos, 0, 1.0);
    texCoordOut = texCoord;
}
'''

image_fragment_shader = '''
// Blend mode constants
const int BLEND_MIX = 0;
const int BLEND_DARKEN = 1;
const int BLEND_MULTIPLY = 2;
const int BLEND_COLOR_BURN = 3;
const int BLEND_LIGHTEN = 4;
const int BLEND_SCREEN = 5;
const int BLEND_COLOR_DODGE = 6;
const int BLEND_ADD = 7;
const int BLEND_OVERLAY = 8;
const int BLEND_SOFT_LIGHT = 9;
const int BLEND_LINEAR_LIGHT = 10;
const int BLEND_DIFFERENCE = 11;
const int BLEND_EXCLUSION = 12;
const int BLEND_SUBTRACT = 13;
const int BLEND_DIVIDE = 14;
const int BLEND_HUE = 15;
const int BLEND_SATURATION = 16;
const int BLEND_COLOR = 17;
const int BLEND_VALUE = 18;

vec3 rgb_to_hsv(vec3 rgb) {
    float cmax = max(rgb.r, max(rgb.g, rgb.b));
    float cmin = min(rgb.r, min(rgb.g, rgb.b));
    float delta = cmax - cmin;
    vec3 hsv = vec3(0.0, 0.0, cmax);
    if (delta > 0.0001) {
        hsv.y = delta / cmax;
        if (rgb.r >= cmax) hsv.x = (rgb.g - rgb.b) / delta;
        else if (rgb.g >= cmax) hsv.x = 2.0 + (rgb.b - rgb.r) / delta;
        else hsv.x = 4.0 + (rgb.r - rgb.g) / delta;
        hsv.x = mod(hsv.x / 6.0, 1.0);
    }
    return hsv;
}

vec3 hsv_to_rgb(vec3 hsv) {
    float h = hsv.x * 6.0;
    float s = hsv.y;
    float v = hsv.z;
    float c = v * s;
    float x = c * (1.0 - abs(mod(h, 2.0) - 1.0));
    float m = v - c;
    vec3 rgb;
    if (h < 1.0) rgb = vec3(c, x, 0.0);
    else if (h < 2.0) rgb = vec3(x, c, 0.0);
    else if (h < 3.0) rgb = vec3(0.0, c, x);
    else if (h < 4.0) rgb = vec3(0.0, x, c);
    else if (h < 5.0) rgb = vec3(x, 0.0, c);
    else rgb = vec3(c, 0.0, x);
    return rgb + m;
}

vec3 blend_colors(vec3 base, vec3 layer, int mode) {
    vec3 result = layer;
    
    if (mode == BLEND_MIX) {
        result = layer;
    } else if (mode == BLEND_DARKEN) {
        result = min(base, layer);
    } else if (mode == BLEND_MULTIPLY) {
        result = base * layer;
    } else if (mode == BLEND_COLOR_BURN) {
        result = vec3(
            layer.r > 0.0 ? 1.0 - min(1.0, (1.0 - base.r) / layer.r) : 0.0,
            layer.g > 0.0 ? 1.0 - min(1.0, (1.0 - base.g) / layer.g) : 0.0,
            layer.b > 0.0 ? 1.0 - min(1.0, (1.0 - base.b) / layer.b) : 0.0
        );
    } else if (mode == BLEND_LIGHTEN) {
        result = max(base, layer);
    } else if (mode == BLEND_SCREEN) {
        result = 1.0 - (1.0 - base) * (1.0 - layer);
    } else if (mode == BLEND_COLOR_DODGE) {
        result = vec3(
            layer.r < 1.0 ? min(1.0, base.r / (1.0 - layer.r)) : 1.0,
            layer.g < 1.0 ? min(1.0, base.g / (1.0 - layer.g)) : 1.0,
            layer.b < 1.0 ? min(1.0, base.b / (1.0 - layer.b)) : 1.0
        );
    } else if (mode == BLEND_ADD) {
        result = min(base + layer, 1.0);
    } else if (mode == BLEND_OVERLAY) {
        result = vec3(
            base.r < 0.5 ? 2.0 * base.r * layer.r : 1.0 - 2.0 * (1.0 - base.r) * (1.0 - layer.r),
            base.g < 0.5 ? 2.0 * base.g * layer.g : 1.0 - 2.0 * (1.0 - base.g) * (1.0 - layer.g),
            base.b < 0.5 ? 2.0 * base.b * layer.b : 1.0 - 2.0 * (1.0 - base.b) * (1.0 - layer.b)
        );
    } else if (mode == BLEND_SOFT_LIGHT) {
        result = vec3(
            layer.r < 0.5 ? base.r - (1.0 - 2.0 * layer.r) * base.r * (1.0 - base.r) : base.r + (2.0 * layer.r - 1.0) * (sqrt(base.r) - base.r),
            layer.g < 0.5 ? base.g - (1.0 - 2.0 * layer.g) * base.g * (1.0 - base.g) : base.g + (2.0 * layer.g - 1.0) * (sqrt(base.g) - base.g),
            layer.b < 0.5 ? base.b - (1.0 - 2.0 * layer.b) * base.b * (1.0 - base.b) : base.b + (2.0 * layer.b - 1.0) * (sqrt(base.b) - base.b)
        );
    } else if (mode == BLEND_LINEAR_LIGHT) {
        result = clamp(base + 2.0 * layer - 1.0, 0.0, 1.0);
    } else if (mode == BLEND_DIFFERENCE) {
        result = abs(base - layer);
    } else if (mode == BLEND_EXCLUSION) {
        result = base + layer - 2.0 * base * layer;
    } else if (mode == BLEND_SUBTRACT) {
        result = max(base - layer, 0.0);
    } else if (mode == BLEND_DIVIDE) {
        result = vec3(
            layer.r > 0.0 ? min(base.r / layer.r, 1.0) : 1.0,
            layer.g > 0.0 ? min(base.g / layer.g, 1.0) : 1.0,
            layer.b > 0.0 ? min(base.b / layer.b, 1.0) : 1.0
        );
    } else if (mode == BLEND_HUE) {
        vec3 baseHSV = rgb_to_hsv(base);
        vec3 layerHSV = rgb_to_hsv(layer);
        result = hsv_to_rgb(vec3(layerHSV.x, baseHSV.y, baseHSV.z));
    } else if (mode == BLEND_SATURATION) {
        vec3 baseHSV = rgb_to_hsv(base);
        vec3 layerHSV = rgb_to_hsv(layer);
        result = hsv_to_rgb(vec3(baseHSV.x, layerHSV.y, baseHSV.z));
    } else if (mode == BLEND_COLOR) {
        vec3 baseHSV = rgb_to_hsv(base);
        vec3 layerHSV = rgb_to_hsv(layer);
        result = hsv_to_rgb(vec3(layerHSV.x, layerHSV.y, baseHSV.z));
    } else if (mode == BLEND_VALUE) {
        vec3 baseHSV = rgb_to_hsv(base);
        vec3 layerHSV = rgb_to_hsv(layer);
        result = hsv_to_rgb(vec3(baseHSV.x, baseHSV.y, layerHSV.z));
    }
    
    return result;
}

void main()
{
    vec4 texColor = texture(image, texCoordOut);
    vec3 blended = blend_colors(baseColor.rgb, texColor.rgb, blendMode);
    float finalAlpha = texColor.a * opacity;
    fragColor = vec4(blended, finalAlpha);
}
'''

def make_scale_matrix(scale):
    return Matrix([
        [scale[0], 0, 0, 0],
        [0, scale[1], 0, 0],
        [0, 0, 1.0, 0],
        [0, 0, 0, 1.0]
    ])

class UIRenderer:
    def __init__(self):
        default_shader_info = gpu.types.GPUShaderCreateInfo()
        default_shader_info.push_constant('MAT4', 'ModelViewProjectionMatrix')
        default_shader_info.push_constant('VEC4', 'color')
        default_shader_info.vertex_in(0, 'VEC2', 'pos')
        default_shader_info.fragment_out(0, 'VEC4', 'fragColor')
        default_shader_info.vertex_source(default_vertex_shader)
        default_shader_info.fragment_source(default_fragment_shader)
        self.default_shader = create_from_info(default_shader_info)
        self.default_shader_u_color = self.default_shader.uniform_from_name('color')

        dotted_line_shader_inter = gpu.types.GPUStageInterfaceInfo("dotted_line")
        dotted_line_shader_inter.smooth('FLOAT', "arcLengthInter")

        dotted_line_shader_info = gpu.types.GPUShaderCreateInfo()
        dotted_line_shader_info.push_constant('MAT4', 'ModelViewProjectionMatrix')
        dotted_line_shader_info.push_constant('FLOAT', 'scale')
        dotted_line_shader_info.push_constant('FLOAT', 'offset')
        dotted_line_shader_info.push_constant('VEC4', 'color1')
        dotted_line_shader_info.push_constant('VEC4', 'color2')
        dotted_line_shader_info.vertex_in(0, 'VEC2', 'pos')
        dotted_line_shader_info.vertex_in(1, 'FLOAT', 'arcLength')
        dotted_line_shader_info.vertex_out(dotted_line_shader_inter)
        dotted_line_shader_info.fragment_out(0, 'VEC4', 'fragColor')
        dotted_line_shader_info.vertex_source(dotted_line_vertex_shader)
        dotted_line_shader_info.fragment_source(dotted_line_fragment_shader)
        self.dotted_line_shader = create_from_info(dotted_line_shader_info)
        self.dotted_line_shader_u_color1 = self.dotted_line_shader.uniform_from_name("color1")
        self.dotted_line_shader_u_color2 = self.dotted_line_shader.uniform_from_name("color2")

        image_shader_inter = gpu.types.GPUStageInterfaceInfo("image_shader")
        image_shader_inter.smooth('VEC2', "texCoordOut")

        image_shader_info = gpu.types.GPUShaderCreateInfo()
        image_shader_info.push_constant('MAT4', 'ModelViewProjectionMatrix')
        image_shader_info.push_constant('FLOAT', 'opacity')
        image_shader_info.push_constant('INT', 'blendMode')
        image_shader_info.push_constant('VEC4', 'baseColor')
        image_shader_info.sampler(0, 'FLOAT_2D', 'image')
        image_shader_info.vertex_in(0, 'VEC2', 'pos')
        image_shader_info.vertex_in(1, 'VEC2', 'texCoord')
        image_shader_info.vertex_out(image_shader_inter)
        image_shader_info.fragment_out(0, 'VEC4', 'fragColor')
        image_shader_info.vertex_source(image_vertex_shader)
        image_shader_info.fragment_source(image_fragment_shader)
        self.image_shader = create_from_info(image_shader_info)

    def render_selection_frame(self, pos, size, rot=0, scale=(1.0, 1.0)):
        width, height = size[0], size[1]

        prev_blend = gpu.state.blend_get()
        gpu.state.blend_set('ALPHA')

        gpu.state.line_width_set(2.0)

        with gpu.matrix.push_pop():
            verts = [[0, 0], [0, height], [width, height], [width, 0], [0, 0]]
            # T <= R <= S <= centering
            mat = Matrix.Translation([pos[0] + width / 2.0, pos[1] + height / 2.0, 0]) \
                    @ Matrix.Rotation(rot, 4, 'Z') \
                    @ make_scale_matrix(scale) \
                    @ Matrix.Translation([-width / 2.0, -height / 2.0, 0])

            for i, vert in enumerate(verts):
                verts[i] = (mat @ Vector(vert + [0, 1]))[:2]

            verts = np.array(verts, 'f')

            arc_lengths = [0]
            for a, b in zip(verts[:-1], verts[1:]):
                arc_lengths.append(arc_lengths[-1] + np.linalg.norm(a - b))
        
            batch = batch_for_shader(self.dotted_line_shader, 'LINE_STRIP',
                {"pos": verts, "arcLength": arc_lengths})

            self.dotted_line_shader.bind()

            self.dotted_line_shader.uniform_float("scale", 0.6)
            self.dotted_line_shader.uniform_float("offset", 0)
            self.dotted_line_shader.uniform_vector_float(self.dotted_line_shader_u_color1,
                    np.array([1.0, 1.0, 1.0, 0.5], 'f'), 4)
            self.dotted_line_shader.uniform_vector_float(self.dotted_line_shader_u_color2,
                    np.array([0.0, 0.0, 0.0, 0.5], 'f'), 4)

            batch.draw(self.dotted_line_shader)

        gpu.state.blend_set(prev_blend)

    def render_image_sub(self, img, pos, size, rot, scale, opacity=1.0, blend_mode=0, base_color=(0.5, 0.5, 0.5, 1.0)):
        width, height = size[0], size[1]

        texture = gpu.texture.from_image(img)

        with gpu.matrix.push_pop():
            gpu.matrix.translate([pos[0] + width / 2.0, pos[1] + height / 2.0])
            gpu.matrix.multiply_matrix(
                    Matrix.Rotation(rot, 4, 'Z'))
            gpu.matrix.scale(scale)
            gpu.matrix.translate([-width / 2.0, -height / 2.0])

            batch = batch_for_shader(self.image_shader, 'TRI_FAN',
                {
                    "pos": [
                        (0, 0),
                        (width, 0),
                        size,
                        (0, height)
                    ],
                    "texCoord": [(0, 0), (1, 0), (1, 1), (0, 1)]
                })

            self.image_shader.bind()

            self.image_shader.uniform_float('opacity', opacity)
            self.image_shader.uniform_int('blendMode', blend_mode)
            self.image_shader.uniform_float('baseColor', base_color)
            self.image_shader.uniform_sampler('image', texture)

            batch.draw(self.image_shader)

    def render_image(self, img, pos, size, rot=0, scale=(1.0, 1.0), opacity=1.0, blend_mode=0, base_color=(0.5, 0.5, 0.5, 1.0)):
        prev_blend = gpu.state.blend_get()
        gpu.state.blend_set('ALPHA')

        self.render_image_sub(img, pos, size, rot, scale, opacity, blend_mode, base_color)

        gpu.state.blend_set(prev_blend)

    def render_image_offscreen(self, img, rot=0, scale=(1.0, 1.0)):
        width, height = img.size[0], img.size[1]

        box = [[0, 0], [width, 0], [0, height], [width, height]]
        mat = Matrix.Rotation(rot, 4, 'Z') \
                @ make_scale_matrix(scale) \
                @ Matrix.Translation([-width / 2.0, -height / 2.0, 0])
        min_x, min_y = sys.float_info.max, sys.float_info.max
        max_x, max_y = -sys.float_info.max, -sys.float_info.max

        # calculate bounding box
        for pos in box:
            pos = mat @ Vector(pos + [0, 1])
            min_x = min(min_x, pos[0])
            min_y = min(min_y, pos[1])
            max_x = max(max_x, pos[0])
            max_y = max(max_y, pos[1])

        ofs_width = math.ceil(max_x - min_x)
        ofs_height = math.ceil(max_y - min_y)

        ofs = gpu.types.GPUOffScreen(ofs_width, ofs_height)
        with ofs.bind():
            fb = gpu.state.active_framebuffer_get()
            fb.clear(color=(0.0, 0.0, 0.0, 0.0))

            with gpu.matrix.push_pop():
                gpu.matrix.load_projection_matrix(Matrix.Identity(4))

                gpu.matrix.load_identity()
                gpu.matrix.scale([1.0 / (ofs_width / 2.0), 1.0 / (ofs_height / 2.0)])
                gpu.matrix.translate([-width / 2.0, -height / 2.0])

                self.render_image_sub(img, [0, 0], [width, height], rot, scale)

            buff = fb.read_color(0, 0, ofs_width, ofs_height, 4, 0, 'UBYTE')

        ofs.free()

        return buff, ofs_width, ofs_height

    def render_info_box(self, pos1, pos2):
        prev_blend = gpu.state.blend_get()
        gpu.state.blend_set('ALPHA')

        verts = [
            pos1,
            (pos2[0], pos1[1]),
            (pos1[0], pos2[1]),
            pos2
        ]

        indices = [
            (0, 1, 2),
            (2, 1, 3)
        ]

        batch = batch_for_shader(self.default_shader, 'TRIS',
            {"pos": verts}, indices=indices)

        self.default_shader.bind()

        self.default_shader.uniform_vector_float(self.default_shader_u_color,
                np.array([0, 0, 0, 0.7], 'f'), 4)

        batch.draw(self.default_shader)

        gpu.state.blend_set(prev_blend)
