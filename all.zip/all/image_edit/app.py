
import os
import bpy
import blf
import numpy as np
from . ui_renderer import UIRenderer as UIRenderer
from . import utils

class AreaSession:
    def __init__(self):
        self.selection = None
        self.selection_region = None
        self.selecting = False
        self.layer_moving = False
        self.layer_rotating = False
        self.layer_scaling = False
        self.prevent_layer_update_event = False
        self.prev_image = None

class Session:
    def __init__(self):
        self.icons = None
        self.keymaps = []
        self.cached_image_pixels = None
        self.cached_layer_location = None
        self.ui_renderer = None
        self.copied_image_pixels = None
        self.copied_image_settings = None
        self.copied_layer_settings = None
        self.areas = {}

def get_session():
    global session
    return session

def get_area_session(context):
    area_session = session.areas.get(context.area, None)
    if not area_session:
        area_session = AreaSession()
        session.areas[context.area] = area_session
    return area_session

def draw_handler():
    global session
    context = bpy.context
    area_session = get_area_session(context)
    info_text = None
    width, height, img_name = 0, 0, ''
    img = context.area.spaces.active.image
    if img:
        width, height = img.size[0], img.size[1]

    if img and area_session.selection or area_session.selection_region:
        if area_session.selection:
            selection = area_session.selection
            view_x1 = selection[0][0] / width
            view_y1 = selection[0][1] / height
            view_x2 = selection[1][0] / width
            view_y2 = selection[1][1] / height
            region_pos1 = context.region.view2d.view_to_region(view_x1, view_y1, clip=False)
            region_pos2 = context.region.view2d.view_to_region(view_x2, view_y2, clip=False)
        else:
            region_pos1, region_pos2 = area_session.selection_region
        if not session.ui_renderer:
            session.ui_renderer = UIRenderer()
        region_size = [region_pos2[0] - region_pos1[0], region_pos2[1] - region_pos1[1]]
        session.ui_renderer.render_selection_frame(region_pos1, region_size)

    if img:
        if not session.ui_renderer:
            session.ui_renderer = UIRenderer()
        img_props = img.imageeditorplus_properties
        selected_layer_index = img_props.selected_layer_index
        layers = img_props.layers
        # Blend mode string to integer mapping
        BLEND_MODE_MAP = {
            'MIX': 0, 'DARKEN': 1, 'MULTIPLY': 2, 'COLOR_BURN': 3,
            'LIGHTEN': 4, 'SCREEN': 5, 'COLOR_DODGE': 6, 'ADD': 7,
            'OVERLAY': 8, 'SOFT_LIGHT': 9, 'LINEAR_LIGHT': 10,
            'DIFFERENCE': 11, 'EXCLUSION': 12, 'SUBTRACT': 13, 'DIVIDE': 14,
            'HUE': 15, 'SATURATION': 16, 'COLOR': 17, 'VALUE': 18
        }
        
        for i, layer in reversed(list(enumerate(layers))):
            layer_img = bpy.data.images.get(layer.name, None)
            if layer_img:
                layer_width, layer_height = layer_img.size[0], layer_img.size[1]
                layer_pos = layer.location
                layer_pos1 = [layer_pos[0], layer_pos[1] + layer_height]
                layer_pos2 = [layer_pos[0] + layer_width, layer_pos[1]]
                layer_view_x1 = layer_pos1[0] / width
                layer_view_y1 = 1.0 - layer_pos1[1] / height
                layer_region_pos1 = context.region.view2d.view_to_region(layer_view_x1, layer_view_y1, clip=False)
                layer_view_x2 = layer_pos2[0] / width
                layer_view_y2 = 1.0 - layer_pos2[1] / height
                layer_region_pos2 = context.region.view2d.view_to_region(layer_view_x2, layer_view_y2, clip=False)
                layer_region_size = [layer_region_pos2[0] - layer_region_pos1[0], layer_region_pos2[1] - layer_region_pos1[1]]
                if not layer.hide:
                    blend_mode_int = BLEND_MODE_MAP.get(layer.blend_mode, 0)
                    session.ui_renderer.render_image(layer_img, layer_region_pos1, layer_region_size, layer.rotation, layer.scale, layer.opacity, blend_mode_int)
                if i == selected_layer_index:
                    session.ui_renderer.render_selection_frame(layer_region_pos1, layer_region_size, layer.rotation, layer.scale)

    if area_session.selection or area_session.selection_region:
        if area_session.prev_image:
            if img != area_session.prev_image:
                cancel_selection(context)
            elif width != area_session.prev_image_width or height != area_session.prev_image_height:
                crop_selection(context)

    area_session.prev_image = img
    area_session.prev_image_width = width
    area_session.prev_image_height = height

    if area_session.layer_moving or area_session.layer_rotating or area_session.layer_scaling:
        info_text = "LMB: Perform   RMB: Cancel"

    area_width = context.area.width
    if info_text:
        ui_scale = context.preferences.system.ui_scale
        session.ui_renderer.render_info_box((0, 0), (area_width, 20 * ui_scale))
        blf.position(0, 8 * ui_scale, 6 * ui_scale, 0)
        blf.size(0, 11 * ui_scale) if bpy.app.version >= (3, 6) else blf.size(0, 11 * ui_scale, 72)
        blf.color(0, 0.7, 0.7, 0.7, 1.0)
        blf.draw(0, info_text)

def get_active_layer(context):
    img = context.area.spaces.active.image
    if not img:
        return None
    img_props = img.imageeditorplus_properties
    layers = img_props.layers
    selected_layer_index = img_props.selected_layer_index
    if selected_layer_index == -1 or selected_layer_index >= len(layers):
        return None
    return layers[selected_layer_index]

def get_target_image(context):
    layer = get_active_layer(context)
    if layer:
        return bpy.data.images.get(layer.name, None)
    else:
        return context.area.spaces.active.image

def cache_image(img):
    global session
    pixels = utils.read_pixels_from_image(img)
    session.cached_image_pixels = pixels
    return pixels

def get_image_cache():
    global session
    pixels = session.cached_image_pixels
    if pixels is not None:
        pixels = pixels.copy()
    return pixels

def revert_image_cache(img):
    global session
    pixels = session.cached_image_pixels
    if pixels is None:
        return
    utils.write_pixels_to_image(img, pixels)

def clear_image_cache():
    global session
    session.cached_image_pixels = None

def convert_selection(context):
    area_session = get_area_session(context)
    img = context.area.spaces.active.image
    if not img:
        return
    width, height = img.size[0], img.size[1]
    selection_region = area_session.selection_region
    if not selection_region:
        return
    x1, y1 = context.region.view2d.region_to_view(*selection_region[0])
    x2, y2 = context.region.view2d.region_to_view(*selection_region[1])
    x1, x2 = sorted((x1, x2))
    y1, y2 = sorted((y1, y2))
    x1 = round(x1 * width)
    y1 = round(y1 * height)
    x2 = round(x2 * width)
    y2 = round(y2 * height)
    area_session.selection = [[x1, y1], [x2, y2]]
    crop_selection(context)

def crop_selection(context):
    area_session = get_area_session(context)
    img = context.area.spaces.active.image
    if not img:
        return
    width, height = img.size[0], img.size[1]
    if not area_session.selection:
        return
    [x1, y1], [x2, y2] = area_session.selection
    x1 = max(min(x1, width), 0)
    y1 = max(min(y1, height), 0)
    x2 = max(min(x2, width), 0)
    y2 = max(min(y2, height), 0)
    if x2 - x1 <= 0:
        if x2 < width:
            x2 = x2 + 1
        else:
            x1 = x1 - 1
    if y2 - y1 <= 0:
        if y2 < height:
            y2 = y2 + 1
        else:
            y1 = y1 - 1
    area_session.selection = [[x1, y1], [x2, y2]]

def cancel_selection(context):
    area_session = get_area_session(context)
    area_session.selection = None
    area_session.selection_region = None
    # Clear paint mask when selection is cancelled
    clear_paint_mask(context)

# Paint mask data storage
_paint_mask_data = {
    'enabled': False,
    'image_name': None,
    'selection': None,
    'full_cached': None,  # Full image cache for restoration
    'timer': None
}

def apply_selection_as_paint_mask(context):
    """Create paint mask - store full image to restore outside selection"""
    global _paint_mask_data
    
    area_session = get_area_session(context)
    selection = area_session.selection
    if not selection:
        return
    
    img = context.area.spaces.active.image
    if not img:
        return
    
    # Store full image pixels
    pixels = utils.read_pixels_from_image(img)
    
    _paint_mask_data['enabled'] = True
    _paint_mask_data['image_name'] = img.name
    _paint_mask_data['selection'] = selection
    _paint_mask_data['full_cached'] = pixels.copy()
    
    # Register timer with longer interval for performance
    if _paint_mask_data['timer'] is None:
        _paint_mask_data['timer'] = bpy.app.timers.register(
            _paint_mask_timer, 
            first_interval=0.3,
            persistent=True
        )

def _paint_mask_timer():
    """Timer that restores pixels outside selection - optimized"""
    global _paint_mask_data
    
    if not _paint_mask_data['enabled']:
        _paint_mask_data['timer'] = None
        return None
    
    img_name = _paint_mask_data['image_name']
    if not img_name:
        return 0.3
    
    img = bpy.data.images.get(img_name)
    if not img:
        _paint_mask_data['enabled'] = False
        _paint_mask_data['timer'] = None
        return None
    
    if not img.is_dirty:
        return 0.3
    
    cached = _paint_mask_data['full_cached']
    selection = _paint_mask_data['selection']
    
    if cached is None or selection is None:
        return 0.3
    
    [[x1, y1], [x2, y2]] = selection
    height, width = cached.shape[0], cached.shape[1]
    
    try:
        current = utils.read_pixels_from_image(img)
        
        # Restore only outside regions (more efficient than full mask)
        # Top region
        if y2 < height:
            current[y2:, :] = cached[y2:, :]
        # Bottom region
        if y1 > 0:
            current[:y1, :] = cached[:y1, :]
        # Left region (within y1:y2)
        if x1 > 0:
            current[y1:y2, :x1] = cached[y1:y2, :x1]
        # Right region (within y1:y2)
        if x2 < width:
            current[y1:y2, x2:] = cached[y1:y2, x2:]
        
        utils.write_pixels_to_image(img, current)
    except:
        pass
    
    return 0.3

def clear_paint_mask(context):
    """Disable paint mask and clean up"""
    global _paint_mask_data
    
    _paint_mask_data['enabled'] = False
    _paint_mask_data['image_name'] = None
    _paint_mask_data['selection'] = None
    _paint_mask_data['full_cached'] = None

def get_selection(context):
    area_session = get_area_session(context)
    return area_session.selection

def get_target_selection(context):
    area_session = get_area_session(context)
    selection = area_session.selection
    if not selection:
        return None
    img = context.area.spaces.active.image
    if not img:
        return selection
    img_props = img.imageeditorplus_properties
    layers = img_props.layers
    selected_layer_index = img_props.selected_layer_index
    if selected_layer_index == -1 or selected_layer_index >= len(layers):
        return selection
    return None

def refresh_image(context):
    wm = context.window_manager
    img = context.area.spaces.active.image
    if not img:
        return
    context.area.spaces.active.image = img
    img.update()
    if not hasattr(wm, 'imagelayersnode_api') or wm.imagelayersnode_api.VERSION < (1, 1, 0):
        return
    wm.imagelayersnode_api.update_pasted_layer_nodes(img)

def apply_layer_transform(img, rot, scale):
    global session
    if not session.ui_renderer:
        session.ui_renderer = UIRenderer()
    buff, width, height = session.ui_renderer.render_image_offscreen(img, rot, scale)
    pixels = np.array([[pixel for pixel in row] for row in buff], np.float32) / 255.0
    utils.convert_colorspace(pixels, 'Linear', 'Linear' if img.is_float else img.colorspace_settings.name)
    return pixels, width, height

def create_layer(base_img, pixels, img_settings, layer_settings, custom_label=None):
    base_width, base_height = base_img.size
    target_width, target_height = pixels.shape[1], pixels.shape[0]
    layer_img_prefix = '#layer'
    layer_img_name = base_img.name + layer_img_prefix
    layer_img = bpy.data.images.new(layer_img_name, width=target_width, height=target_height, alpha=True, float_buffer=base_img.is_float)
    layer_img.colorspace_settings.name = base_img.colorspace_settings.name
    pixels = pixels.copy()
    utils.convert_colorspace(pixels, 'Linear' if img_settings['is_float'] else img_settings['colorspace_name'], 'Linear' if base_img.is_float else base_img.colorspace_settings.name)
    utils.write_pixels_to_image(layer_img, pixels)
    layer_img.use_fake_user = True
    layer_img.pack()
    img_props = base_img.imageeditorplus_properties
    layers = img_props.layers
    layer = layers.add()
    layer.name = layer_img.name
    layer.location = [int((base_width - target_width) / 2.0), int((base_height - target_height) / 2.0)]
    
    # Set layer label
    if custom_label:
        layer.label = custom_label
    else:
        layer_img_postfix = layer_img.name[layer_img.name.rfind(layer_img_prefix) + len(layer_img_prefix):]
        if layer_img_postfix:
            layer.label = 'Layer ' + layer_img_postfix
        else:
            layer.label = 'Layer'
    
    if layer_settings:
        layer.rotation = layer_settings['rotation']
        layer.scale = layer_settings['scale']
        layer.custom_data = layer_settings['custom_data']
    layers.move(len(layers) - 1, 0)
    img_props.selected_layer_index = 0
    rebuild_image_layers_nodes(base_img)

def rebuild_image_layers_nodes(img):
    wm = bpy.context.window_manager
    if not hasattr(wm, 'imagelayersnode_api') or wm.imagelayersnode_api.VERSION < (1, 1, 0):
        return
    wm.imagelayersnode_api.rebuild_image_layers_nodes(img)

def on_layer_placement_changed(self, context):
    area_session = get_area_session(context)
    if area_session.prevent_layer_update_event:
        return
    img = context.area.spaces.active.image
    if not img:
        return
    rebuild_image_layers_nodes(img)

def on_layer_visible_changed(self, context):
    refresh_image(context)

def on_selected_layer_index_changed(self, context):
    if self.selected_layer_index != -1:
        cancel_selection(context)



def cleanup_scene():
    node_group = bpy.data.node_groups.get('imageeditorplus')
    if node_group:
        bpy.data.node_groups.remove(node_group)

@bpy.app.handlers.persistent
def save_pre_handler(args):
    cleanup_scene()
    for img in bpy.data.images:
        if img.source != 'VIEWER':
            if img.is_dirty:
                if img.packed_files or not img.filepath:
                    img.pack()
                else:
                    img.save()

class IMAGE_EDITOR_PLUS_WindowPropertyGroup(bpy.types.PropertyGroup):
    foreground_color: bpy.props.FloatVectorProperty(name='Foreground Color', subtype='COLOR_GAMMA', min=0, max=1.0, size=3, default=(1.0, 1.0, 1.0))
    background_color: bpy.props.FloatVectorProperty(name='Background Color', subtype='COLOR_GAMMA', min=0, max=1.0, size=3, default=(0, 0, 0))

class IMAGE_EDITOR_PLUS_LayerPropertyGroup(bpy.types.PropertyGroup):
    location: bpy.props.IntVectorProperty(size=2, update=on_layer_placement_changed)
    rotation: bpy.props.FloatProperty(subtype='ANGLE', update=on_layer_placement_changed)
    scale: bpy.props.FloatVectorProperty(size=2, default=(1.0, 1.0), update=on_layer_placement_changed)
    opacity: bpy.props.FloatProperty(name='Opacity', default=1.0, min=0.0, max=1.0, subtype='FACTOR', update=on_layer_visible_changed)
    blend_mode: bpy.props.EnumProperty(
        name='Blend Mode',
        items=[
            ('MIX', 'Mix', 'Normal blend'),
            ('DARKEN', 'Darken', 'Darken blend'),
            ('MULTIPLY', 'Multiply', 'Multiply blend'),
            ('COLOR_BURN', 'Color Burn', 'Color burn blend'),
            ('LIGHTEN', 'Lighten', 'Lighten blend'),
            ('SCREEN', 'Screen', 'Screen blend'),
            ('COLOR_DODGE', 'Color Dodge', 'Color dodge blend'),
            ('ADD', 'Add', 'Add blend'),
            ('OVERLAY', 'Overlay', 'Overlay blend'),
            ('SOFT_LIGHT', 'Soft Light', 'Soft light blend'),
            ('LINEAR_LIGHT', 'Linear Light', 'Linear light blend'),
            ('DIFFERENCE', 'Difference', 'Difference blend'),
            ('EXCLUSION', 'Exclusion', 'Exclusion blend'),
            ('SUBTRACT', 'Subtract', 'Subtract blend'),
            ('DIVIDE', 'Divide', 'Divide blend'),
            ('HUE', 'Hue', 'Hue blend'),
            ('SATURATION', 'Saturation', 'Saturation blend'),
            ('COLOR', 'Color', 'Color blend'),
            ('VALUE', 'Value', 'Value blend'),
        ],
        default='MIX',
        update=on_layer_visible_changed
    )
    label: bpy.props.StringProperty()
    hide: bpy.props.BoolProperty(name='Hide', update=on_layer_visible_changed)
    locked: bpy.props.BoolProperty(name='Lock', default=False, description='Lock layer to prevent editing')
    checked: bpy.props.BoolProperty(name='Select', default=False, description='Select for multi-layer operations')
    custom_data: bpy.props.StringProperty(default='{}')

class IMAGE_EDITOR_PLUS_ImagePropertyGroup(bpy.types.PropertyGroup):
    layers: bpy.props.CollectionProperty(type=IMAGE_EDITOR_PLUS_LayerPropertyGroup)
    selected_layer_index: bpy.props.IntProperty(update=on_selected_layer_index_changed)

session = Session()
