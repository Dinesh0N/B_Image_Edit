
import bpy
from bpy.types import WorkSpaceTool
from . import operators
from . import app

def draw_box_select_tool_settings(context, layout):
    """Draw box select tool settings in the Tool tab"""
    wm = context.window_manager
    
    if not hasattr(wm, 'imageeditorplus_properties'):
        return
    
    props = wm.imageeditorplus_properties
    
    # Edit section
    box = layout.box()
    
    # Color + Fill
    row = box.row(align=True)
    row.prop(props, 'foreground_color', text='')
    row.operator(operators.IMAGE_EDITOR_PLUS_OT_fill_with_fg_color.bl_idname, text='Fill', icon='BRUSH_DATA')
    
    # Cut/Copy to Layer
    row = box.row(align=True)
    row.operator(operators.IMAGE_EDITOR_PLUS_OT_cut_to_layer.bl_idname, text='Cut to Layer', icon='X')
    row.operator(operators.IMAGE_EDITOR_PLUS_OT_copy_to_layer.bl_idname, text='Copy to Layer', icon='COPYDOWN')
    
    # Crop + Delete
    row = box.row(align=True)
    row.operator(operators.IMAGE_EDITOR_PLUS_OT_crop.bl_idname, text='Crop', icon='MOD_MASK')
    row.operator(operators.IMAGE_EDITOR_PLUS_OT_clear.bl_idname, text='Delete', icon='X')

class IMAGE_EDITOR_PLUS_WT_box_select(WorkSpaceTool):
    bl_space_type = 'IMAGE_EDITOR'
    bl_context_mode = 'PAINT'
    bl_idname = "image_editor_plus.box_select_tool"
    bl_label = "Box Select"
    bl_description = "Draw a box to restrict painting to the selected area"
    bl_icon = "ops.generic.select_box"
    bl_widget = None
    bl_keymap = (
        (operators.IMAGE_EDITOR_PLUS_OT_make_selection.bl_idname, {"type": 'LEFTMOUSE', "value": 'PRESS'}, None),
    )
    
    def draw_settings(context, layout, tool):
        draw_box_select_tool_settings(context, layout)

def menu_func(self, context):
    area_session = app.get_area_session(context)
    layout = self.layout
    if context.area.spaces.active.mode != 'UV' \
            and context.area.spaces.active.image != None \
            and context.area.spaces.active.image.source != 'VIEWER':
        layout.separator()
        layout.label(text='Layers')
        if area_session.selection:
            layout.operator(operators.IMAGE_EDITOR_PLUS_OT_make_selection.bl_idname, text='Select Box', icon='SELECT_SET')
            layout.operator(operators.IMAGE_EDITOR_PLUS_OT_cancel_selection.bl_idname, text='Deselect', icon='X')
        else:
            layout.operator(operators.IMAGE_EDITOR_PLUS_OT_make_selection.bl_idname, text='Select Box', icon='SELECT_SET')
        layout.menu(IMAGE_EDITOR_PLUS_MT_edit_menu.bl_idname, text='Edit')
        layout.menu(IMAGE_EDITOR_PLUS_MT_layers_menu.bl_idname, text='Layers')
        layout.menu(IMAGE_EDITOR_PLUS_MT_transform_menu.bl_idname, text='Transform')
        layout.menu(IMAGE_EDITOR_PLUS_MT_transform_layer_menu.bl_idname, text='Transform Layer')
        layout.menu(IMAGE_EDITOR_PLUS_MT_offset_menu.bl_idname, text='Offset')

def reset_scale_properties(self, context):
    if self.reset:
        self.width_pixels = self.original_width
        self.height_pixels = self.original_height
        self.property_unset('width_percent')
        self.property_unset('height_percent')
        self.property_unset('keep_aspect_ratio')
        self.property_unset('scale_layers')
        self.reset = False

def update_scale_width_properties(self, context):
    if self.skip_property_update:
        return
    if self.keep_aspect_ratio:
        self.skip_property_update = True
        ratio = self.original_width / self.original_height
        self.height_pixels = int(self.width_pixels / ratio)
        self.height_percent = self.width_percent
        self.skip_property_update = False

def update_scale_height_properties(self, context):
    if self.skip_property_update:
        return
    if self.keep_aspect_ratio:
        self.skip_property_update = True
        ratio = self.original_width / self.original_height
        self.width_pixels = int(self.height_pixels * ratio)
        self.width_percent = self.height_percent
        self.skip_property_update = False

class IMAGE_EDITOR_PLUS_OT_scale_dialog(bpy.types.Operator):
    """Scale the image"""
    bl_idname = 'image_editor_plus.scale_image_dialog'
    bl_label = "Scale Image"
    reset: bpy.props.BoolProperty(options={'SKIP_SAVE'}, update=reset_scale_properties)
    unit: bpy.props.EnumProperty(options={'SKIP_SAVE'}, items=(('pixels', 'Pixels', 'In pixels'), ('percent', 'Percent', 'In percent')))
    width_pixels: bpy.props.IntProperty(name='Width', min=1, options={'SKIP_SAVE'}, update=update_scale_width_properties)
    height_pixels: bpy.props.IntProperty(name='Height', min=1, options={'SKIP_SAVE'}, update=update_scale_height_properties)
    width_percent: bpy.props.FloatProperty(name='Width', subtype='PERCENTAGE', min=1.0, soft_max=200.0, default=100.0, options={'SKIP_SAVE'}, update=update_scale_width_properties)
    height_percent: bpy.props.FloatProperty(name='Height', subtype='PERCENTAGE', min=1.0, soft_max=200.0, default=100.0, options={'SKIP_SAVE'}, update=update_scale_height_properties)
    keep_aspect_ratio: bpy.props.BoolProperty(name='Keep Aspect Ratio', default=True, options={'SKIP_SAVE'}, update=update_scale_width_properties)
    scale_layers: bpy.props.BoolProperty(name='Scale Layers', default=True, options={'SKIP_SAVE'}, description='Only if Keep Aspect Ratio is turned on')
    original_width: bpy.props.IntProperty()
    original_height: bpy.props.IntProperty()
    skip_property_update: bpy.props.BoolProperty()

    def invoke(self, context, event):
        wm = context.window_manager
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        width, height = img.size
        self.original_width = width
        self.original_height = height
        self.width_pixels = width
        self.height_pixels = height
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        if self.unit == 'pixels':
            width = self.width_pixels
            height = self.height_pixels
        else:
            width = int(self.original_width * self.width_percent / 100.0)
            height = int(self.original_height * self.height_percent / 100.0)
        if width < 1:
            width = 1
        if height < 1:
            height = 1
        scale_layers = False
        if self.keep_aspect_ratio:
            scale_layers = self.scale_layers
        bpy.ops.image_editor_plus.scale('EXEC_DEFAULT', False, width=width, height=height, scale_layers=scale_layers)
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.prop(self, "unit", expand=True)
        row = layout.split(align=True)
        row.alignment = 'RIGHT'
        row.label(text='Width')
        if self.unit == 'pixels':
            row.prop(self, 'width_pixels', text='')
        else:
            row.prop(self, 'width_percent', text='')
        row = layout.split(align=True)
        row.alignment = 'RIGHT'
        row.label(text='Height')
        if self.unit == 'pixels':
            row.prop(self, 'height_pixels', text='')
        else:
            row.prop(self, 'height_percent', text='')
        row = layout.split(align=True)
        row.column()
        row.prop(self, 'keep_aspect_ratio')
        row = layout.split(align=True)
        row.column()
        if self.keep_aspect_ratio:
            row.prop(self, 'scale_layers')
        else:
            row.label(text='No layers scaled.')
        row = layout.split(factor=0.7)
        row.column()
        row.prop(self, 'reset', text='Reset', toggle=True)

def reset_canvas_size_properties(self, context):
    if self.reset:
        self.width = self.original_width
        self.height = self.original_height
        self.expand_from_center = False
        self.use_background_color = False
        self.reset = False

class IMAGE_EDITOR_PLUS_OT_change_canvas_size_dialog(bpy.types.Operator):
    """Change the canvas size"""
    bl_idname = 'image_editor_plus.change_canvas_size_dialog'
    bl_label = "Canvas Size"
    reset: bpy.props.BoolProperty(options={'SKIP_SAVE'}, update=reset_canvas_size_properties)
    width: bpy.props.IntProperty(name='Width', min=1, options={'SKIP_SAVE'})
    height: bpy.props.IntProperty(name='Height', min=1, options={'SKIP_SAVE'})
    expand_from_center: bpy.props.BoolProperty(name='Expand from Center', default=False)
    use_background_color: bpy.props.BoolProperty(name='Use Background Color', default=False)
    original_width: bpy.props.IntProperty()
    original_height: bpy.props.IntProperty()

    def invoke(self, context, event):
        wm = context.window_manager
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        width, height = img.size
        self.original_width = width
        self.original_height = height
        self.width = width
        self.height = height
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        width = self.width
        height = self.height
        if width < 1:
            width = 1
        if height < 1:
            height = 1
        bpy.ops.image_editor_plus.change_canvas_size('EXEC_DEFAULT', False, width=width, height=height, expand_from_center=self.expand_from_center, use_background_color=self.use_background_color)
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row = layout.split(align=True)
        row.alignment = 'RIGHT'
        row.label(text='Width')
        row.prop(self, 'width', text='')
        row = layout.split(align=True)
        row.alignment = 'RIGHT'
        row.label(text='Height')
        row.prop(self, 'height', text='')
        row = layout.split(align=True)
        row.column()
        row.prop(self, 'expand_from_center')
        row = layout.split(align=True)
        row.column()
        row.prop(self, 'use_background_color')
        row = layout.split(align=True)
        row.column()
        row = layout.split(factor=0.7)
        row.column()
        row.prop(self, 'reset', text='Reset', toggle=True)

def reset_offset_properties(self, context):
    if self.reset:
        self.reset = False
    self.offset_properties.property_unset('offset_x')
    self.offset_properties.property_unset('offset_y')
    self.property_unset('offset_edge_behavior')
    update_offset_properties(self, context)

def update_offset_properties(self, context):
    if self.update_preview:
        self.update_preview = False
    bpy.ops.image_editor_plus.offset('EXEC_DEFAULT', False, offset_x=self.offset_properties.offset_x, offset_y=self.offset_properties.offset_y, offset_edge_behavior=self.offset_edge_behavior)

class IMAGE_EDITOR_PLUS_OffsetPropertyGroup(bpy.types.PropertyGroup):
    offset_x: bpy.props.IntProperty()
    offset_y: bpy.props.IntProperty()

class IMAGE_EDITOR_PLUS_OT_offset_dialog(bpy.types.Operator):
    """Offset the image"""
    bl_idname = 'image_editor_plus.offset_dialog'
    bl_label = "Offset"
    update_preview: bpy.props.BoolProperty(options={'SKIP_SAVE'}, update=update_offset_properties, description='Update preview')
    reset: bpy.props.BoolProperty(options={'SKIP_SAVE'}, update=reset_offset_properties)
    offset_properties: bpy.props.PointerProperty(options={'SKIP_SAVE'}, type=IMAGE_EDITOR_PLUS_OffsetPropertyGroup)
    offset_edge_behavior: bpy.props.EnumProperty(options={'SKIP_SAVE'}, items=(('wrap', 'Wrap', 'Wrap image around'), ('edge', 'Edge', 'Repeat edge pixels')))

    def invoke(self, context, event):
        wm = context.window_manager
        img = app.get_target_image(context)
        if not img:
            return {'CANCELLED'}
        app.cache_image(img)
        width, height = img.size
        selection = app.get_target_selection(context)
        if selection:
            width = selection[1][0] - selection[0][0]
            height = selection[1][1] - selection[0][1]
        IMAGE_EDITOR_PLUS_OffsetPropertyGroup.offset_x = bpy.props.IntProperty(name='Offset X', subtype='FACTOR', min=-width + 1, max=width - 1)
        IMAGE_EDITOR_PLUS_OffsetPropertyGroup.offset_y = bpy.props.IntProperty(name='Offset Y', subtype='FACTOR', min=-height + 1, max=height - 1)
        update_offset_properties(self, context)
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        bpy.ops.image_editor_plus.offset('EXEC_DEFAULT', False, offset_x=self.offset_properties.offset_x, offset_y=self.offset_properties.offset_y, offset_edge_behavior=self.offset_edge_behavior)
        return {'FINISHED'}

    def cancel(self, context):
        img = app.get_target_image(context)
        if not img:
            return {'CANCELLED'}
        app.revert_image_cache(img)
        app.clear_image_cache()
        app.refresh_image(context)

    def draw(self, context):
        layout = self.layout
        row = layout.split(align=True)
        row.column()
        row.prop(self, 'update_preview', text='Update Preview', toggle=True, icon='FILE_REFRESH')
        layout.separator()
        row = layout.split(align=True)
        row.alignment = 'RIGHT'
        row.label(text='Offset X')
        row.prop(self.offset_properties, 'offset_x', text='')
        row = layout.split(align=True)
        row.alignment = 'RIGHT'
        row.label(text='Offset Y')
        row.prop(self.offset_properties, 'offset_y', text='')
        row = layout.row()
        row.prop(self, "offset_edge_behavior", expand=True)
        row = layout.split(factor=0.7)
        row.column()
        row.prop(self, 'reset', text='Reset', toggle=True)

class IMAGE_EDITOR_PLUS_UL_layer_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        img = bpy.data.images.get(item.name)
        if img:
            icon_value = bpy.types.UILayout.icon(img)
            
            row = layout.row(align=True)
            
            # 1. Multi-selection checkbox
            check_icon = 'CHECKBOX_HLT' if item.checked else 'CHECKBOX_DEHLT'
            row.prop(item, 'checked', text='', emboss=False, icon=check_icon)
            
            # 2. Visibility (eye icon)
            hide_icon = 'HIDE_ON' if item.hide else 'HIDE_OFF'
            row.prop(item, 'hide', text='', emboss=False, icon=hide_icon)
            
            # 3. Layer preview thumbnail + 4. Layer name (editable)
            row.prop(item, 'label', text='', emboss=False, icon_value=icon_value)
            
            # 5. Layer lock toggle
            lock_icon = 'LOCKED' if item.locked else 'UNLOCKED'
            row.prop(item, 'locked', text='', emboss=False, icon=lock_icon)

    def filter_items(self, context, data, propname):
        layers = getattr(data, propname)
        helper_funcs = bpy.types.UI_UL_list
        
        # Default return values
        flt_flags = []
        flt_neworder = []
        
        # Filtering by name
        if self.filter_name:
            flt_flags = helper_funcs.filter_items_by_name(self.filter_name, self.bitflag_filter_item, layers, "label")
        
        if not flt_flags:
            flt_flags = [self.bitflag_filter_item] * len(layers)
        
        # Sorting (if enabled)
        if self.use_filter_sort_alpha:
            flt_neworder = helper_funcs.sort_items_by_name(layers, "label")
        
        return flt_flags, flt_neworder

class IMAGE_EDITOR_PLUS_MT_edit_menu(bpy.types.Menu):
    bl_idname = "IMAGE_EDITOR_PLUS_MT_edit_menu"
    bl_label = "Edit"

    def draw(self, context):
        layout = self.layout
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_fill_with_fg_color.bl_idname, text='Fill with FG Color', icon='BRUSH_DATA')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_fill_with_bg_color.bl_idname, text='Fill with BG Color', icon='BRUSH_DATA')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_clear.bl_idname, text='Clear', icon='X')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_cut.bl_idname, text='Cut', icon='X')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_copy.bl_idname, text='Copy', icon='COPYDOWN')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_paste.bl_idname, text='Paste', icon='PASTEDOWN')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_crop.bl_idname, text='Crop', icon='MOD_MASK')

class IMAGE_EDITOR_PLUS_MT_layers_menu(bpy.types.Menu):
    bl_idname = "IMAGE_EDITOR_PLUS_MT_layers_menu"
    bl_label = "Layers"

    def draw(self, context):
        layout = self.layout
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_deselect_layer.bl_idname, text='Deselect Layer', icon='X')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_move_layer.bl_idname, text='Move', icon='GRAB')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_rotate_layer.bl_idname, text='Rotate', icon='FILE_REFRESH')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_scale_layer.bl_idname, text='Scale', icon='FULLSCREEN_ENTER')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_delete_layer.bl_idname, text='Delete', icon='TRASH')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_merge_layers.bl_idname, text='Merge Layers', icon='CHECKMARK')

class IMAGE_EDITOR_PLUS_MT_layer_options_menu(bpy.types.Menu):
    bl_idname = "IMAGE_EDITOR_PLUS_MT_layer_options_menu"
    bl_label = "Layer Options"

    def draw(self, context):
        layout = self.layout
        
        # Layer operations
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_duplicate_layer.bl_idname, text='Duplicate', icon='DUPLICATE')
        
        layout.separator()
        
        # Multi-selection
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_select_all_layers.bl_idname, text='Select All', icon='CHECKBOX_HLT')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_deselect_all_layers.bl_idname, text='Deselect All', icon='CHECKBOX_DEHLT')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_invert_layer_selection.bl_idname, text='Invert Selection', icon='UV_SYNC_SELECT')
        
        layout.separator()
        
        # Selected layer operations
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_merge_selected_layers.bl_idname, text='Merge Selected', icon='AUTOMERGE_OFF')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_delete_selected_layers.bl_idname, text='Delete Selected', icon='TRASH')
        
        layout.separator()
        
        # Flip operations
        op = layout.operator(operators.IMAGE_EDITOR_PLUS_OT_flip_layer.bl_idname, text='Flip Horizontal', icon='MOD_MIRROR')
        op.is_vertically = False
        op = layout.operator(operators.IMAGE_EDITOR_PLUS_OT_flip_layer.bl_idname, text='Flip Vertical', icon='MOD_MIRROR')
        op.is_vertically = True
        
        layout.separator()
        
        # Visibility
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_show_all_layers.bl_idname, text='Show All', icon='HIDE_OFF')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_hide_all_layers.bl_idname, text='Hide All', icon='HIDE_ON')
        
        layout.separator()
        
        # Lock operations
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_lock_all_layers.bl_idname, text='Lock All', icon='LOCKED')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_unlock_all_layers.bl_idname, text='Unlock All', icon='UNLOCKED')
        
        layout.separator()
        
        # Merge and delete all
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_merge_layers.bl_idname, text='Merge All', icon='AUTOMERGE_OFF')
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_delete_all_layers.bl_idname, text='Delete All', icon='TRASH')
        
        layout.separator()
        
        # Utilities
        layout.operator(operators.IMAGE_EDITOR_PLUS_OT_update_layer_previews.bl_idname, text='Update Previews', icon='FILE_REFRESH')

class IMAGE_EDITOR_PLUS_MT_transform_menu(bpy.types.Menu):
    bl_idname = "IMAGE_EDITOR_PLUS_MT_transform_menu"
    bl_label = "Transform"

    def draw(self, context):
        layout = self.layout
        op = layout.operator(operators.IMAGE_EDITOR_PLUS_OT_flip.bl_idname, text='Flip Horizontally', icon='MOD_MIRROR')
        op.is_vertically = False
        op = layout.operator(operators.IMAGE_EDITOR_PLUS_OT_flip.bl_idname, text='Flip Vertically', icon='MOD_MIRROR')
        op.is_vertically = True
        op = layout.operator(operators.IMAGE_EDITOR_PLUS_OT_rotate.bl_idname, text="Rotate 90\u00b0 Left", icon='FILE_REFRESH')
        op.is_left = True
        op = layout.operator(operators.IMAGE_EDITOR_PLUS_OT_rotate.bl_idname, text="Rotate 90\u00b0 Right", icon='FILE_REFRESH')
        op.is_left = False
        op = layout.operator(IMAGE_EDITOR_PLUS_OT_scale_dialog.bl_idname, text='Scale...', icon='FULLSCREEN_ENTER')
        op = layout.operator(IMAGE_EDITOR_PLUS_OT_change_canvas_size_dialog.bl_idname, text='Canvas Size...', icon='FULLSCREEN_ENTER')

class IMAGE_EDITOR_PLUS_MT_transform_layer_menu(bpy.types.Menu):
    bl_idname = "IMAGE_EDITOR_PLUS_MT_transform_layer_menu"
    bl_label = "Transform Layer"

    def draw(self, context):
        layout = self.layout
        op = layout.operator(operators.IMAGE_EDITOR_PLUS_OT_flip_layer.bl_idname, text='Flip Horizontally', icon='MOD_MIRROR')
        op.is_vertically = False
        op = layout.operator(operators.IMAGE_EDITOR_PLUS_OT_flip_layer.bl_idname, text='Flip Vertically', icon='MOD_MIRROR')
        op.is_vertically = True
        op = layout.operator(operators.IMAGE_EDITOR_PLUS_OT_rotate_layer.bl_idname, text="Rotate 90\u00b0 Left", icon='FILE_REFRESH')
        op.is_left = True
        op = layout.operator(operators.IMAGE_EDITOR_PLUS_OT_rotate_layer.bl_idname, text="Rotate 90\u00b0 Right", icon='FILE_REFRESH')
        op.is_left = False
        op = layout.operator(operators.IMAGE_EDITOR_PLUS_OT_rotate_layer_arbitrary.bl_idname, text="Rotate Arbitrary", icon='FILE_REFRESH')
        op = layout.operator(operators.IMAGE_EDITOR_PLUS_OT_scale_layer.bl_idname, text="Scale", icon='FULLSCREEN_ENTER')

class IMAGE_EDITOR_PLUS_MT_offset_menu(bpy.types.Menu):
    bl_idname = "IMAGE_EDITOR_PLUS_MT_offset_menu"
    bl_label = "Offset"

    def draw(self, context):
        layout = self.layout
        layout.operator(IMAGE_EDITOR_PLUS_OT_offset_dialog.bl_idname, text='Offset...', icon='MOD_ARRAY')


class IMAGE_EDITOR_PLUS_PT_layers_panel(bpy.types.Panel):
    bl_label = "Layers"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Layers"

    @classmethod
    def poll(cls, context):
        return context.area.spaces.active.mode != 'UV' and context.area.spaces.active.image != None and context.area.spaces.active.image.source != 'VIEWER'

    def draw(self, context):
        layout = self.layout
        img = context.area.spaces.active.image
        if img:
            img_props = img.imageeditorplus_properties
            layers = img_props.layers
            
            # Main row with list and buttons column
            row = layout.row()
            
            # Layer list on the left
            row.template_list("IMAGE_EDITOR_PLUS_UL_layer_list", "", img_props, "layers", img_props, "selected_layer_index", rows=4)
            
            # Button column on the right
            col = row.column(align=True)
            col.operator(operators.IMAGE_EDITOR_PLUS_OT_add_image_layer.bl_idname, text='', icon='IMAGE_DATA')
            col.operator(operators.IMAGE_EDITOR_PLUS_OT_new_image_layer.bl_idname, text='', icon='ADD')
            col.separator()
            if layers:
                col.menu(IMAGE_EDITOR_PLUS_MT_layer_options_menu.bl_idname, text='', icon='DOWNARROW_HLT')
                col.separator()
                op = col.operator(operators.IMAGE_EDITOR_PLUS_OT_change_image_layer_order.bl_idname, text='', icon="TRIA_UP")
                op.up = True
                op = col.operator(operators.IMAGE_EDITOR_PLUS_OT_change_image_layer_order.bl_idname, text='', icon="TRIA_DOWN")
                op.up = False
            
            # Opacity slider for selected layer
            if layers and img_props.selected_layer_index >= 0 and img_props.selected_layer_index < len(layers):
                selected_layer = layers[img_props.selected_layer_index]
                row = layout.row()
                row.prop(selected_layer, 'opacity', slider=True)
                row = layout.row()
                row.prop(selected_layer, 'blend_mode', text='')

class IMAGE_EDITOR_PLUS_PT_transform_layer_panel(bpy.types.Panel):
    bl_label = "Transform Layer"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Layers"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return context.area.spaces.active.mode != 'UV' and context.area.spaces.active.image != None and context.area.spaces.active.image.source != 'VIEWER'

    def draw(self, context):
        wm = context.window_manager
        layout = self.layout
        row = layout.split(factor=0.8)
        op = row.operator(operators.IMAGE_EDITOR_PLUS_OT_flip_layer.bl_idname, text='Flip', icon='MOD_MIRROR')
        op.is_vertically = False
        op = row.operator(operators.IMAGE_EDITOR_PLUS_OT_flip_layer.bl_idname, text='', icon='MOD_MIRROR')
        op.is_vertically = True
        row = layout.split(factor=0.8)
        op = row.operator(operators.IMAGE_EDITOR_PLUS_OT_rotate_layer.bl_idname, text='Rotate', icon='FILE_REFRESH')
        op.is_left = True
        op = row.operator(operators.IMAGE_EDITOR_PLUS_OT_rotate_layer.bl_idname, text='', icon='FILE_REFRESH')
        op.is_left = False
        row = layout.row()
        row.operator(operators.IMAGE_EDITOR_PLUS_OT_rotate_layer_arbitrary.bl_idname, text='Rotate Arbitrary', icon='FILE_REFRESH')
        row = layout.row()
        row.operator(operators.IMAGE_EDITOR_PLUS_OT_scale_layer.bl_idname, text='Scale', icon='FULLSCREEN_ENTER')

class IMAGE_EDITOR_PLUS_PT_offset_panel(bpy.types.Panel):
    bl_label = "Offset"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Layers"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return context.area.spaces.active.mode != 'UV' and context.area.spaces.active.image != None and context.area.spaces.active.image.source != 'VIEWER'

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.operator(IMAGE_EDITOR_PLUS_OT_offset_dialog.bl_idname, text='Offset...', icon='MOD_ARRAY')
