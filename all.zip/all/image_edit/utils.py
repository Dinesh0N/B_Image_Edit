

import numpy as np

def read_pixels_from_image(img):
    width, height = img.size[0], img.size[1]
    pixels = np.empty(len(img.pixels), dtype=np.float32)
    img.pixels.foreach_get(pixels)
    return np.reshape(pixels, (height, width, 4))

def write_pixels_to_image(img, pixels):
    img.pixels.foreach_set(np.reshape(pixels, -1))
    if img.preview:
        img.preview.reload()

def convert_colorspace(pixels, src_colorspace, dest_colorspace):
    if src_colorspace == dest_colorspace:
        return
    if src_colorspace == 'Linear' and dest_colorspace == 'sRGB':
        pixels[:, :, 0:3] = pixels[:, :, :3] ** (1.0 / 2.2)
    elif src_colorspace == 'sRGB' and dest_colorspace == 'Linear':
        pixels[:, :, 0:3] = pixels[:, :, :3] ** 2.2
