
import math
import bpy
import numpy as np
from . import app
from . import utils

class IMAGE_EDITOR_PLUS_OT_make_selection(bpy.types.Operator):
    """Make a selection on the image"""
    bl_idname = "image_editor_plus.make_selection"
    bl_label = "Make Selection"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.lmb = False

    def modal(self, context, event):
        area_session = app.get_area_session(context)
        context.area.tag_redraw()
        img = context.area.spaces.active.image
        width, height = img.size[0], img.size[1]

        if event.type == 'MOUSEMOVE':
            if self.lmb:
                region_pos = [event.mouse_region_x, event.mouse_region_y]
                if area_session.selection_region:
                    area_session.selection_region[1] = region_pos
        elif event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                self.lmb = True
                region_pos = [event.mouse_region_x, event.mouse_region_y]
                area_session.selection_region = [region_pos, region_pos]
            elif event.value == 'RELEASE':
                self.lmb = False
                if area_session.selection_region:
                    area_session.selecting = False
                    app.convert_selection(context)
                    # Apply the selection as a paint mask
                    app.apply_selection_as_paint_mask(context)
                    img_props = img.imageeditorplus_properties
                    img_props.selected_layer_index = -1
                    return {'FINISHED'}
        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            area_session.selection = None
            area_session.selection_region = None
            area_session.selecting = False
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        area_session = app.get_area_session(context)
        if context.area.type != 'IMAGE_EDITOR':
            return {'CANCELLED'}
        area_session.selection = None
        area_session.selection_region = None
        area_session.selecting = True
        # Capture the initial mouse position from the first click
        self.lmb = True
        region_pos = [event.mouse_region_x, event.mouse_region_y]
        area_session.selection_region = [region_pos, region_pos[:]]
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

class IMAGE_EDITOR_PLUS_OT_cancel_selection(bpy.types.Operator):
    """Cancel the selection"""
    bl_idname = "image_editor_plus.cancel_selection"
    bl_label = "Cancel Selection"

    def execute(self, context):
        area_session = app.get_area_session(context)
        if not area_session.selection:
            return {'CANCELLED'}
        app.cancel_selection(context)
        context.area.tag_redraw()
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_swap_colors(bpy.types.Operator):
    """Swap foreground and background color"""
    bl_idname = "image_editor_plus.swap_colors"
    bl_label = "Swap Colors"

    def execute(self, context):
        wm = context.window_manager
        props = wm.imageeditorplus_properties
        props.foreground_color, props.background_color = props.background_color[:], props.foreground_color[:]
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_fill_with_fg_color(bpy.types.Operator):
    """Fill the image with foreground color"""
    bl_idname = "image_editor_plus.fill_with_fg_color"
    bl_label = "Fill with FG Color"

    def execute(self, context):
        wm = context.window_manager
        props = wm.imageeditorplus_properties
        color = props.foreground_color[:] + (1.0,)
        img = app.get_target_image(context)
        if not img:
            return {'CANCELLED'}
        pixels = utils.read_pixels_from_image(img)
        selection = app.get_target_selection(context)
        if selection:
            pixels[selection[0][1]:selection[1][1], selection[0][0]:selection[1][0]] = color
        elif selection == []:
            return {'CANCELLED'}
        else:
            pixels[:] = color
        utils.write_pixels_to_image(img, pixels)
        app.refresh_image(context)
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_fill_with_bg_color(bpy.types.Operator):
    """Fill the image with background color"""
    bl_idname = "image_editor_plus.fill_with_bg_color"
    bl_label = "Fill with BG Color"

    def execute(self, context):
        wm = context.window_manager
        props = wm.imageeditorplus_properties
        color = props.background_color[:] + (1.0,)
        img = app.get_target_image(context)
        if not img:
            return {'CANCELLED'}
        pixels = utils.read_pixels_from_image(img)
        selection = app.get_target_selection(context)
        if selection:
            pixels[selection[0][1]:selection[1][1], selection[0][0]:selection[1][0]] = color
        elif selection == []:
            return {'CANCELLED'}
        else:
            pixels[:] = color
        utils.write_pixels_to_image(img, pixels)
        app.refresh_image(context)
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_clear(bpy.types.Operator):
    """Clear the image"""
    bl_idname = "image_editor_plus.clear"
    bl_label = "Clear"

    def execute(self, context):
        img = app.get_target_image(context)
        if not img:
            return {'CANCELLED'}
        pixels = utils.read_pixels_from_image(img)
        selection = app.get_target_selection(context)
        if selection:
            pixels[selection[0][1]:selection[1][1], selection[0][0]:selection[1][0]] = (0, 0, 0, 0)
        elif selection == []:
            return {'CANCELLED'}
        else:
            pixels[:] = (0, 0, 0, 0)
        utils.write_pixels_to_image(img, pixels)
        app.refresh_image(context)
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_cut(bpy.types.Operator):
    """Cut the image"""
    bl_idname = "image_editor_plus.cut"
    bl_label = "Cut"

    def execute(self, context):
        session = app.get_session()
        img = app.get_target_image(context)
        if not img:
            return {'CANCELLED'}
        width, height = img.size
        pixels = utils.read_pixels_from_image(img)
        selection = app.get_target_selection(context)
        if selection:
            target_pixels = pixels[selection[0][1]:selection[1][1], selection[0][0]:selection[1][0]]
        elif selection == []:
            return {'CANCELLED'}
        else:
            target_pixels = pixels
        session.copied_image_pixels = target_pixels.copy()
        session.copied_image_settings = {'is_float': img.is_float, 'colorspace_name': img.colorspace_settings.name}
        layer = app.get_active_layer(context)
        if layer:
            session.copied_layer_settings = {'rotation': layer.rotation, 'scale': layer.scale, 'custom_data': layer.custom_data}
        else:
            session.copied_layer_settings = None
        if selection:
            pixels[selection[0][1]:selection[1][1], selection[0][0]:selection[1][0]] = (0, 0, 0, 0)
        else:
            pixels[:] = (0, 0, 0, 0)
        utils.write_pixels_to_image(img, pixels)
        app.refresh_image(context)
        self.report({'INFO'}, 'Cut selected image.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_copy(bpy.types.Operator):
    """Copy the image"""
    bl_idname = "image_editor_plus.copy"
    bl_label = "Copy"

    def execute(self, context):
        session = app.get_session()
        img = app.get_target_image(context)
        if not img:
            return {'CANCELLED'}
        width, height = img.size
        pixels = utils.read_pixels_from_image(img)
        selection = app.get_target_selection(context)
        if selection:
            target_pixels = pixels[selection[0][1]:selection[1][1], selection[0][0]:selection[1][0]]
        elif selection == []:
            return {'CANCELLED'}
        else:
            target_pixels = pixels
        session.copied_image_pixels = target_pixels
        session.copied_image_settings = {'is_float': img.is_float, 'colorspace_name': img.colorspace_settings.name}
        layer = app.get_active_layer(context)
        if layer:
            session.copied_layer_settings = {'rotation': layer.rotation, 'scale': layer.scale, 'custom_data': layer.custom_data}
        else:
            session.copied_layer_settings = None
        self.report({'INFO'}, 'Copied selected image.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_paste(bpy.types.Operator):
    """Paste the image"""
    bl_idname = "image_editor_plus.paste"
    bl_label = "Paste"

    def execute(self, context):
        session = app.get_session()
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        target_pixels = session.copied_image_pixels
        if target_pixels is None:
            return {'CANCELLED'}
        app.create_layer(img, target_pixels, session.copied_image_settings, session.copied_layer_settings)
        app.cancel_selection(context)
        app.refresh_image(context)
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_cut_to_layer(bpy.types.Operator):
    """Cut selection and paste as new layer"""
    bl_idname = "image_editor_plus.cut_to_layer"
    bl_label = "Cut Selection to New Layer"

    def execute(self, context):
        session = app.get_session()
        img = app.get_target_image(context)
        base_img = context.area.spaces.active.image
        if not img or not base_img:
            return {'CANCELLED'}
        pixels = utils.read_pixels_from_image(img)
        selection = app.get_target_selection(context)
        if selection:
            target_pixels = pixels[selection[0][1]:selection[1][1], selection[0][0]:selection[1][0]].copy()
        elif selection == []:
            return {'CANCELLED'}
        else:
            target_pixels = pixels.copy()
        
        img_settings = {'is_float': img.is_float, 'colorspace_name': img.colorspace_settings.name}
        layer = app.get_active_layer(context)
        if layer:
            layer_settings = {'rotation': layer.rotation, 'scale': layer.scale, 'custom_data': layer.custom_data}
        else:
            layer_settings = None
        
        # Clear the cut area
        if selection:
            pixels[selection[0][1]:selection[1][1], selection[0][0]:selection[1][0]] = (0, 0, 0, 0)
        else:
            pixels[:] = (0, 0, 0, 0)
        utils.write_pixels_to_image(img, pixels)
        
        # Create layer from cut pixels
        app.create_layer(base_img, target_pixels, img_settings, layer_settings)
        app.cancel_selection(context)
        app.refresh_image(context)
        self.report({'INFO'}, 'Cut selection to new layer.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_copy_to_layer(bpy.types.Operator):
    """Copy selection and paste as new layer"""
    bl_idname = "image_editor_plus.copy_to_layer"
    bl_label = "Copy Selection to New Layer"

    def execute(self, context):
        session = app.get_session()
        img = app.get_target_image(context)
        base_img = context.area.spaces.active.image
        if not img or not base_img:
            return {'CANCELLED'}
        pixels = utils.read_pixels_from_image(img)
        selection = app.get_target_selection(context)
        if selection:
            target_pixels = pixels[selection[0][1]:selection[1][1], selection[0][0]:selection[1][0]].copy()
        elif selection == []:
            return {'CANCELLED'}
        else:
            target_pixels = pixels.copy()
        
        img_settings = {'is_float': img.is_float, 'colorspace_name': img.colorspace_settings.name}
        layer = app.get_active_layer(context)
        if layer:
            layer_settings = {'rotation': layer.rotation, 'scale': layer.scale, 'custom_data': layer.custom_data}
        else:
            layer_settings = None
        
        # Create layer from copied pixels
        app.create_layer(base_img, target_pixels, img_settings, layer_settings)
        app.cancel_selection(context)
        app.refresh_image(context)
        self.report({'INFO'}, 'Copied selection to new layer.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_add_image_layer(bpy.types.Operator):
    """Add image file(s) as new layer(s)"""
    bl_idname = "image_editor_plus.add_image_layer"
    bl_label = "Add Image as Layer"
    
    filepath: bpy.props.StringProperty(subtype='FILE_PATH')
    directory: bpy.props.StringProperty(subtype='DIR_PATH')
    files: bpy.props.CollectionProperty(type=bpy.types.OperatorFileListElement)
    filter_glob: bpy.props.StringProperty(default="*.png;*.jpg;*.jpeg;*.bmp;*.tga;*.tiff;*.exr;*.hdr", options={'HIDDEN'})

    def execute(self, context):
        import os
        img = context.area.spaces.active.image
        if not img:
            self.report({'ERROR'}, "No active image")
            return {'CANCELLED'}
        
        # Handle multiple files
        if self.files:
            filepaths = [os.path.join(self.directory, f.name) for f in self.files if f.name]
        else:
            filepaths = [self.filepath]
        
        added_count = 0
        for filepath in filepaths:
            if not filepath or not os.path.isfile(filepath):
                continue
            
            # Load the image file
            try:
                layer_source = bpy.data.images.load(filepath)
            except:
                self.report({'WARNING'}, f"Could not load: {os.path.basename(filepath)}")
                continue
            
            # Get original filename (without extension) for layer label
            original_filename = os.path.splitext(os.path.basename(filepath))[0]
            
            # Read pixels from loaded image
            target_pixels = utils.read_pixels_from_image(layer_source)
            
            img_settings = {
                'is_float': layer_source.is_float,
                'colorspace_name': layer_source.colorspace_settings.name
            }
            
            # Create layer from loaded image with original filename as label
            app.create_layer(img, target_pixels, img_settings, None, custom_label=original_filename)
            
            # Remove the temporary loaded image (we copied its pixels)
            bpy.data.images.remove(layer_source)
            added_count += 1
        
        if added_count == 0:
            self.report({'ERROR'}, "No images were added")
            return {'CANCELLED'}
        
        app.cancel_selection(context)
        app.refresh_image(context)
        
        self.report({'INFO'}, f'{added_count} image(s) added as layers.')
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class IMAGE_EDITOR_PLUS_OT_new_image_layer(bpy.types.Operator):
    """Create a new blank image as a layer"""
    bl_idname = "image_editor_plus.new_image_layer"
    bl_label = "New Image Layer"
    
    layer_name: bpy.props.StringProperty(name='Name', default='New Layer')
    width: bpy.props.IntProperty(name='Width', default=512, min=1, max=16384)
    height: bpy.props.IntProperty(name='Height', default=512, min=1, max=16384)
    color: bpy.props.FloatVectorProperty(name='Color', subtype='COLOR', size=4, min=0, max=1, default=(1.0, 1.0, 1.0, 0.0))
    use_base_size: bpy.props.BoolProperty(name='Use Base Image Size', default=True)

    def invoke(self, context, event):
        img = context.area.spaces.active.image
        if img:
            self.width = img.size[0]
            self.height = img.size[1]
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        import numpy as np
        img = context.area.spaces.active.image
        if not img:
            self.report({'ERROR'}, "No active image")
            return {'CANCELLED'}
        
        if self.use_base_size:
            layer_width = img.size[0]
            layer_height = img.size[1]
        else:
            layer_width = self.width
            layer_height = self.height
        
        # Create blank pixels with the specified color
        pixels = np.full((layer_height, layer_width, 4), self.color, dtype=np.float32)
        
        img_settings = {
            'is_float': img.is_float,
            'colorspace_name': img.colorspace_settings.name
        }
        
        # Create layer from blank pixels
        layer_label = self.layer_name if self.layer_name else "New Layer"
        app.create_layer(img, pixels, img_settings, None, custom_label=layer_label)
        
        app.cancel_selection(context)
        app.refresh_image(context)
        
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'layer_name')
        layout.prop(self, 'use_base_size')
        if not self.use_base_size:
            layout.prop(self, 'width')
            layout.prop(self, 'height')
        layout.prop(self, 'color')

class IMAGE_EDITOR_PLUS_OT_crop(bpy.types.Operator):
    """Crop the image to the boundary of the selection"""
    bl_idname = "image_editor_plus.crop"
    bl_label = "Crop"

    def execute(self, context):
        wm = context.window_manager
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        pixels = utils.read_pixels_from_image(img)
        selection = app.get_selection(context)
        if selection:
            target_pixels = pixels[selection[0][1]:selection[1][1], selection[0][0]:selection[1][0]]
        else:
            target_pixels = pixels
        target_width, target_height = target_pixels.shape[1], target_pixels.shape[0]
        img.scale(target_width, target_height)
        utils.write_pixels_to_image(img, target_pixels)
        if selection:
            img_props = img.imageeditorplus_properties
            layers = img_props.layers
            for layer in reversed(layers):
                layer_pos = layer.location
                layer_pos[0] -= selection[0][0]
                layer_pos[1] -= selection[0][1]
        app.cancel_selection(context)
        app.refresh_image(context)
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_deselect_layer(bpy.types.Operator):
    bl_idname = "image_editor_plus.deselect_layer"
    bl_label = "Deselect Layer"

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        img_props = img.imageeditorplus_properties
        img_props.selected_layer_index = -1
        app.refresh_image(context)
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_move_layer(bpy.types.Operator):
    """Move the layer"""
    bl_idname = "image_editor_plus.move_layer"
    bl_label = "Move Layer"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.start_input_position = [0, 0]
        self.start_layer_location = [0, 0]

    def modal(self, context, event):
        area_session = app.get_area_session(context)
        context.area.tag_redraw()
        img = context.area.spaces.active.image
        width, height = img.size[0], img.size[1]
        layer = app.get_active_layer(context)
        if not layer:
            return {'CANCELLED'}
        layer_width, layer_height = 1, 1
        layer_img = bpy.data.images.get(layer.name, None)
        if layer_img:
            layer_width, layer_height = layer_img.size[0], layer_img.size[1]
        if event.type == 'MOUSEMOVE':
            region_pos = [event.mouse_region_x, event.mouse_region_y]
            view_x, view_y = context.region.view2d.region_to_view(*region_pos)
            target_x = width * view_x
            target_y = height * view_y
            layer.location[0] = int(self.start_layer_location[0] + target_x - self.start_input_position[0])
            layer.location[1] = int(self.start_layer_location[1] - (target_y - self.start_input_position[1]))
        elif event.type == 'LEFTMOUSE':
            app.rebuild_image_layers_nodes(img)
            area_session.layer_moving = False
            area_session.prevent_layer_update_event = False
            return {'FINISHED'}
        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            layer.location = self.start_layer_location
            area_session.layer_moving = False
            area_session.prevent_layer_update_event = False
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        area_session = app.get_area_session(context)
        img = context.area.spaces.active.image
        width, height = img.size[0], img.size[1]
        layer = app.get_active_layer(context)
        if not layer:
            return {'CANCELLED'}
        if layer.locked:
            self.report({'WARNING'}, 'Layer is locked.')
            return {'CANCELLED'}
        region_pos = [event.mouse_region_x, event.mouse_region_y]
        view_x, view_y = context.region.view2d.region_to_view(*region_pos)
        self.start_input_position = [width * view_x, height * view_y]
        self.start_layer_location = layer.location[:]
        area_session.layer_moving = True
        area_session.prevent_layer_update_event = True
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

class IMAGE_EDITOR_PLUS_OT_delete_layer(bpy.types.Operator):
    bl_idname = "image_editor_plus.delete_layer"
    bl_label = "Delete Layer"

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        selected_layer_index = img_props.selected_layer_index
        if selected_layer_index == -1 or selected_layer_index >= len(layers):
            return {'CANCELLED'}
        layer = layers[selected_layer_index]
        if layer.locked:
            self.report({'WARNING'}, 'Layer is locked.')
            return {'CANCELLED'}
        layer_img = bpy.data.images.get(layer.name, None)
        if layer_img:
            bpy.data.images.remove(layer_img)
        layers.remove(selected_layer_index)
        selected_layer_index = min(max(selected_layer_index, 0), len(layers) - 1)
        img_props.selected_layer_index = selected_layer_index
        app.rebuild_image_layers_nodes(img)
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_duplicate_layer(bpy.types.Operator):
    """Duplicate the selected layer"""
    bl_idname = "image_editor_plus.duplicate_layer"
    bl_label = "Duplicate Layer"

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        layer = app.get_active_layer(context)
        if not layer:
            return {'CANCELLED'}
        
        layer_img = bpy.data.images.get(layer.name, None)
        if not layer_img:
            return {'CANCELLED'}
        
        # Read pixels from the layer image
        pixels = utils.read_pixels_from_image(layer_img)
        
        img_settings = {
            'is_float': layer_img.is_float,
            'colorspace_name': layer_img.colorspace_settings.name
        }
        
        layer_settings = {
            'rotation': layer.rotation,
            'scale': list(layer.scale),
            'custom_data': layer.custom_data
        }
        
        # Create a duplicate layer
        app.create_layer(img, pixels, img_settings, layer_settings, custom_label=layer.label + " Copy")
        
        app.refresh_image(context)
        self.report({'INFO'}, 'Layer duplicated.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_lock_all_layers(bpy.types.Operator):
    """Lock all layers"""
    bl_idname = "image_editor_plus.lock_all_layers"
    bl_label = "Lock All Layers"

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        for layer in layers:
            layer.locked = True
        self.report({'INFO'}, 'All layers locked.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_unlock_all_layers(bpy.types.Operator):
    """Unlock all layers"""
    bl_idname = "image_editor_plus.unlock_all_layers"
    bl_label = "Unlock All Layers"

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        for layer in layers:
            layer.locked = False
        self.report({'INFO'}, 'All layers unlocked.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_hide_all_layers(bpy.types.Operator):
    """Hide all layers"""
    bl_idname = "image_editor_plus.hide_all_layers"
    bl_label = "Hide All Layers"

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        for layer in layers:
            layer.hide = True
        app.refresh_image(context)
        self.report({'INFO'}, 'All layers hidden.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_show_all_layers(bpy.types.Operator):
    """Show all layers"""
    bl_idname = "image_editor_plus.show_all_layers"
    bl_label = "Show All Layers"

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        for layer in layers:
            layer.hide = False
        app.refresh_image(context)
        self.report({'INFO'}, 'All layers shown.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_delete_all_layers(bpy.types.Operator):
    """Delete all layers"""
    bl_idname = "image_editor_plus.delete_all_layers"
    bl_label = "Delete All Layers"

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        
        # Remove layer images
        for layer in layers:
            layer_img = bpy.data.images.get(layer.name, None)
            if layer_img:
                bpy.data.images.remove(layer_img)
        
        layers.clear()
        img_props.selected_layer_index = -1
        app.rebuild_image_layers_nodes(img)
        app.refresh_image(context)
        self.report({'INFO'}, 'All layers deleted.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_update_layer_previews(bpy.types.Operator):
    """Update all layer preview thumbnails"""
    bl_idname = "image_editor_plus.update_layer_previews"
    bl_label = "Update Layer Previews"

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        
        # Update preview for each layer image
        for layer in layers:
            layer_img = bpy.data.images.get(layer.name, None)
            if layer_img:
                layer_img.update()
                if layer_img.preview:
                    layer_img.preview.reload()
        
        # Also update the base image
        img.update()
        if img.preview:
            img.preview.reload()
        
        context.area.tag_redraw()
        self.report({'INFO'}, 'Layer previews updated.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_select_all_layers(bpy.types.Operator):
    """Select all layers"""
    bl_idname = "image_editor_plus.select_all_layers"
    bl_label = "Select All Layers"

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        for layer in layers:
            layer.checked = True
        self.report({'INFO'}, 'All layers selected.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_deselect_all_layers(bpy.types.Operator):
    """Deselect all layers"""
    bl_idname = "image_editor_plus.deselect_all_layers"
    bl_label = "Deselect All Layers"

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        for layer in layers:
            layer.checked = False
        self.report({'INFO'}, 'All layers deselected.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_invert_layer_selection(bpy.types.Operator):
    """Invert layer selection"""
    bl_idname = "image_editor_plus.invert_layer_selection"
    bl_label = "Invert Layer Selection"

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        for layer in layers:
            layer.checked = not layer.checked
        self.report({'INFO'}, 'Layer selection inverted.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_delete_selected_layers(bpy.types.Operator):
    """Delete all selected (checked) layers"""
    bl_idname = "image_editor_plus.delete_selected_layers"
    bl_label = "Delete Selected Layers"

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        
        # Get indices of checked layers (in reverse order to safely remove)
        indices_to_remove = []
        for i, layer in enumerate(layers):
            if layer.checked and not layer.locked:
                indices_to_remove.append(i)
        
        if not indices_to_remove:
            self.report({'WARNING'}, 'No unlocked layers selected.')
            return {'CANCELLED'}
        
        # Remove in reverse order to avoid index shifting
        for i in reversed(indices_to_remove):
            layer = layers[i]
            layer_img = bpy.data.images.get(layer.name, None)
            if layer_img:
                bpy.data.images.remove(layer_img)
            layers.remove(i)
        
        # Adjust selected layer index
        if len(layers) > 0:
            img_props.selected_layer_index = min(img_props.selected_layer_index, len(layers) - 1)
        else:
            img_props.selected_layer_index = -1
        
        app.rebuild_image_layers_nodes(img)
        app.refresh_image(context)
        self.report({'INFO'}, f'{len(indices_to_remove)} layers deleted.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_merge_selected_layers(bpy.types.Operator):
    """Merge all selected (checked) layers"""
    bl_idname = "image_editor_plus.merge_selected_layers"
    bl_label = "Merge Selected Layers"

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        width, height = img.size
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        
        # Get checked layers
        checked_layers = [(i, layer) for i, layer in enumerate(layers) if layer.checked]
        
        if len(checked_layers) < 2:
            self.report({'WARNING'}, 'Select at least 2 layers to merge.')
            return {'CANCELLED'}
        
        # Start with base image pixels
        pixels = utils.read_pixels_from_image(img)
        
        # Only merge checked layers (in reverse order for proper compositing)
        merged_count = 0
        indices_to_remove = []
        
        for i, layer in reversed(checked_layers):
            layer_img = bpy.data.images.get(layer.name, None)
            if not layer_img:
                continue
            layer_width, layer_height = layer_img.size[0], layer_img.size[1]
            layer_pos = layer.location
            layer_x1, layer_y1 = layer_pos[0], height - layer_height - layer_pos[1]
            
            if layer.rotation == 0 and layer.scale[0] == 1.0 and layer.scale[1] == 1.0:
                layer_pixels = utils.read_pixels_from_image(layer_img)
            else:
                layer_pixels, new_layer_width, new_layer_height = app.apply_layer_transform(layer_img, layer.rotation, layer.scale)
                layer_x1 = int(layer_x1 - (new_layer_width - layer_width) / 2.0)
                layer_y1 = int(layer_y1 - (new_layer_height - layer_height) / 2.0)
                layer_width = new_layer_width
                layer_height = new_layer_height
            
            layer_x2 = layer_x1 + layer_width
            layer_y2 = layer_y1 + layer_height
            target_x1 = max(min(layer_x1, width), 0)
            target_y1 = max(min(layer_y1, height), 0)
            target_x2 = max(min(layer_x2, width), 0)
            target_y2 = max(min(layer_y2, height), 0)
            
            if layer_x1 == layer_x2 or layer_y1 == layer_y2:
                continue
            
            src_x1 = target_x1 - layer_x1
            src_y1 = target_y1 - layer_y1
            src_x2 = layer_width - (layer_x2 - target_x2)
            src_y2 = layer_height - (layer_y2 - target_y2)
            
            target_range = pixels[target_y1:target_y2, target_x1:target_x2]
            target_color_chan = target_range[:, :, :3]
            target_alpha_chan = target_range[:, :, 3:4]
            layer_range = layer_pixels[src_y1:src_y2, src_x1:src_x2]
            layer_color_chan = layer_range[:, :, :3]
            layer_alpha_chan = layer_range[:, :, 3:4]
            temp_alpha_chan = target_alpha_chan * (1.0 - layer_alpha_chan) + layer_alpha_chan
            temp_alpha_chan_safe = np.where(temp_alpha_chan == 0, 1.0, temp_alpha_chan)
            pixels[target_y1:target_y2, target_x1:target_x2, :3] = (target_color_chan * target_alpha_chan * (1.0 - layer_alpha_chan) + layer_color_chan * layer_alpha_chan) / temp_alpha_chan_safe
            pixels[target_y1:target_y2, target_x1:target_x2, 3:4] = temp_alpha_chan
            
            bpy.data.images.remove(layer_img)
            indices_to_remove.append(i)
            merged_count += 1
        
        # Remove merged layers
        for i in sorted(indices_to_remove, reverse=True):
            layers.remove(i)
        
        utils.write_pixels_to_image(img, pixels)
        
        # Adjust selected layer index
        if len(layers) > 0:
            img_props.selected_layer_index = min(img_props.selected_layer_index, len(layers) - 1)
        else:
            img_props.selected_layer_index = -1
        
        app.rebuild_image_layers_nodes(img)
        app.refresh_image(context)
        self.report({'INFO'}, f'{merged_count} layers merged.')
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_change_image_layer_order(bpy.types.Operator):
    bl_idname = "image_editor_plus.change_image_layer_order"
    bl_label = "Change Image Layer Order"
    up: bpy.props.BoolProperty()

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        selected_layer_index = img_props.selected_layer_index
        if selected_layer_index == -1 or selected_layer_index >= len(layers):
            return {'CANCELLED'}
        if (self.up and selected_layer_index == 0) or (not self.up and selected_layer_index >= len(layers) - 1):
            return {'CANCELLED'}
        layer = layers[selected_layer_index]
        new_layer_index = selected_layer_index + (-1 if self.up else 1)
        layers.move(selected_layer_index, new_layer_index)
        img_props.selected_layer_index = new_layer_index
        app.rebuild_image_layers_nodes(img)
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_merge_layers(bpy.types.Operator):
    """Merge all layers"""
    bl_idname = "image_editor_plus.merge_layers"
    bl_label = "Merge Layers"

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        width, height = img.size
        pixels = utils.read_pixels_from_image(img)
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        for layer in reversed(layers):
            layer_img = bpy.data.images.get(layer.name, None)
            if not layer_img:
                continue
            layer_width, layer_height = layer_img.size[0], layer_img.size[1]
            layer_pos = layer.location
            layer_x1, layer_y1 = layer_pos[0], height - layer_height - layer_pos[1]
            if layer.rotation == 0 and layer.scale[0] == 1.0 and layer.scale[1] == 1.0:
                layer_pixels = utils.read_pixels_from_image(layer_img)
            else:
                layer_pixels, new_layer_width, new_layer_height = app.apply_layer_transform(layer_img, layer.rotation, layer.scale)
                layer_x1 = int(layer_x1 - (new_layer_width - layer_width) / 2.0)
                layer_y1 = int(layer_y1 - (new_layer_height - layer_height) / 2.0)
                layer_width = new_layer_width
                layer_height = new_layer_height
            layer_x2 = layer_x1 + layer_width
            layer_y2 = layer_y1 + layer_height
            target_x1 = max(min(layer_x1, width), 0)
            target_y1 = max(min(layer_y1, height), 0)
            target_x2 = max(min(layer_x2, width), 0)
            target_y2 = max(min(layer_y2, height), 0)
            if layer_x1 == layer_x2 or layer_y1 == layer_y2:
                continue
            src_x1 = target_x1 - layer_x1
            src_y1 = target_y1 - layer_y1
            src_x2 = layer_width - (layer_x2 - target_x2)
            src_y2 = layer_height - (layer_y2 - target_y2)
            target_range = pixels[target_y1:target_y2, target_x1:target_x2]
            target_color_chan = target_range[:, :, :3]
            target_alpha_chan = target_range[:, :, 3:4]
            layer_range = layer_pixels[src_y1:src_y2, src_x1:src_x2]
            layer_color_chan = layer_range[:, :, :3]
            layer_alpha_chan = layer_range[:, :, 3:4]
            temp_alpha_chan = target_alpha_chan * (1.0 - layer_alpha_chan) + layer_alpha_chan
            temp_alpha_chan_safe = np.where(temp_alpha_chan == 0, 1.0, temp_alpha_chan)
            pixels[target_y1:target_y2, target_x1:target_x2, :3] = (target_color_chan * target_alpha_chan * (1.0 - layer_alpha_chan) + layer_color_chan * layer_alpha_chan) / temp_alpha_chan_safe
            pixels[target_y1:target_y2, target_x1:target_x2, 3:4] = temp_alpha_chan
            bpy.data.images.remove(layer_img)
        utils.write_pixels_to_image(img, pixels)
        layers.clear()
        app.rebuild_image_layers_nodes(img)
        app.refresh_image(context)
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_flip(bpy.types.Operator):
    """Flip the image"""
    bl_idname = "image_editor_plus.flip"
    bl_label = "Flip"
    is_vertically: bpy.props.BoolProperty(name="Vertically", default=False)

    def execute(self, context):
        wm = context.window_manager
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        width, height = img.size
        pixels = utils.read_pixels_from_image(img)
        if self.is_vertically:
            new_pixels = np.flipud(pixels)
        else:
            new_pixels = np.fliplr(pixels)
        utils.write_pixels_to_image(img, new_pixels)
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        for layer in reversed(layers):
            layer_img = bpy.data.images.get(layer.name, None)
            if not layer_img:
                continue
            layer_width, layer_height = layer_img.size[0], layer_img.size[1]
            layer_pos = layer.location
            if self.is_vertically:
                layer_pos[1] = height - layer_pos[1] - layer_height
                layer.scale[1] *= -1.0
            else:
                layer_pos[0] = width - layer_pos[0] - layer_width
                layer.scale[0] *= -1.0
            layer.rotation = -layer.rotation
        app.refresh_image(context)
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_rotate(bpy.types.Operator):
    """Rotate the image"""
    bl_idname = "image_editor_plus.rotate"
    bl_label = "Rotate"
    is_left: bpy.props.BoolProperty(name="Left", default=False)

    def execute(self, context):
        wm = context.window_manager
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        width, height = img.size
        pixels = utils.read_pixels_from_image(img)
        if self.is_left:
            new_pixels = np.rot90(pixels, 3)
        else:
            new_pixels = np.rot90(pixels)
        img.scale(height, width)
        utils.write_pixels_to_image(img, new_pixels)
        img_props = img.imageeditorplus_properties
        layers = img_props.layers
        for layer in reversed(layers):
            layer_img = bpy.data.images.get(layer.name, None)
            if not layer_img:
                continue
            layer_width, layer_height = layer_img.size[0], layer_img.size[1]
            layer_pos = layer.location
            prev_layer_x, prev_layer_y = layer_pos[0], layer_pos[1]
            if self.is_left:
                layer_pos[0] = height - prev_layer_y - layer_height - (layer_width - layer_height) / 2.0
                layer_pos[1] = prev_layer_x + (layer_width - layer_height) / 2.0
                layer.rotation += math.pi / 2.0
            else:
                layer_pos[0] = prev_layer_y - (layer_width - layer_height) / 2.0
                layer_pos[1] = width - prev_layer_x - layer_width + (layer_width - layer_height) / 2.0
                layer.rotation -= math.pi / 2.0
        app.refresh_image(context)
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_scale(bpy.types.Operator):
    """Apply settings"""
    bl_idname = "image_editor_plus.scale"
    bl_label = "Scale"
    width: bpy.props.IntProperty()
    height: bpy.props.IntProperty()
    scale_layers: bpy.props.BoolProperty()

    def execute(self, context):
        wm = context.window_manager
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        width, height = img.size
        img.scale(self.width, self.height)
        if self.scale_layers:
            scale_x = self.width / width
            scale_y = self.height / height
            img_props = img.imageeditorplus_properties
            layers = img_props.layers
            for layer in reversed(layers):
                layer_img = bpy.data.images.get(layer.name, None)
                if not layer_img:
                    continue
                layer_width, layer_height = layer_img.size[0], layer_img.size[1]
                layer_scale = layer.scale
                layer_scale[0] *= scale_x
                layer_scale[1] *= scale_y
                layer_pos = layer.location
                layer_pos[0] = layer_pos[0] * scale_x - layer_width * (1.0 - scale_x) / 2.0
                layer_pos[1] = layer_pos[1] * scale_y - layer_height * (1.0 - scale_y) / 2.0
        app.refresh_image(context)
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_change_canvas_size(bpy.types.Operator):
    """Apply settings"""
    bl_idname = "image_editor_plus.change_canvas_size"
    bl_label = "Change Canvas Size"
    width: bpy.props.IntProperty()
    height: bpy.props.IntProperty()
    expand_from_center: bpy.props.BoolProperty()
    use_background_color: bpy.props.BoolProperty()

    def execute(self, context):
        wm = context.window_manager
        props = wm.imageeditorplus_properties
        if self.use_background_color:
            color = props.background_color[:] + (1.0,)
        else:
            color = (0, 0, 0, 0)
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        width, height = img.size
        pixels = utils.read_pixels_from_image(img)
        if self.width > width or self.height > height:
            expand_width = self.width - width if self.width > width else 0
            expand_height = self.height - height if self.height > height else 0
            if self.expand_from_center:
                expand_left = int(expand_width / 2)
                expand_top = int(expand_height / 2)
                expand_right = expand_width - expand_left
                expand_bottom = expand_height - expand_top
            else:
                expand_left, expand_top = 0, 0
                expand_right = expand_width
                expand_bottom = expand_height
            new_pixels = np.pad(pixels, ((expand_bottom, expand_top), (expand_left, expand_right), (0, 0)), constant_values=np.array(((color, color), (color, color), (0, 0)), dtype=object))
        else:
            new_pixels = pixels
        if self.width < width or self.height < height:
            shrink_width = width - self.width if self.width < width else 0
            shrink_height = height - self.height if self.height < height else 0
            if self.expand_from_center:
                shrink_left = int(shrink_width / 2)
                shrink_top = int(shrink_height / 2)
            else:
                shrink_left, shrink_top = 0, 0
            if self.height < height:
                new_pixels = new_pixels[height - self.height - shrink_top:height - shrink_top, shrink_left:self.width + shrink_left]
            else:
                new_pixels = new_pixels[0:self.height, shrink_left:self.width + shrink_left]
        img.scale(self.width, self.height)
        utils.write_pixels_to_image(img, new_pixels)
        app.refresh_image(context)
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_flip_layer(bpy.types.Operator):
    """Flip the layer"""
    bl_idname = "image_editor_plus.flip_layer"
    bl_label = "Flip Layer"
    is_vertically: bpy.props.BoolProperty(name="Vertically", default=False)

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        layer = app.get_active_layer(context)
        if not layer:
            return {'CANCELLED'}
        if layer.locked:
            self.report({'WARNING'}, 'Layer is locked.')
            return {'CANCELLED'}
        if self.is_vertically:
            layer.scale[1] *= -1.0
        else:
            layer.scale[0] *= -1.0
        app.refresh_image(context)
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_rotate_layer(bpy.types.Operator):
    """Rotate the layer"""
    bl_idname = "image_editor_plus.rotate_layer"
    bl_label = "Rotate Layer"
    is_left: bpy.props.BoolProperty(name="Left", default=False)

    def execute(self, context):
        img = context.area.spaces.active.image
        if not img:
            return {'CANCELLED'}
        layer = app.get_active_layer(context)
        if not layer:
            return {'CANCELLED'}
        if layer.locked:
            self.report({'WARNING'}, 'Layer is locked.')
            return {'CANCELLED'}
        layer.rotation += math.pi / 2.0 if self.is_left else -math.pi / 2.0
        app.refresh_image(context)
        return {'FINISHED'}

class IMAGE_EDITOR_PLUS_OT_rotate_layer_arbitrary(bpy.types.Operator):
    """Rotate the image by a specified angle"""
    bl_idname = "image_editor_plus.rotate_layer_arbitrary"
    bl_label = "Rotate Layer Arbitrary"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.start_input_position = [0, 0]
        self.start_layer_angle = 0

    def modal(self, context, event):
        area_session = app.get_area_session(context)
        context.area.tag_redraw()
        img = context.area.spaces.active.image
        width, height = img.size[0], img.size[1]
        layer = app.get_active_layer(context)
        if not layer:
            return {'CANCELLED'}
        layer_width, layer_height = 1, 1
        layer_img = bpy.data.images.get(layer.name, None)
        if layer_img:
            layer_width, layer_height = layer_img.size[0], layer_img.size[1]
        if event.type == 'MOUSEMOVE':
            center_x = layer.location[0] + layer_width / 2.0
            center_y = height - layer.location[1] - layer_height / 2.0
            region_pos = [event.mouse_region_x, event.mouse_region_y]
            view_x, view_y = context.region.view2d.region_to_view(*region_pos)
            target_x = width * view_x
            target_y = height * view_y
            angle1 = math.atan2(self.start_input_position[1] - center_y, self.start_input_position[0] - center_x)
            angle2 = math.atan2(target_y - center_y, target_x - center_x)
            layer.rotation = self.start_layer_angle + angle2 - angle1
        elif event.type == 'LEFTMOUSE':
            app.rebuild_image_layers_nodes(img)
            area_session.layer_rotating = False
            area_session.prevent_layer_update_event = False
            return {'FINISHED'}
        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            layer.rotation = self.start_layer_angle
            area_session.layer_rotating = False
            area_session.prevent_layer_update_event = False
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        area_session = app.get_area_session(context)
        img = context.area.spaces.active.image
        width, height = img.size[0], img.size[1]
        layer = app.get_active_layer(context)
        if not layer:
            return {'CANCELLED'}
        if layer.locked:
            self.report({'WARNING'}, 'Layer is locked.')
            return {'CANCELLED'}
        region_pos = [event.mouse_region_x, event.mouse_region_y]
        view_x, view_y = context.region.view2d.region_to_view(*region_pos)
        self.start_input_position = [width * view_x, height * view_y]
        self.start_layer_angle = layer.rotation
        area_session.layer_rotating = True
        area_session.prevent_layer_update_event = True
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

class IMAGE_EDITOR_PLUS_OT_scale_layer(bpy.types.Operator):
    """Scale the layer"""
    bl_idname = "image_editor_plus.scale_layer"
    bl_label = "Scale Layer"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.start_input_position = [0, 0]
        self.start_layer_scale_x = 1.0
        self.start_layer_scale_y = 1.0

    def modal(self, context, event):
        area_session = app.get_area_session(context)
        context.area.tag_redraw()
        img = context.area.spaces.active.image
        width, height = img.size[0], img.size[1]
        layer = app.get_active_layer(context)
        if not layer:
            return {'CANCELLED'}
        layer_width, layer_height = 1, 1
        layer_img = bpy.data.images.get(layer.name, None)
        if layer_img:
            layer_width, layer_height = layer_img.size[0], layer_img.size[1]
        if event.type == 'MOUSEMOVE':
            center_x = layer.location[0] + layer_width / 2.0
            center_y = height - layer.location[1] - layer_height / 2.0
            region_pos = [event.mouse_region_x, event.mouse_region_y]
            view_x, view_y = context.region.view2d.region_to_view(*region_pos)
            target_x = width * view_x
            target_y = height * view_y
            dist1 = math.hypot(self.start_input_position[0] - center_x, self.start_input_position[1] - center_y)
            dist2 = math.hypot(target_x - center_x, target_y - center_y)
            layer.scale[0] = self.start_layer_scale_x * dist2 / dist1
            layer.scale[1] = self.start_layer_scale_y * dist2 / dist1
        elif event.type == 'LEFTMOUSE':
            app.rebuild_image_layers_nodes(img)
            area_session.layer_scaling = False
            area_session.prevent_layer_update_event = False
            return {'FINISHED'}
        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            layer.scale[0] = self.start_layer_scale_x
            layer.scale[1] = self.start_layer_scale_y
            area_session.layer_scaling = False
            area_session.prevent_layer_update_event = False
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        area_session = app.get_area_session(context)
        img = context.area.spaces.active.image
        width, height = img.size[0], img.size[1]
        layer = app.get_active_layer(context)
        if not layer:
            return {'CANCELLED'}
        if layer.locked:
            self.report({'WARNING'}, 'Layer is locked.')
            return {'CANCELLED'}
        region_pos = [event.mouse_region_x, event.mouse_region_y]
        view_x, view_y = context.region.view2d.region_to_view(*region_pos)
        self.start_input_position = [width * view_x, height * view_y]
        self.start_layer_scale_x = layer.scale[0]
        self.start_layer_scale_y = layer.scale[1]
        area_session.layer_scaling = True
        area_session.prevent_layer_update_event = True
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

class IMAGE_EDITOR_PLUS_OT_offset(bpy.types.Operator):
    """Apply settings"""
    bl_idname = 'image_editor_plus.offset'
    bl_label = "Offset"
    offset_x: bpy.props.IntProperty()
    offset_y: bpy.props.IntProperty()
    offset_edge_behavior: bpy.props.EnumProperty(items=(('wrap', 'Wrap', 'Wrap image around'), ('edge', 'Edge', 'Repeat edge pixels')))

    def execute(self, context):
        wm = context.window_manager
        offset_x = self.offset_x
        offset_y = self.offset_y
        edge_behavior = self.offset_edge_behavior
        pixels = app.get_image_cache()
        if pixels is None:
            return {'CANCELLED'}
        selection = app.get_target_selection(context)
        if selection:
            target_pixels = pixels[selection[0][1]:selection[1][1], selection[0][0]:selection[1][0]]
        elif selection == []:
            return {'CANCELLED'}
        else:
            target_pixels = pixels
        new_pixels = np.roll(target_pixels, offset_y, axis=0)
        if edge_behavior == 'edge':
            if offset_y > 0:
                new_pixels[:offset_y] = new_pixels[offset_y]
            elif offset_y < 0:
                new_pixels[offset_y:] = new_pixels[offset_y - 1]
        new_pixels = np.roll(new_pixels, offset_x, axis=1)
        if edge_behavior == 'edge':
            if offset_x > 0:
                new_pixels[:, :offset_x] = new_pixels[:, offset_x, np.newaxis]
            elif offset_x < 0:
                new_pixels[:, offset_x:] = new_pixels[:, offset_x - 1, np.newaxis]
        if selection:
            pixels[selection[0][1]:selection[1][1], selection[0][0]:selection[1][0]] = new_pixels
        else:
            pixels[:,:] = new_pixels
        img = app.get_target_image(context)
        utils.write_pixels_to_image(img, pixels)
        app.refresh_image(context)
        return {'FINISHED'}
