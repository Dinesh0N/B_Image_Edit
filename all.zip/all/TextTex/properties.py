import bpy
from bpy.types import PropertyGroup
from bpy.props import StringProperty, IntProperty, EnumProperty, BoolProperty, FloatVectorProperty, FloatProperty, PointerProperty
from . import utils

def update_gradient_init(self, context):
    """Ensure gradient node tree exists when gradient is enabled."""
    if self.use_gradient:
        # This creates the node tree if missing, which is safe in an operator/update loop
        # but not in a draw loop. By doing it here, we ensure ui.py finds it ready.
        try:
            utils.get_gradient_node()
        except Exception as e:
            print(f"Error initializing gradient node: {e}")

class TextTexProperties(PropertyGroup):
    text: StringProperty(
        name="Text",
        description="Text to paint",
        default="Text"
    )
    use_text_block: BoolProperty(
        name="Use Text Block",
        description="Use a Text Editor data block for multi-line text",
        default=False
    )
    text_block: PointerProperty(
        name="Text Block",
        description="Text data block to use for multi-line text",
        type=bpy.types.Text
    )
    font_file: PointerProperty(
        name="Font",
        description="Font to use",
        type=bpy.types.VectorFont
    )
    font_size: IntProperty(
        name="Font Size",
        description="TTF/OTF font size (pixels)",
        default=64,
        min=8,
        max=512
    )
    color: FloatVectorProperty(
        name="Color",
        description="Text color",
        default=(1.0, 1.0, 1.0, 1.0),
        min=0.0,
        max=1.0,
        size=4,
        subtype='COLOR'
    )

    anchor_horizontal: EnumProperty(
        name="Anchor X",
        description="Horizontal text anchor relative to cursor",
        items=[
            ('LEFT', "Left", "Text starts at cursor (left-aligned)", 'ANCHOR_LEFT', 0),
            ('CENTER', "Center", "Text center at cursor", 'ANCHOR_CENTER', 1),
            ('RIGHT', "Right", "Text ends at cursor (right-aligned)", 'ANCHOR_RIGHT', 2),
        ],
        default='CENTER'
    )
    anchor_vertical: EnumProperty(
        name="Anchor Y",
        description="Vertical text anchor relative to cursor",
        items=[
            ('TOP', "Top", "Text below cursor", 'ANCHOR_TOP', 0),
            ('CENTER', "Center", "Text center at cursor", 'ANCHOR_CENTER', 1),
            ('BOTTOM', "Bottom", "Text above cursor", 'ANCHOR_BOTTOM', 2),
        ],
        default='CENTER'
    )
    text_alignment: EnumProperty(
        name="Alignment",
        description="Text alignment for multi-line text",
        items=[
            ('LEFT', "Left", "Align text to the left", 'ALIGN_LEFT', 0),
            ('CENTER', "Center", "Center align text", 'ALIGN_CENTER', 1),
            ('RIGHT', "Right", "Align text to the right", 'ALIGN_RIGHT', 2),
        ],
        default='CENTER'
    )
    line_spacing: FloatProperty(
        name="Line Spacing",
        description="Spacing between lines (1.0 = normal, 1.5 = 150%)",
        default=1.2,
        min=0.5,
        max=3.0,
        step=10,
        precision=2
    )
    rotation: FloatProperty(
        name="Rotation",
        description="Text rotation in degrees (counter-clockwise)",
        default=0.0,
        min=0.0,
        max=360.0,
        subtype='ANGLE'
    )
    align_to_view: BoolProperty(
        name="Align to View",
        description="Align text rotation to viewport camera (uncheck for UV/3D alignment)",
        default=True
    )
    projection_mode: EnumProperty(
        name="Projection",
        description="How text is projected onto the surface",
        items=[
            ('UV', "UV-Based", "Place text at UV coordinates (fast)"),
            ('VIEW', "3D Projected", "Project text from view like brush strokes (accurate)"),
        ],
        default='VIEW'
    )
    
    # Gradient properties
    use_gradient: BoolProperty(
        name="Use Gradient",
        description="Use gradient instead of solid color",
        default=False,
        update=update_gradient_init
    )
    gradient_type: EnumProperty(
        name="Gradient Type",
        description="Type of gradient to apply",
        items=[
            ('LINEAR', "Linear", "Linear gradient from left to right"),
            ('RADIAL', "Radial", "Radial gradient from center outward"),
        ],
        default='LINEAR'
    )
    gradient_rotation: FloatProperty(
        name="Gradient Rotation",
        description="Rotation of the gradient in degrees",
        default=0.0,
        min=0.0,
        max=360.0
    )
    
    # Outline properties
    use_outline: BoolProperty(
        name="Use Outline",
        description="Add outline/stroke around text",
        default=False
    )
    outline_color: FloatVectorProperty(
        name="Outline Color",
        description="Color of the text outline",
        default=(0.0, 0.0, 0.0, 1.0),
        min=0.0,
        max=1.0,
        size=4,
        subtype='COLOR'
    )
    outline_size: IntProperty(
        name="Outline Size",
        description="Thickness of the text outline in pixels",
        default=2,
        min=1,
        max=20
    )
    
    # Anti-aliasing (for text, gradient, clone tools)
    use_antialiasing: BoolProperty(
        name="Anti-Aliasing",
        description="Smooth the edges of strokes and painted elements",
        default=True
    )
    
    # Crop Tool properties
    crop_show_thirds: BoolProperty(
        name="Show Rule of Thirds",
        description="Display rule of thirds grid overlay on crop selection",
        default=True
    )
    crop_lock_aspect: BoolProperty(
        name="Lock Aspect Ratio",
        description="Constrain crop selection to specified aspect ratio",
        default=False
    )
    crop_aspect_width: FloatProperty(
        name="Width",
        description="Aspect ratio width component",
        default=16.0,
        min=0.1,
        max=100.0
    )
    crop_aspect_height: FloatProperty(
        name="Height",
        description="Aspect ratio height component",
        default=9.0,
        min=0.1,
        max=100.0
    )
    crop_expand_canvas: BoolProperty(
        name="Expand Canvas",
        description="Allow expanding the canvas beyond the original image bounds",
        default=False
    )
    crop_fill_color: FloatVectorProperty(
        name="Fill Color",
        description="Color to fill expanded canvas areas",
        default=(0.0, 0.0, 0.0, 1.0),
        min=0.0,
        max=1.0,
        size=4,
        subtype='COLOR'
    )
    crop_use_resolution: BoolProperty(
        name="Set Resolution",
        description="Scale crop result to a specific resolution",
        default=False
    )
    crop_resolution_x: IntProperty(
        name="Width",
        description="Output width in pixels",
        default=1920,
        min=1,
        max=16384
    )
    crop_resolution_y: IntProperty(
        name="Height",
        description="Output height in pixels",
        default=1080,
        min=1,
        max=16384
    )
    
    # Clone Tool properties
    clone_brush_size: IntProperty(
        name="Brush Size",
        description="Clone brush radius in pixels",
        default=50,
        min=1,
        max=500
    )
    clone_falloff_preset: EnumProperty(
        name="Falloff",
        description="Brush edge falloff curve preset",
        items=[
            ('SMOOTH', "Smooth", "Smooth falloff curve", 'SMOOTHCURVE', 0),
            ('SMOOTHER', "Smoother", "Extra smooth falloff", 'SMOOTHCURVE', 1),
            ('SPHERE', "Sphere", "Spherical falloff", 'SPHERECURVE', 2),
            ('ROOT', "Root", "Root falloff (square root)", 'ROOTCURVE', 3),
            ('SHARP', "Sharp", "Sharp falloff curve", 'SHARPCURVE', 4),
            ('LINEAR', "Linear", "Linear falloff", 'LINCURVE', 5),
            ('CONSTANT', "Constant", "No falloff (hard edge)", 'NOCURVE', 6),
            ('CUSTOM', "Custom", "Use custom curve from active brush", 'RNDCURVE', 7),
        ],
        default='SMOOTH'
    )
    clone_brush_strength: FloatProperty(
        name="Strength",
        description="Opacity/strength of clone painting (1.0 = full, 0.0 = none)",
        default=1.0,
        min=0.0,
        max=1.0
    )
    
    # Pen Tool properties
    pen_use_stroke: BoolProperty(
        name="Stroke",
        description="Enable stroke for the path",
        default=True
    )
    pen_use_fill: BoolProperty(
        name="Fill",
        description="Enable fill for the path",
        default=False
    )
    pen_stroke_color: FloatVectorProperty(
        name="Stroke Color",
        description="Color of the path stroke",
        default=(1.0, 1.0, 1.0, 1.0),
        min=0.0,
        max=1.0,
        size=4,
        subtype='COLOR'
    )
    pen_fill_color: FloatVectorProperty(
        name="Fill Color",
        description="Color of the path fill",
        default=(0.5, 0.5, 0.5, 1.0),
        min=0.0,
        max=1.0,
        size=4,
        subtype='COLOR'
    )
    pen_stroke_width: IntProperty(
        name="Stroke Width",
        description="Width of the stroke in pixels",
        default=3,
        min=1,
        max=50
    )


# ----------------------------
# Image Layer System
# ----------------------------

class ImageLayer(PropertyGroup):
    """Single layer in the layer stack - stores reference to layer image."""
    # Name of the Blender image that contains layer pixels
    layer_image_name: StringProperty(
        name="Layer Image",
        description="Name of the Blender image containing this layer's pixels",
        default=""
    )
    label: StringProperty(
        name="Label",
        description="Display name for the layer",
        default="Layer"
    )
    opacity: FloatProperty(
        name="Opacity",
        description="Layer opacity",
        default=1.0,
        min=0.0,
        max=1.0,
        subtype='FACTOR'
    )
    blend_mode: EnumProperty(
        name="Blend Mode",
        description="Layer blend mode",
        items=[
            ('MIX', "Normal", "Normal blending"),
            ('DARKEN', "Darken", "Keep darker pixels"),
            ('MUL', "Multiply", "Multiply colors"),
            ('LIGHTEN', "Lighten", "Keep lighter pixels"),
            ('SCREEN', "Screen", "Inverse multiply"),
            ('ADD', "Add", "Add colors"),
            ('OVERLAY', "Overlay", "Overlay blend"),
            ('SOFT_LIGHT', "Soft Light", "Soft light blend"),
            ('DIFFERENCE', "Difference", "Color difference"),
        ],
        default='MIX'
    )
    visible: BoolProperty(
        name="Visible",
        description="Layer visibility",
        default=True
    )
    locked: BoolProperty(
        name="Locked",
        description="Lock layer from editing",
        default=False
    )


class ImageLayerSettings(PropertyGroup):
    """Layer settings stored per-image."""
    layers: bpy.props.CollectionProperty(type=ImageLayer)
    active_layer_index: IntProperty(
        name="Active Layer",
        description="Index of active layer",
        default=0,
        min=0
    )
