bl_info = {
    "name": "B Image Editor",
    "author": "Dinesh007",
    "version": (1, 0, 0),
    "blender": (5, 0, 0),
    "location": "Texture Paint Mode > Toolbar",
    "description": "Text, Gradient, Crop and Clone tools.",
    "category": "Paint",
}

import bpy
from . import properties
from . import preferences
from . import ui
from . import operators
from . import sync

classes = (
    properties.ImageLayer,
    properties.ImageLayerSettings,
    properties.TextTexProperties,
    *preferences.preference_classes,
    operators.TEXTURE_PAINT_OT_input_text,
    operators.TEXTURE_PAINT_OT_refresh_fonts,
    operators.TEXTURE_PAINT_OT_text_tool,
    operators.IMAGE_PAINT_OT_text_tool,
    operators.TEXTURE_PAINT_OT_gradient_tool,
    operators.IMAGE_PAINT_OT_gradient_tool,
    operators.IMAGE_PAINT_OT_crop_tool,
    operators.IMAGE_PAINT_OT_clone_tool,
    operators.IMAGE_PAINT_OT_clone_adjust_size,
    operators.IMAGE_PAINT_OT_clone_adjust_strength,
    operators.IMAGE_PAINT_OT_pen_tool,
    operators.TEXTTOOL_OT_undo,
    operators.TEXTTOOL_OT_redo,
    operators.TEXTTOOL_OT_adjust_font_size,
    operators.TEXTTOOL_OT_adjust_rotation,
    # Layer operators
    operators.IMAGE_OT_layer_add,
    operators.IMAGE_OT_layer_delete,
    operators.IMAGE_OT_layer_duplicate,
    operators.IMAGE_OT_layer_move_up,
    operators.IMAGE_OT_layer_move_down,
    operators.IMAGE_OT_layer_merge_down,
    operators.IMAGE_OT_layer_flatten,
    operators.IMAGE_OT_layer_from_image,
    operators.IMAGE_OT_layer_open_image,
    # Layer UI
    ui.IMAGE_UL_layers,
    ui.IMAGE_PT_layers,
)

_addon_keymaps = []

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.text_tool_properties = bpy.props.PointerProperty(type=properties.TextTexProperties)
    bpy.types.Image.layer_settings = bpy.props.PointerProperty(type=properties.ImageLayerSettings)
    bpy.utils.register_tool(ui.TextTool, separator=True, group=False)
    bpy.utils.register_tool(ui.GradientTool, separator=False, group=False)
    bpy.utils.register_tool(ui.ImageTextTool, separator=True, group=False)
    bpy.utils.register_tool(ui.ImageGradientTool, separator=False, group=False)
    bpy.utils.register_tool(ui.ImageCropTool, separator=False, group=False)
    bpy.utils.register_tool(ui.ImageCloneTool, separator=False, group=False)
    bpy.utils.register_tool(ui.ImagePenTool, separator=False, group=False)
    
    if not bpy.app.timers.is_registered(sync.sync_tool_timer):
        bpy.app.timers.register(sync.sync_tool_timer)
    
    # Register keymaps for undo/redo
    wm = bpy.context.window_manager
    if wm.keyconfigs.addon:
        # Texture Paint mode keymap
        km = wm.keyconfigs.addon.keymaps.new(name='Texture Paint', space_type='EMPTY')
        kmi = km.keymap_items.new('texttool.undo', 'Z', 'PRESS', ctrl=True)
        _addon_keymaps.append((km, kmi))
        kmi = km.keymap_items.new('texttool.redo', 'Z', 'PRESS', ctrl=True, shift=True)
        _addon_keymaps.append((km, kmi))
        # Font Size: F key
        kmi = km.keymap_items.new('texttool.adjust_font_size', 'F', 'PRESS')
        _addon_keymaps.append((km, kmi))
        # Rotation: Ctrl+F key
        kmi = km.keymap_items.new('texttool.adjust_rotation', 'F', 'PRESS', ctrl=True)
        _addon_keymaps.append((km, kmi))
        
        # Image Paint mode keymap
        km = wm.keyconfigs.addon.keymaps.new(name='Image Paint', space_type='EMPTY')
        kmi = km.keymap_items.new('texttool.undo', 'Z', 'PRESS', ctrl=True)
        _addon_keymaps.append((km, kmi))
        kmi = km.keymap_items.new('texttool.redo', 'Z', 'PRESS', ctrl=True, shift=True)
        _addon_keymaps.append((km, kmi))
        # Font Size: F key
        kmi = km.keymap_items.new('texttool.adjust_font_size', 'F', 'PRESS')
        _addon_keymaps.append((km, kmi))
        # Rotation: Ctrl+F key
        kmi = km.keymap_items.new('texttool.adjust_rotation', 'F', 'PRESS', ctrl=True)
        _addon_keymaps.append((km, kmi))

def unregister():
    # Unregister keymaps
    for km, kmi in _addon_keymaps:
        km.keymap_items.remove(kmi)
    _addon_keymaps.clear()
    
    if bpy.app.timers.is_registered(sync.sync_tool_timer):
        try:
            bpy.app.timers.unregister(sync.sync_tool_timer)
        except ValueError:
            pass

    bpy.utils.unregister_tool(ui.ImagePenTool)
    bpy.utils.unregister_tool(ui.ImageCloneTool)
    bpy.utils.unregister_tool(ui.ImageCropTool)
    bpy.utils.unregister_tool(ui.ImageGradientTool)
    bpy.utils.unregister_tool(ui.ImageTextTool)
    bpy.utils.unregister_tool(ui.GradientTool)
    bpy.utils.unregister_tool(ui.TextTool)
    del bpy.types.Image.layer_settings
    del bpy.types.Scene.text_tool_properties
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
        
    from . import utils
    utils.TextPreviewCache.get().cleanup()
    utils.ImageUndoStack.get().clear()
