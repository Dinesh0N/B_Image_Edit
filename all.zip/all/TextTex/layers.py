"""
Layer management utilities for the Image Layer System.
"""

import bpy
import numpy as np
import base64
import zlib


class LayerStack:
    """Manages layers for an image."""
    
    _instances = {}  # Cache of LayerStack instances keyed by image name
    
    @classmethod
    def get(cls, image):
        """Get or create LayerStack for an image."""
        if image.name not in cls._instances:
            cls._instances[image.name] = cls(image)
        return cls._instances[image.name]
    
    @classmethod
    def clear_cache(cls):
        """Clear all cached instances."""
        cls._instances.clear()
    
    def __init__(self, image):
        self.image = image
        self.width, self.height = image.size
    
    def get_settings(self):
        """Get or create layer settings for the image."""
        if not hasattr(bpy.types.Scene, 'image_layer_settings'):
            return None
        
        # Store settings on the scene, keyed by image name
        scene = bpy.context.scene
        if not hasattr(scene, 'layer_stacks'):
            return None
        
        return scene.layer_stacks.get(self.image.name)
    
    def ensure_base_layer(self):
        """Ensure at least one layer exists with current image content."""
        settings = self._get_or_create_settings()
        
        if len(settings.layers) == 0:
            # Create base layer from current image
            layer = settings.layers.add()
            layer.name = "Background"
            layer.opacity = 1.0
            layer.visible = True
            layer.locked = True
            
            # Store current image pixels
            self._save_layer_pixels(layer)
            
            settings.active_layer_index = 0
    
    def _get_or_create_settings(self):
        """Get or create layer settings in scene properties."""
        scene = bpy.context.scene
        props = scene.text_tool_properties
        
        # Use the image name as key in a dictionary-like structure
        # For simplicity, store on scene.text_tool_properties with dynamic attribute
        if not hasattr(props, '_layer_stacks'):
            props._layer_stacks = {}
        
        if self.image.name not in props._layer_stacks:
            # Initialize with empty settings reference
            pass
        
        return scene.image_layer_settings
    
    def _save_layer_pixels(self, layer):
        """Save layer pixels as compressed base64."""
        pixels = np.zeros(self.width * self.height * 4, dtype=np.float32)
        self.image.pixels.foreach_get(pixels)
        
        # Convert to uint8 for compression
        pixels_uint8 = (pixels * 255).astype(np.uint8)
        
        # Compress and encode
        compressed = zlib.compress(pixels_uint8.tobytes(), level=6)
        layer.pixel_data = base64.b64encode(compressed).decode('ascii')
    
    def _load_layer_pixels(self, layer):
        """Load layer pixels from compressed base64."""
        if not layer.pixel_data:
            return np.zeros((self.height, self.width, 4), dtype=np.float32)
        
        # Decode and decompress
        compressed = base64.b64decode(layer.pixel_data)
        pixels_uint8 = np.frombuffer(zlib.decompress(compressed), dtype=np.uint8)
        
        # Convert back to float
        pixels = pixels_uint8.astype(np.float32) / 255.0
        return pixels.reshape((self.height, self.width, 4))
    
    def add_layer(self, name="New Layer", above_active=True):
        """Add a new transparent layer."""
        settings = self._get_or_create_settings()
        
        # Create new layer
        layer = settings.layers.add()
        layer.name = name
        layer.opacity = 1.0
        layer.visible = True
        layer.locked = False
        
        # Initialize with transparent pixels
        pixels = np.zeros((self.height, self.width, 4), dtype=np.float32)
        pixels[:, :, 3] = 0.0  # Fully transparent
        
        # Compress and store
        pixels_uint8 = (pixels * 255).astype(np.uint8)
        compressed = zlib.compress(pixels_uint8.tobytes(), level=6)
        layer.pixel_data = base64.b64encode(compressed).decode('ascii')
        
        # Move to correct position
        if above_active and len(settings.layers) > 1:
            new_idx = len(settings.layers) - 1
            target_idx = settings.active_layer_index + 1
            settings.layers.move(new_idx, target_idx)
            settings.active_layer_index = target_idx
        else:
            settings.active_layer_index = len(settings.layers) - 1
        
        return layer
    
    def delete_layer(self, index):
        """Delete a layer by index."""
        settings = self._get_or_create_settings()
        
        if len(settings.layers) <= 1:
            return False  # Can't delete last layer
        
        settings.layers.remove(index)
        
        # Adjust active index
        if settings.active_layer_index >= len(settings.layers):
            settings.active_layer_index = len(settings.layers) - 1
        
        return True
    
    def composite_layers(self):
        """Composite all visible layers and update the image."""
        settings = self._get_or_create_settings()
        
        if len(settings.layers) == 0:
            return
        
        # Start with transparent base
        result = np.zeros((self.height, self.width, 4), dtype=np.float32)
        
        # Composite from bottom to top
        for layer in settings.layers:
            if not layer.visible:
                continue
            
            layer_pixels = self._load_layer_pixels(layer)
            
            # Apply layer opacity
            layer_alpha = layer_pixels[:, :, 3:4] * layer.opacity
            
            # Blend based on mode
            result = self._blend_layers(result, layer_pixels, layer_alpha, layer.blend_mode)
        
        # Update image
        self.image.pixels.foreach_set(result.flatten())
        self.image.update()
    
    def _blend_layers(self, dst, src, alpha, blend_mode):
        """Blend source onto destination with given alpha and blend mode."""
        d_rgb = dst[:, :, :3]
        s_rgb = src[:, :, :3]
        d_alpha = dst[:, :, 3:4]
        
        # Calculate blended RGB
        if blend_mode == 'MIX':
            blended_rgb = s_rgb
        elif blend_mode == 'DARKEN':
            blended_rgb = np.minimum(d_rgb, s_rgb)
        elif blend_mode == 'MUL':
            blended_rgb = d_rgb * s_rgb
        elif blend_mode == 'LIGHTEN':
            blended_rgb = np.maximum(d_rgb, s_rgb)
        elif blend_mode == 'SCREEN':
            blended_rgb = 1.0 - (1.0 - d_rgb) * (1.0 - s_rgb)
        elif blend_mode == 'ADD':
            blended_rgb = np.clip(d_rgb + s_rgb, 0.0, 1.0)
        elif blend_mode == 'OVERLAY':
            mask = d_rgb < 0.5
            blended_rgb = np.where(mask, 2.0 * d_rgb * s_rgb, 1.0 - 2.0 * (1.0 - d_rgb) * (1.0 - s_rgb))
        elif blend_mode == 'SOFT_LIGHT':
            blended_rgb = (1.0 - 2.0 * s_rgb) * (d_rgb ** 2) + 2.0 * s_rgb * d_rgb
        elif blend_mode == 'DIFFERENCE':
            blended_rgb = np.abs(d_rgb - s_rgb)
        else:
            blended_rgb = s_rgb
        
        # Alpha compositing
        out_rgb = d_rgb * (1 - alpha) + blended_rgb * alpha
        out_alpha = d_alpha + alpha * (1 - d_alpha)
        
        return np.dstack((out_rgb, out_alpha[:, :, 0]))
    
    def get_active_layer_pixels(self):
        """Get pixels of the active layer for painting."""
        settings = self._get_or_create_settings()
        
        if len(settings.layers) == 0:
            return None
        
        layer = settings.layers[settings.active_layer_index]
        return self._load_layer_pixels(layer)
    
    def set_active_layer_pixels(self, pixels):
        """Set pixels of the active layer after painting."""
        settings = self._get_or_create_settings()
        
        if len(settings.layers) == 0:
            return
        
        layer = settings.layers[settings.active_layer_index]
        
        # Compress and store
        pixels_uint8 = (np.clip(pixels, 0.0, 1.0) * 255).astype(np.uint8)
        compressed = zlib.compress(pixels_uint8.tobytes(), level=6)
        layer.pixel_data = base64.b64encode(compressed).decode('ascii')
        
        # Recomposite
        self.composite_layers()
