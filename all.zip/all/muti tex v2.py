
bl_info = {
    "name": "Multi-Texture Brush",
    "author": "Dinesh007",
    "version": (1, 0, 0),
    "blender": (5, 0, 0),
    "location": "View3D > Tool > Multi-Texture Brush",
    "description": "Cycle through multiple brush textures in texture paint mode (sequential or random)",
    "category": "Paint",
}

import bpy
import random
from bpy.props import (
    BoolProperty,
    IntProperty,
    FloatProperty,
    EnumProperty,
    StringProperty,
    PointerProperty,
    CollectionProperty,
)
from bpy.types import PropertyGroup, Operator, Panel, UIList


# =============================================================================
# PROPERTY GROUPS
# =============================================================================

class MTB_TextureItem(PropertyGroup):
    """Individual texture entry in the texture list"""
    texture: PointerProperty(
        name="Texture",
        type=bpy.types.Texture,
        description="Brush texture data block"
    )
    enabled: BoolProperty(
        name="Enabled",
        default=True,
        description="Enable this texture in the rotation"
    )


class MTB_Settings(PropertyGroup):
    """Main addon settings"""
    enabled: BoolProperty(
        name="Enable Multi-Texture",
        default=False,
        description="Enable multi-texture brush switching"
    )

    auto_switch: BoolProperty(
        name="Auto-Switch",
        default=False,
        description="Automatically switch textures while painting",
        update=lambda self, context: on_auto_switch_update(self, context)
    )

    switch_mode: EnumProperty(
        name="Switch Mode",
        items=[
            ('ORDER', "Order", "Cycle textures in sequential order", 'FORWARD', 0),
            ('RANDOM', "Random", "Randomly select textures", 'QUESTION', 1),
        ],
        default='ORDER',
        description="How to switch between textures"
    )

    trigger_mode: EnumProperty(
        name="Trigger Mode",
        items=[
            ('STROKE', "Per Stroke", "Switch texture on each new stroke", 'BRUSH_DATA', 0),
            ('INTERVAL', "Interval", "Switch texture at timed intervals while painting", 'TIME', 1),
        ],
        default='STROKE',
        description="When to switch textures"
    )

    interval_time: FloatProperty(
        name="Interval",
        default=0.2,
        min=0.02,
        max=5.0,
        step=1,
        precision=2,
        description="Time interval between texture switches (seconds)"
    )

    current_index: IntProperty(
        name="Current Index",
        default=0,
        min=0,
        description="Current texture index in the list"
    )

    active_index: IntProperty(
        name="Active Index",
        default=0,
        description="Active texture in the UI list",
        update=lambda self, context: on_active_index_change(self, context)
    )

    textures: CollectionProperty(type=MTB_TextureItem)


def on_active_index_change(self, context):
    """Called when user selects a different item in the list - switches to that texture"""
    if self.active_index < len(self.textures):
        item = self.textures[self.active_index]
        if item.texture and item.enabled:
            apply_texture_to_brush(context, item.texture)


def on_auto_switch_update(self, context):
    """Called when auto_switch toggle changes"""
    if self.auto_switch:
        # Start the monitor
        if context.mode in ('PAINT_TEXTURE', 'SCULPT', 'PAINT_VERTEX', 'PAINT_WEIGHT'):
            bpy.ops.mtb.stroke_monitor('INVOKE_DEFAULT')
    # If turning off, the modal operator will cancel itself


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_enabled_textures(settings):
    """Get list of enabled textures"""
    return [item for item in settings.textures if item.enabled and item.texture]


def get_next_texture(settings):
    """Get the next texture based on current mode"""
    enabled = get_enabled_textures(settings)
    if not enabled:
        return None

    if settings.switch_mode == 'RANDOM':
        return random.choice(enabled).texture
    else:  # ORDER
        settings.current_index = settings.current_index % len(enabled)
        texture = enabled[settings.current_index].texture
        settings.current_index = (settings.current_index + 1) % len(enabled)
        return texture


def apply_texture_to_brush(context, texture):
    """Apply texture to the current brush"""
    if not texture:
        return False

    # Get the active brush
    tool_settings = context.tool_settings
    brush = None

    if context.mode == 'PAINT_TEXTURE':
        brush = tool_settings.image_paint.brush
    elif context.mode == 'SCULPT':
        brush = tool_settings.sculpt.brush
    elif context.mode == 'PAINT_VERTEX':
        brush = tool_settings.vertex_paint.brush
    elif context.mode == 'PAINT_WEIGHT':
        brush = tool_settings.weight_paint.brush

    if brush:
        # Directly assign the texture data block to the brush
        brush.texture_slot.texture = texture
        return True

    return False


def switch_texture(context):
    """Switch to the next texture"""
    settings = context.scene.mtb_settings
    if not settings.enabled:
        return False

    texture = get_next_texture(settings)
    return apply_texture_to_brush(context, texture)


# =============================================================================
# MODAL OPERATOR FOR STROKE DETECTION
# =============================================================================

class MTB_OT_stroke_monitor(Operator):
    """Modal operator that monitors paint strokes and switches textures"""
    bl_idname = "mtb.stroke_monitor"
    bl_label = "MTB Stroke Monitor"
    bl_options = {'INTERNAL'}

    _timer = None
    _last_switch_time = 0
    _is_painting = False  # Track if currently painting (mouse held down)
    _mouse_pressed = False  # Track raw mouse state

    @classmethod
    def poll(cls, context):
        return context.mode in ('PAINT_TEXTURE', 'SCULPT', 'PAINT_VERTEX', 'PAINT_WEIGHT')

    def modal(self, context, event):
        settings = context.scene.mtb_settings

        # Stop if disabled or auto_switch turned off
        if not settings.enabled or not settings.auto_switch:
            self.cancel(context)
            settings.auto_switch = False  # Ensure toggle is off
            return {'CANCELLED'}

        # Check if we're still in paint mode
        if context.mode not in ('PAINT_TEXTURE', 'SCULPT', 'PAINT_VERTEX', 'PAINT_WEIGHT'):
            self.cancel(context)
            settings.auto_switch = False
            return {'CANCELLED'}

        # Track mouse button state
        if event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                self._mouse_pressed = True
                self._is_painting = True
                # For STROKE mode, switch on stroke start
                if settings.trigger_mode == 'STROKE':
                    switch_texture(context)
                # For INTERVAL mode, switch immediately and reset timer
                elif settings.trigger_mode == 'INTERVAL':
                    import time
                    self._last_switch_time = time.time()
                    switch_texture(context)
            elif event.value == 'RELEASE':
                self._mouse_pressed = False
                self._is_painting = False

        # Also track painting via mouse movement with button held
        if event.type == 'MOUSEMOVE' and self._mouse_pressed:
            self._is_painting = True

        # INTERVAL mode: switch at intervals while actively painting
        if settings.trigger_mode == 'INTERVAL' and event.type == 'TIMER':
            if self._is_painting and self._mouse_pressed:
                import time
                current_time = time.time()
                if current_time - self._last_switch_time >= settings.interval_time:
                    switch_texture(context)
                    self._last_switch_time = current_time

        return {'PASS_THROUGH'}

    def execute(self, context):
        import time

        settings = context.scene.mtb_settings

        # Add timer for interval mode - faster polling for more responsive switching
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.016, window=context.window)  # ~60fps
        self._last_switch_time = time.time()
        self._is_painting = False
        self._mouse_pressed = False

        wm.modal_handler_add(self)

        self.report({'INFO'}, "Multi-Texture Brush monitoring started")
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        if self._timer:
            wm = context.window_manager
            wm.event_timer_remove(self._timer)
            self._timer = None


class MTB_OT_start_monitoring(Operator):
    """Toggle the texture switching monitor"""
    bl_idname = "mtb.start_monitor"
    bl_label = "Toggle Monitoring"
    bl_description = "Toggle automatic texture switching"

    @classmethod
    def poll(cls, context):
        settings = context.scene.mtb_settings
        return settings.enabled and len(get_enabled_textures(settings)) > 0

    def execute(self, context):
        settings = context.scene.mtb_settings
        # Toggle the auto_switch property (which will trigger the modal)
        settings.auto_switch = not settings.auto_switch
        return {'FINISHED'}


# =============================================================================
# OPERATORS
# =============================================================================

class MTB_OT_add_texture(Operator):
    """Add a new texture to the list"""
    bl_idname = "mtb.add_texture"
    bl_label = "Add Texture"
    bl_description = "Add a new texture slot to the list"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.mtb_settings
        item = settings.textures.add()
        settings.active_index = len(settings.textures) - 1
        return {'FINISHED'}


class MTB_OT_remove_texture(Operator):
    """Remove the selected texture from the list"""
    bl_idname = "mtb.remove_texture"
    bl_label = "Remove Texture"
    bl_description = "Remove the selected texture from the list"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        settings = context.scene.mtb_settings
        return len(settings.textures) > 0

    def execute(self, context):
        settings = context.scene.mtb_settings
        if settings.active_index < len(settings.textures):
            settings.textures.remove(settings.active_index)
            settings.active_index = max(0, settings.active_index - 1)
        return {'FINISHED'}


class MTB_OT_move_texture(Operator):
    """Move texture up or down in the list"""
    bl_idname = "mtb.move_texture"
    bl_label = "Move Texture"
    bl_description = "Move the selected texture up or down"
    bl_options = {'REGISTER', 'UNDO'}

    direction: EnumProperty(
        items=[
            ('UP', "Up", ""),
            ('DOWN', "Down", ""),
        ]
    )

    @classmethod
    def poll(cls, context):
        settings = context.scene.mtb_settings
        return len(settings.textures) > 1

    def execute(self, context):
        settings = context.scene.mtb_settings
        index = settings.active_index

        if self.direction == 'UP' and index > 0:
            settings.textures.move(index, index - 1)
            settings.active_index -= 1
        elif self.direction == 'DOWN' and index < len(settings.textures) - 1:
            settings.textures.move(index, index + 1)
            settings.active_index += 1

        return {'FINISHED'}


class MTB_OT_add_current_brush_texture(Operator):
    """Add the current brush's texture to the list"""
    bl_idname = "mtb.add_current_texture"
    bl_label = "Add Current Brush Texture"
    bl_description = "Add the texture from the current brush to the list"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        brush = None
        if context.mode == 'PAINT_TEXTURE':
            brush = context.tool_settings.image_paint.brush
        elif context.mode == 'SCULPT':
            brush = context.tool_settings.sculpt.brush

        return brush and brush.texture_slot.texture is not None

    def execute(self, context):
        settings = context.scene.mtb_settings
        brush = None

        if context.mode == 'PAINT_TEXTURE':
            brush = context.tool_settings.image_paint.brush
        elif context.mode == 'SCULPT':
            brush = context.tool_settings.sculpt.brush

        if brush and brush.texture_slot.texture:
            tex = brush.texture_slot.texture
            # Check if texture is already in the list
            for existing in settings.textures:
                if existing.texture == tex:
                    self.report({'WARNING'}, f"Texture '{tex.name}' already in list")
                    return {'CANCELLED'}

            item = settings.textures.add()
            item.texture = tex
            settings.active_index = len(settings.textures) - 1
            self.report({'INFO'}, f"Added texture: {tex.name}")
            return {'FINISHED'}

        self.report({'WARNING'}, "No brush texture found")
        return {'CANCELLED'}


class MTB_OT_switch_texture_now(Operator):
    """Manually switch to the next texture"""
    bl_idname = "mtb.switch_now"
    bl_label = "Switch Texture Now"
    bl_description = "Manually switch to the next texture"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        settings = context.scene.mtb_settings
        return len(get_enabled_textures(settings)) > 0

    def execute(self, context):
        settings = context.scene.mtb_settings
        texture = get_next_texture(settings)
        if texture:
            apply_texture_to_brush(context, texture)
            self.report({'INFO'}, f"Switched to: {texture.name}")
        return {'FINISHED'}


class MTB_OT_clear_all_textures(Operator):
    """Clear all textures from the list"""
    bl_idname = "mtb.clear_all"
    bl_label = "Clear All Textures?"
    bl_description = "Remove all textures from the list"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        # Show confirmation dialog
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        settings = context.scene.mtb_settings
        settings.textures.clear()
        settings.active_index = 0
        settings.current_index = 0
        self.report({'INFO'}, "All textures cleared")
        return {'FINISHED'}


# =============================================================================
# UI LIST
# =============================================================================

class MTB_UL_texture_list(UIList):
    """UI List for displaying textures"""
    bl_idname = "MTB_UL_texture_list"

    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)

            # Enable toggle (small)
            row.prop(item, "enabled", text="", icon='CHECKBOX_HLT' if item.enabled else 'CHECKBOX_DEHLT', emboss=False)

            # Texture name label (large clickable area)
            if item.texture:
                row.label(text=item.texture.name, icon='TEXTURE')
            else:
                row.label(text="(None)", icon='TEXTURE')

            # Small texture selector at the end
            sub = row.row(align=True)
            sub.scale_x = 0.5
            sub.prop(item, "texture", text="", icon_only=True)

        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            if item.texture:
                layout.label(text=item.texture.name, icon='TEXTURE')
            else:
                layout.label(text="", icon='TEXTURE')


# =============================================================================
# PANELS
# =============================================================================

class MTB_PT_main_panel(Panel):
    """Main panel for Multi-Texture Brush"""
    bl_label = "Multi-Texture Brush"
    bl_idname = "MTB_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Tool"
    bl_context = "imagepaint"

    @classmethod
    def poll(cls, context):
        return context.mode in ('PAINT_TEXTURE', 'SCULPT')

    def draw_header(self, context):
        settings = context.scene.mtb_settings
        self.layout.prop(settings, "enabled", text="")

    def draw(self, context):
        draw_mtb_panel(self.layout, context)


class MTB_PT_main_panel_image_editor(Panel):
    """Main panel for Multi-Texture Brush in Image Editor"""
    bl_label = "Multi-Texture Brush"
    bl_idname = "MTB_PT_main_panel_image_editor"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Tool"

    @classmethod
    def poll(cls, context):
        # Show in Image Editor when in Paint mode
        return context.space_data.mode == 'PAINT'

    def draw_header(self, context):
        settings = context.scene.mtb_settings
        self.layout.prop(settings, "enabled", text="")

    def draw(self, context):
        draw_mtb_panel(self.layout, context)


def draw_mtb_panel(layout, context):
    """Shared panel drawing function for both 3D View and Image Editor"""
    settings = context.scene.mtb_settings

    layout.active = settings.enabled

    # Auto-switch toggle
    if settings.enabled:
        row = layout.row()
        row.scale_y = 1.3
        row.prop(settings, "auto_switch", text="Auto-Switch", icon='PLAY' if settings.auto_switch else 'PAUSE', toggle=True)

    layout.separator()

    # Mode selection
    col = layout.column(align=True)
    col.label(text="Switch Mode:")
    row = col.row(align=True)
    row.prop(settings, "switch_mode", expand=True)

    layout.separator()

    # Trigger mode
    col = layout.column(align=True)
    col.label(text="Trigger:")
    col.prop(settings, "trigger_mode", text="")

    if settings.trigger_mode == 'INTERVAL':
        col.prop(settings, "interval_time")

    layout.separator()

    # Texture list
    row = layout.row()
    row.template_list(
        "MTB_UL_texture_list",
        "",
        settings,
        "textures",
        settings,
        "active_index",
        rows=4
    )

    # List controls
    col = row.column(align=True)
    col.operator("mtb.add_texture", icon='ADD', text="")
    col.operator("mtb.remove_texture", icon='REMOVE', text="")
    col.separator()
    col.operator("mtb.move_texture", icon='TRIA_UP', text="").direction = 'UP'
    col.operator("mtb.move_texture", icon='TRIA_DOWN', text="").direction = 'DOWN'
    col.separator()
    col.operator("mtb.clear_all", icon='TRASH', text="")

    layout.separator()

    # Manual switch button
    row = layout.row()
    row.scale_y = 1.5
    row.operator("mtb.switch_now", icon='FILE_REFRESH', text="Switch Now")

    # Status info
    enabled_count = len(get_enabled_textures(settings))
    total_count = len(settings.textures)
    layout.label(text=f"Textures: {enabled_count}/{total_count} enabled", icon='INFO')


# =============================================================================
# REGISTRATION
# =============================================================================

classes = (
    MTB_TextureItem,
    MTB_Settings,
    MTB_OT_stroke_monitor,
    MTB_OT_start_monitoring,
    MTB_OT_add_texture,
    MTB_OT_remove_texture,
    MTB_OT_move_texture,
    MTB_OT_add_current_brush_texture,
    MTB_OT_switch_texture_now,
    MTB_OT_clear_all_textures,
    MTB_UL_texture_list,
    MTB_PT_main_panel,
    MTB_PT_main_panel_image_editor,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.mtb_settings = PointerProperty(type=MTB_Settings)


def unregister():
    del bpy.types.Scene.mtb_settings

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
